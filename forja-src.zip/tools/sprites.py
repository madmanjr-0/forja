"""Gera sprite sheets (versão web): cada frame 240x160, 10 colunas x 10 linhas por folha."""
import json, os
from PIL import Image, ImageOps
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ex=json.load(open(f'{ROOT}/src/data/exercises.json'))
FW,FH,COLS,ROWS=240,160,10,10
PER=COLS*ROWS
out=f'{ROOT}/assets/sprites'; os.makedirs(out,exist_ok=True)
frames=[]; pos={}
for e in ex:
    a=f"{ROOT}/assets/ex/{e['id']}_0.jpg"; b=f"{ROOT}/assets/ex/{e['id']}_1.jpg"
    if not os.path.exists(a): continue
    if not os.path.exists(b): b=a
    i0=len(frames); frames.append(a); frames.append(b)
    pos[e['id']]=[i0,i0+1]
sheets=(len(frames)+PER-1)//PER
for s in range(sheets):
    im=Image.new('RGB',(FW*COLS,FH*ROWS),(255,255,255))
    for k,f in enumerate(frames[s*PER:(s+1)*PER]):
        fr=ImageOps.fit(Image.open(f).convert('RGB'),(FW,FH))
        im.paste(fr,((k%COLS)*FW,(k//COLS)*FH))
    im.save(f'{out}/s{s}.jpg','JPEG',quality=68,optimize=True)
lines=['// Gerado por tools/sprites.py — só para a versão web.','export const SHEETS: number[] = [']
lines+= [f"  require('../../assets/sprites/s{s}.jpg')," for s in range(sheets)]
lines+=['];',f'export const GRID = {{ fw: {FW}, fh: {FH}, cols: {COLS}, rows: {ROWS}, per: {PER} }};',
        'export const POS: Record<string, [number, number]> = '+json.dumps(pos,separators=(',',':'))+';']
open(f'{ROOT}/src/data/sprites.ts','w').write('\n'.join(lines)+'\n')
print(sheets,'folhas',len(pos),'exercícios')
