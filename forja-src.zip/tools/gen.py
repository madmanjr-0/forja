"""Gera a base de exercícios (metadados + imagens otimizadas) a partir do free-exercise-db (domínio público)."""
import json, os, re, sys
from PIL import Image
sys.path.insert(0, os.path.dirname(__file__))
from pt_names import PT, CUES

SRC = '/home/claude/free-exercise-db'
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_IMG = os.path.join(ROOT, 'assets', 'ex')
os.makedirs(OUT_IMG, exist_ok=True)

EQ = {'barbell': 'Barra', 'dumbbell': 'Halteres', 'cable': 'Polia', 'machine': 'Máquina',
      'body only': 'Peso corporal', 'bands': 'Elástico', 'e-z curl bar': 'Barra W', 'kettlebells': 'Kettlebell'}
MUSCLE = {'chest': 'peito', 'lats': 'costas', 'middle back': 'costas', 'traps': 'trapezio', 'neck': 'trapezio',
          'lower back': 'lombar', 'shoulders': 'ombros', 'biceps': 'biceps', 'triceps': 'triceps',
          'forearms': 'antebracos', 'abdominals': 'abdominais', 'quadriceps': 'quadriceps',
          'hamstrings': 'isquios', 'glutes': 'gluteos', 'calves': 'gemeos', 'adductors': 'adutores',
          'abductors': 'adutores'}

data = json.load(open(f'{SRC}/dist/exercises.json'))
keep = []
for x in data:
    cat = x['category']
    eq = x['equipment']
    if x['id'] in PT:
        pass
    elif cat in ('strength', 'powerlifting') and eq in EQ:
        pass
    else:
        continue
    keep.append(x)

missing = [k for k in PT if k not in {x['id'] for x in data}]
if missing:
    print('IDs PT inexistentes:', missing)

def slug(s):
    return re.sub(r'[^a-z0-9]+', '_', s.lower()).strip('_')

out = []
img_lines = ['// Gerado por tools/gen.py — não editar à mão.', '/* eslint-disable */',
             'export const IMAGES: Record<string, [number, number]> = {']
for x in keep:
    sid = slug(x['id'])
    frames = []
    for i, rel in enumerate(x['images'][:2]):
        dst = os.path.join(OUT_IMG, f'{sid}_{i}.jpg')
        if not os.path.exists(dst):
            im = Image.open(os.path.join(SRC, 'exercises', rel)).convert('RGB')
            im.thumbnail((420, 420))
            im.save(dst, 'JPEG', quality=62, optimize=True, progressive=False)
        frames.append(f"require('../../assets/ex/{sid}_{i}.jpg')")
    if len(frames) == 1:
        frames.append(frames[0])
    if frames:
        img_lines.append(f"  '{sid}': [{frames[0]}, {frames[1]}],")
    cat = x['category']
    if cat == 'cardio' or x['id'] == 'Plank' or (x['force'] == 'static' and x['equipment'] in ('body only', None)):
        typ = 'time'
    elif x['equipment'] in ('body only', None) or 'Pull' in x['id'] and x['equipment'] == 'other':
        typ = 'reps'
    else:
        typ = 'weight'
    prim = sorted({MUSCLE.get(m, 'outros') for m in x['primaryMuscles']})
    sec = sorted({MUSCLE.get(m, 'outros') for m in x['secondaryMuscles']} - set(prim))
    out.append({
        'id': sid,
        'name': PT.get(x['id'], x['name']),
        'en': x['name'],
        'eq': EQ.get(x['equipment'], 'Outro' if cat != 'cardio' else 'Cardio'),
        'p': prim, 's': sec,
        'type': typ,
        'mech': x['mechanic'] or '',
        'lvl': x['level'],
        'cues': CUES.get(x['id'], []),
        'ins': x['instructions'],
        'pt': x['id'] in PT,
    })
img_lines.append('};')
out.sort(key=lambda e: (not e['pt'], e['name'].lower()))
os.makedirs(os.path.join(ROOT, 'src', 'data'), exist_ok=True)
json.dump(out, open(os.path.join(ROOT, 'src', 'data', 'exercises.json'), 'w'), ensure_ascii=False, separators=(',', ':'))
open(os.path.join(ROOT, 'src', 'data', 'images.ts'), 'w').write('\n'.join(img_lines) + '\n')
print(len(out), 'exercícios;', sum(e['pt'] for e in out), 'com nome PT')
print({k: v for k, v in [(e['id'], e['type']) for e in out] if k in ('plank', 'pushups', 'bicycling_stationary', 'pullups', 'leg_press')})
