import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { DarkTheme, DefaultTheme, NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { ActivityIndicator, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { DialogHost } from './src/components/dialog';
import { Ionicons } from './src/components/ui';
import type { RootStack } from './src/nav';
import BodyEntryScreen from './src/screens/BodyEntryScreen';
import BodyScreen from './src/screens/BodyScreen';
import ExerciseDetailScreen from './src/screens/ExerciseDetailScreen';
import HistoryScreen from './src/screens/HistoryScreen';
import OnboardingScreen from './src/screens/OnboardingScreen';
import ProgressScreen from './src/screens/ProgressScreen';
import RoutineEditScreen from './src/screens/RoutineEditScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import TrainScreen from './src/screens/TrainScreen';
import WorkoutDetailScreen from './src/screens/WorkoutDetailScreen';
import WorkoutScreen from './src/screens/WorkoutScreen';
import { StoreProvider, useStore } from './src/store';
import { useTheme } from './src/theme';

const Stack = createNativeStackNavigator<RootStack>();
const Tab = createBottomTabNavigator();

function Tabs() {
  const t = useTheme();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerStyle: { backgroundColor: t.bg },
        headerShadowVisible: false,
        headerTitleStyle: { color: t.text, fontWeight: '800', fontSize: 20 },
        headerTitleAlign: 'left',
        tabBarActiveTintColor: t.accent,
        tabBarInactiveTintColor: t.faint,
        tabBarStyle: { backgroundColor: t.card, borderTopColor: t.border },
        tabBarIcon: ({ color, size, focused }) => {
          const icons: Record<string, [any, any]> = {
            Treinar: ['barbell', 'barbell-outline'],
            Histórico: ['calendar', 'calendar-outline'],
            Progresso: ['stats-chart', 'stats-chart-outline'],
            Corpo: ['body', 'body-outline'],
          };
          const [on, off] = icons[route.name];
          return <Ionicons name={focused ? on : off} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Treinar" component={TrainScreen} />
      <Tab.Screen name="Histórico" component={HistoryScreen} />
      <Tab.Screen name="Progresso" component={ProgressScreen} />
      <Tab.Screen name="Corpo" component={BodyScreen} />
    </Tab.Navigator>
  );
}

function Root() {
  const t = useTheme();
  const { ready, data } = useStore();
  if (!ready)
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: t.bg }}>
        <ActivityIndicator color={t.accent} />
      </View>
    );
  if (!data.profile) return <OnboardingScreen />;
  const navTheme = t.dark ? DarkTheme : DefaultTheme;
  return (
    <NavigationContainer
      theme={{ ...navTheme, colors: { ...navTheme.colors, background: t.bg, card: t.card, text: t.text, primary: t.accent, border: t.border } }}
    >
      <StatusBar style={t.dark ? 'light' : 'dark'} />
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: t.bg },
          headerShadowVisible: false,
          headerTintColor: t.accent,
          headerTitleStyle: { color: t.text },
          headerBackTitle: 'Voltar',
        }}
      >
        <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
        <Stack.Screen name="Workout" component={WorkoutScreen} options={{ headerShown: false, presentation: 'fullScreenModal', gestureEnabled: false }} />
        <Stack.Screen name="WorkoutDetail" component={WorkoutDetailScreen} options={{ title: 'Treino' }} />
        <Stack.Screen name="RoutineEdit" component={RoutineEditScreen} options={{ title: 'Rotina' }} />
        <Stack.Screen name="ExerciseDetail" component={ExerciseDetailScreen} options={{ title: 'Exercício' }} />
        <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: 'Definições e backup' }} />
        <Stack.Screen name="BodyEntry" component={BodyEntryScreen} options={{ title: 'Registo corporal', presentation: 'modal' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <StoreProvider>
        <Root />
        <DialogHost />
      </StoreProvider>
    </SafeAreaProvider>
  );
}
