# Forja — app de treino pessoal

App nativa (iOS/Android, Expo SDK 57) inspirada no Hevy. Tudo fica guardado **só no telemóvel**: sem conta, sem servidor, funciona offline.

## O que tem

- **Treino ao vivo**: séries com kg × reps (ou só reps / tempo), coluna "Anterior", ✓ que copia os valores da última vez, tipos de série (A = aquecimento, F = falha, D = drop), notas, temporizador de descanso com vibração e ecrã sempre ligado.
- **Progressão dupla**: em cada exercício diz-te se deves subir a carga ou tentar mais reps.
- **Demo visual em cada exercício**: 559 exercícios com animação (posição inicial ↔ final), dicas em PT e instruções. As imagens estão dentro da app, por isso funcionam offline.
- **Rotinas pré-carregadas**: Treino A/B (ginásio) e Casa A/B (halteres + elástico), pensadas para joelhos, pulsos e cotovelo. Dá para editar, duplicar e criar novas.
- **Progresso**: "Scouter de força" (radar com a evolução do 1RM por grupo muscular e power level), radar de distribuição muscular (comparação com o período anterior), mapa muscular frente/costas, volume semanal, e por exercício: gráfico de 1RM/carga/volume, recordes e melhor carga por nº de reps.
- **Corpo**: registo semanal da balança (peso, gordura, água, músculo, osso), massa magra calculada, meta de +10 kg, silhueta com medidas (peito, cintura, braço esq./dir., coxa) e gráficos.
- **Backup**: exportar/importar os dados em Definições.
- Tema claro/escuro automático.

## Experimentar já (Expo Go)

1. Instala o [Node.js](https://nodejs.org) (versão 20 ou mais recente) no computador.
2. Instala a app **Expo Go** no telemóvel (App Store / Play Store).
3. Na pasta do projeto:
   ```bash
   npm install
   npx expo start
   ```
4. Lê o QR code com a câmara (iPhone) ou com a Expo Go (Android). Computador e telemóvel na mesma rede Wi-Fi.

Nota: com a Expo Go o computador tem de estar ligado a servir a app. Para ficar 100% no telemóvel, instala a versão final (abaixo).

## Instalar de vez no telemóvel

Precisas de uma conta gratuita em [expo.dev](https://expo.dev).

**Android (grátis, APK):**
```bash
npx eas-cli@latest login
npx eas-cli@latest build -p android --profile preview
```
No fim recebes um link para descarregar o `.apk` e instalá-lo diretamente.

**iPhone:** o iOS só deixa instalar apps fora da App Store com conta Apple Developer (99 €/ano):
```bash
npx eas-cli@latest build -p ios --profile preview
```
Sem essa conta, a alternativa é usar a Expo Go, ou instalar com Xcode num Mac (a app expira ao fim de 7 dias).

## Estrutura

```
App.tsx                    navegação (separadores + ecrãs)
src/store.tsx              dados, cálculos de volume / 1RM / recordes, guardar no telemóvel
src/data/routines.ts       rotinas A/B e Casa
src/data/exercises.json    base de exercícios (gerada por tools/gen.py)
src/components/            gráficos (linha, barras, radar), mapa muscular, demo, seletor
src/screens/               Treinar, Treino, Histórico, Progresso, Corpo, etc.
assets/ex/                 imagens dos exercícios (otimizadas)
```

Imagens e instruções dos exercícios: [free-exercise-db](https://github.com/yuhonas/free-exercise-db) (domínio público).
