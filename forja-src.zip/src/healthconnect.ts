import { Platform } from 'react-native';
import type { Workout } from './store';

/**
 * Ligação opcional ao Health Connect (Android): cada treino da Forja é guardado como
 * uma sessão de exercício "Treino de força". Outras apps (ex.: Chama) podem lê-la.
 * Usa o id do treino como clientRecordId, por isso reenviar atualiza em vez de duplicar.
 */
type HC = typeof import('react-native-health-connect');

function lib(): HC | null {
  if (Platform.OS !== 'android') return null;
  try {
    return require('react-native-health-connect') as HC;
  } catch {
    return null;
  }
}

export type HcState = 'unsupported' | 'missing' | 'update' | 'ready';

export async function hcStatus(): Promise<HcState> {
  const hc = lib();
  if (!hc) return 'unsupported';
  try {
    const s = await hc.getSdkStatus();
    if (s === hc.SdkAvailabilityStatus.SDK_AVAILABLE) return 'ready';
    if (s === hc.SdkAvailabilityStatus.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED) return 'update';
    return 'missing';
  } catch {
    return 'unsupported';
  }
}

/** Pede a permissão de escrita de sessões de exercício. true se concedida. */
export async function hcEnable(): Promise<boolean> {
  const hc = lib();
  if (!hc) return false;
  try {
    if (!(await hc.initialize())) return false;
    const granted = await hc.requestPermission([{ accessType: 'write', recordType: 'ExerciseSession' }]);
    return granted.some((p) => 'recordType' in p && p.recordType === 'ExerciseSession' && p.accessType === 'write');
  } catch {
    return false;
  }
}

export async function hcHasPermission(): Promise<boolean> {
  const hc = lib();
  if (!hc) return false;
  try {
    if (!(await hc.initialize())) return false;
    const granted = await hc.getGrantedPermissions();
    return granted.some((p) => 'recordType' in p && p.recordType === 'ExerciseSession' && p.accessType === 'write');
  } catch {
    return false;
  }
}

function toRecord(w: Workout, sets: number, volume: number) {
  const start = w.start;
  const end = w.end && w.end > start ? w.end : start + 45 * 60 * 1000;
  return {
    recordType: 'ExerciseSession' as const,
    exerciseType: 70, // ExerciseType.STRENGTH_TRAINING
    title: w.name,
    notes: `${sets} séries · ${Math.round(volume)} kg de volume`,
    startTime: new Date(start).toISOString(),
    endTime: new Date(end).toISOString(),
    metadata: { clientRecordId: w.id, clientRecordVersion: Date.now() },
  };
}

/** Envia (ou atualiza) treinos. Devolve quantos foram enviados. */
export async function hcWrite(ws: Workout[], stats: (w: Workout) => { sets: number; volume: number }): Promise<number> {
  const hc = lib();
  if (!hc || !ws.length) return 0;
  if (!(await hc.initialize())) return 0;
  let sent = 0;
  for (let i = 0; i < ws.length; i += 40) {
    const chunk = ws.slice(i, i + 40).map((w) => {
      const s = stats(w);
      return toRecord(w, s.sets, s.volume);
    });
    await hc.insertRecords(chunk);
    sent += chunk.length;
  }
  return sent;
}

export async function hcDelete(workoutId: string): Promise<void> {
  const hc = lib();
  if (!hc) return;
  try {
    if (!(await hc.initialize())) return;
    await hc.deleteRecordsByUuids('ExerciseSession', [], [workoutId]);
  } catch {
    /* melhor esforço */
  }
}

export function hcOpenSettings() {
  try {
    lib()?.openHealthConnectSettings();
  } catch {
    /* ignora */
  }
}
