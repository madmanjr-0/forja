import type { Routine } from '../store';

type Row = [id: string, sets: number, repMin: number, repMax: number, rest: number];

const mk = (id: string, name: string, place: 'gym' | 'home', note: string, rows: Row[]): Routine => ({
  id,
  name,
  place,
  note,
  exercises: rows.map(([exerciseId, sets, repMin, repMax, restSec]) => ({ exerciseId, sets, repMin, repMax, restSec })),
});

/** Full body A/B 3x/semana + versões casa. Escolhas pensadas para joelhos, pulsos e cotovelo. */
export const DEFAULT_ROUTINES: Routine[] = [
  mk('r_gym_a', 'Treino A · Ginásio', 'gym', 'Full body com ênfase em peito e costas. Usa straps nas remadas.', [
    ['leg_press', 3, 8, 12, 120],
    ['incline_dumbbell_bench_with_palms_facing_in', 3, 8, 12, 120],
    ['seated_cable_rows', 3, 10, 12, 90],
    ['stiff_legged_dumbbell_deadlift', 3, 8, 10, 120],
    ['side_lateral_raise', 3, 12, 15, 60],
    ['ez_bar_curl', 3, 10, 12, 60],
    ['triceps_pushdown_rope_attachment', 2, 12, 15, 60],
  ]),
  mk('r_gym_b', 'Treino B · Ginásio', 'gym', 'Full body com ênfase em ombros e braços. Chest press em vez de supino com barra (cotovelo).', [
    ['barbell_hip_thrust', 3, 8, 12, 120],
    ['machine_bench_press', 3, 8, 12, 120],
    ['close_grip_front_lat_pulldown', 3, 8, 12, 90],
    ['seated_leg_curl', 3, 10, 12, 90],
    ['seated_dumbbell_press', 3, 8, 10, 90],
    ['face_pull', 2, 15, 20, 60],
    ['hammer_curls', 3, 10, 12, 60],
    ['cable_crunch', 2, 12, 15, 60],
  ]),
  mk('r_home_a', 'Casa A · Halteres', 'home', 'Para os dias de preguiça. Halteres + elástico.', [
    ['goblet_squat', 3, 10, 15, 90],
    ['pushups', 3, 8, 15, 90],
    ['one_arm_dumbbell_row', 3, 10, 12, 60],
    ['stiff_legged_dumbbell_deadlift', 3, 10, 12, 90],
    ['side_lateral_raise', 3, 12, 15, 60],
    ['dumbbell_bicep_curl', 3, 10, 12, 60],
    ['band_skull_crusher', 2, 12, 15, 60],
  ]),
  mk('r_home_b', 'Casa B · Halteres', 'home', 'Afundo atrás é mais suave para os joelhos.', [
    ['single_leg_glute_bridge', 3, 10, 15, 60],
    ['dumbbell_floor_press', 3, 8, 12, 90],
    ['bent_over_two_dumbbell_row_with_palms_in', 3, 10, 12, 90],
    ['dumbbell_rear_lunge', 3, 8, 10, 90],
    ['dumbbell_shoulder_press', 3, 8, 12, 90],
    ['band_pull_apart', 2, 15, 20, 45],
    ['hammer_curls', 3, 10, 12, 60],
    ['plank', 3, 30, 45, 45],
  ]),
];
