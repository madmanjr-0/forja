import RAW from './exercises.json';

export type ExType = 'weight' | 'reps' | 'time';

export type Exercise = {
  id: string;
  name: string;
  en: string;
  eq: string;
  p: string[]; // músculos primários
  s: string[]; // músculos secundários
  type: ExType;
  mech: string;
  lvl: string;
  cues: string[];
  ins: string[];
  pt: boolean;
  cat?: string;
  custom?: boolean;
};

export const BASE_EXERCISES: Exercise[] = RAW as Exercise[];


export const EQUIPMENT = ['Barra', 'Halteres', 'Polia', 'Máquina', 'Barra W', 'Kettlebell', 'Elástico', 'Peso corporal', 'Cardio', 'Outro'];

const norm = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

// Sinónimos PT → termos em inglês, para encontrar exercícios que ainda só têm nome em inglês.
const SYN: Record<string, string[]> = {
  supino: ['bench press', 'press'], agachamento: ['squat'], remada: ['row'], puxada: ['pulldown', 'pull'],
  elevacao: ['raise', 'pull-up', 'pullup'], elevacoes: ['pull-up', 'pullup', 'chin'], afundo: ['lunge'], afundos: ['lunge'],
  flexao: ['push-up', 'pushup', 'curl'], flexoes: ['push-up', 'pushup'], prancha: ['plank'], ponte: ['bridge'],
  peso: ['deadlift', 'weight'], morto: ['deadlift'], abertura: ['fly', 'flye'], aberturas: ['fly', 'flye'],
  biceps: ['curl', 'bicep'], triceps: ['tricep', 'extension', 'pushdown', 'dip'], ombro: ['shoulder', 'delt'], ombros: ['shoulder', 'delt'],
  peito: ['chest', 'pec'], costas: ['back', 'lat', 'row'], perna: ['leg'], pernas: ['leg'], gemeos: ['calf'], gluteo: ['glute', 'hip'], gluteos: ['glute', 'hip'],
  abdominal: ['crunch', 'ab', 'sit-up'], abdominais: ['crunch', 'ab', 'sit-up'], coxa: ['thigh', 'leg'], anca: ['hip'],
  halter: ['dumbbell'], halteres: ['dumbbell'], barra: ['barbell', 'bar'], polia: ['cable'], cabo: ['cable'], maquina: ['machine', 'lever'],
  elastico: ['band'], kettlebell: ['kettlebell'], corda: ['rope'], banco: ['bench'], inclinado: ['incline'], declinado: ['decline'],
  sentado: ['seated'], 'em pe': ['standing'], deitado: ['lying'], unilateral: ['one-arm', 'single', 'one-leg', 'one arm'],
  martelo: ['hammer'], encolhimento: ['shrug'], alongamento: ['stretch'], bicicleta: ['bicycl', 'bike'], corrida: ['run', 'jog'],
  salto: ['jump'], saltos: ['jump'], frente: ['front'], lateral: ['lateral', 'side'], posterior: ['rear', 'reverse'], fechada: ['close-grip', 'close'],
  larga: ['wide'], militar: ['military', 'overhead'], torcao: ['twist'], rotacao: ['rotation'], pulso: ['wrist'], antebraco: ['forearm', 'wrist'],
};

export function searchExercises(list: Exercise[], q: string, muscle?: string | null, eq?: string | null): Exercise[] {
  const nq = norm(q.trim());
  const words = nq.split(/\s+/).filter(Boolean);
  return list.filter((e) => {
    if (muscle && !e.p.includes(muscle)) return false;
    if (eq && e.eq !== eq) return false;
    if (!words.length) return true;
    const hay = norm(e.name + ' ' + e.en + ' ' + e.eq);
    return words.every((w) => hay.includes(w) || (SYN[w] ?? []).some((s) => hay.includes(s)));
  });
}
