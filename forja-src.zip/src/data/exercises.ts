import RAW from './exercises.json';

export type ExType = 'weight' | 'reps' | 'time';

export type Exercise = {
  id: string;
  name: string;
  en: string;
  eq: string;
  p: string[]; // músculos primários
  s: string[]; // músculos secundários
  type: ExType;
  mech: string;
  lvl: string;
  cues: string[];
  ins: string[];
  pt: boolean;
  custom?: boolean;
};

export const BASE_EXERCISES: Exercise[] = RAW as Exercise[];


export const EQUIPMENT = ['Barra', 'Halteres', 'Polia', 'Máquina', 'Barra W', 'Kettlebell', 'Elástico', 'Peso corporal', 'Cardio', 'Outro'];

const norm = (s: string) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

export function searchExercises(list: Exercise[], q: string, muscle?: string | null, eq?: string | null): Exercise[] {
  const nq = norm(q.trim());
  const words = nq.split(/\s+/).filter(Boolean);
  return list.filter((e) => {
    if (muscle && !e.p.includes(muscle)) return false;
    if (eq && e.eq !== eq) return false;
    if (!words.length) return true;
    const hay = norm(e.name + ' ' + e.en + ' ' + e.eq);
    return words.every((w) => hay.includes(w));
  });
}
