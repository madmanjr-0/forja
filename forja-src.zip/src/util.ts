export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

/** Aceita vírgula ou ponto como separador decimal. */
export function parseNum(s: string): number | null {
  const t = s.replace(',', '.').trim();
  if (t === '' || t === '.') return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

export function fmtNum(n: number | null | undefined, digits = 1): string {
  if (n == null) return '';
  const r = Math.round(n * 10 ** digits) / 10 ** digits;
  return String(r).replace('.', ',');
}

export function fmtKg(n: number): string {
  if (n >= 10000) return `${fmtNum(n / 1000, 1)} t`;
  return `${Math.round(n).toLocaleString('pt-PT')} kg`;
}

/** 1RM estimado (Epley), só com reps ≤ 12 para ser fiável. */
export function e1rm(kg: number, reps: number): number {
  if (!kg || !reps) return 0;
  if (reps === 1) return kg;
  return kg * (1 + Math.min(reps, 12) / 30);
}

const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];

export function fmtDate(ts: number, withWeekday = true): string {
  const d = new Date(ts);
  const base = `${d.getDate()} ${MESES[d.getMonth()]}`;
  const y = d.getFullYear() !== new Date().getFullYear() ? ` ${d.getFullYear()}` : '';
  return withWeekday ? `${DIAS[d.getDay()]}, ${base}${y}` : `${base}${y}`;
}

export function fmtShort(ts: number): string {
  const d = new Date(ts);
  return `${d.getDate()}/${d.getMonth() + 1}`;
}

export function fmtDuration(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, '0')}min`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function fmtSecs(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function todayISO(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function isoToTs(iso: string): number {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1, 12).getTime();
}

/** Início (segunda-feira 00:00) da semana de um timestamp. */
export function weekStart(ts: number): number {
  const d = new Date(ts);
  const day = (d.getDay() + 6) % 7;
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - day);
  return d.getTime();
}

export const DAY = 86400000;
