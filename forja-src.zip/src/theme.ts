import { useColorScheme } from 'react-native';

export type Theme = {
  dark: boolean;
  bg: string;
  card: string;
  card2: string;
  border: string;
  text: string;
  sub: string;
  faint: string;
  accent: string;
  accentSoft: string;
  onAccent: string;
  good: string;
  goodSoft: string;
  warn: string;
  bad: string;
  gold: string;
};

const light: Theme = {
  dark: false,
  bg: '#F4F5F7',
  card: '#FFFFFF',
  card2: '#F0F2F5',
  border: '#E3E6EA',
  text: '#111418',
  sub: '#5F6873',
  faint: '#9AA3AD',
  accent: '#1E7BF2',
  accentSoft: '#E3EEFE',
  onAccent: '#FFFFFF',
  good: '#1FA463',
  goodSoft: '#DDF4E8',
  warn: '#E8A21A',
  bad: '#E5484D',
  gold: '#F2B01E',
};

const dark: Theme = {
  dark: true,
  bg: '#0E1013',
  card: '#181B20',
  card2: '#22262C',
  border: '#2A2F36',
  text: '#F2F4F6',
  sub: '#A1A9B3',
  faint: '#6B737D',
  accent: '#3C8DFF',
  accentSoft: '#1A2B45',
  onAccent: '#FFFFFF',
  good: '#2FBF77',
  goodSoft: '#16352A',
  warn: '#F0B23A',
  bad: '#FF6369',
  gold: '#F5C04A',
};

export function useTheme(): Theme {
  return useColorScheme() === 'dark' ? dark : light;
}

export const MUSCLE_LABEL: Record<string, string> = {
  peito: 'Peito',
  costas: 'Costas',
  trapezio: 'Trapézio',
  lombar: 'Lombar',
  ombros: 'Ombros',
  biceps: 'Bíceps',
  triceps: 'Tríceps',
  antebracos: 'Antebraços',
  abdominais: 'Abdominais',
  quadriceps: 'Quadríceps',
  isquios: 'Isquiotibiais',
  gluteos: 'Glúteos',
  gemeos: 'Gémeos',
  adutores: 'Adutores',
  outros: 'Outros',
};

/** Eixos do radar (estilo "scouter"). */
export const RADAR_AXES: { key: string; label: string; muscles: string[] }[] = [
  { key: 'peito', label: 'Peito', muscles: ['peito'] },
  { key: 'costas', label: 'Costas', muscles: ['costas', 'trapezio', 'lombar'] },
  { key: 'ombros', label: 'Ombros', muscles: ['ombros'] },
  { key: 'bracos', label: 'Braços', muscles: ['biceps', 'triceps', 'antebracos'] },
  { key: 'core', label: 'Core', muscles: ['abdominais'] },
  { key: 'pernas', label: 'Pernas', muscles: ['quadriceps', 'isquios', 'gluteos', 'gemeos', 'adutores'] },
];
