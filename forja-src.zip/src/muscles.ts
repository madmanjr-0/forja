import type { Exercise } from './data/exercises';
import { isWorking, Workout } from './store';

/** Músculos detalhados usados no mapa (o ombro divide-se em frontal, lateral e posterior). */
export const DETAIL_LABEL: Record<string, string> = {
  peito: 'Peito',
  ombro_frente: 'Ombro frontal',
  ombro_lado: 'Ombro lateral',
  ombro_tras: 'Ombro posterior',
  biceps: 'Bíceps',
  triceps: 'Tríceps',
  antebracos: 'Antebraços',
  abdominais: 'Abdominais',
  obliquos: 'Oblíquos',
  trapezio: 'Trapézio',
  costas: 'Dorsais',
  lombar: 'Lombar',
  gluteos: 'Glúteos',
  quadriceps: 'Quadríceps',
  isquios: 'Isquiotibiais',
  adutores: 'Adutores',
  gemeos: 'Gémeos',
};

const has = (txt: string, words: string[]) => words.some((w) => txt.includes(w));

const REAR = ['rear', 'reverse fly', 'reverse flye', 'reverse pec', 'face pull', 'posterior', 'bent over lateral', 'bent-over lateral', 'bent over dumbbell rear', 'band pull apart', 'pull-apart', 'pull apart', 'bent over low-pulley', 'bent-over low-pulley'];
const SIDE = ['lateral raise', 'side lateral', 'side raise', 'upright row', 'elevação lateral', 'elevações laterais', 'y-raise', 'lu raise', 'cable lateral', 'lateral delt'];
const PRESS = ['shoulder press', 'military', 'overhead press', 'arnold', 'push press', 'press overhead', 'desenvolvimento', 'seated dumbbell press', 'standing dumbbell press', 'landmine press', 'pike push', 'handstand'];
const OBLIQUE = ['oblique', 'oblíquo', 'twist', 'side bend', 'woodchop', 'wood chop', 'russian', 'side plank', 'prancha lateral', 'windmill', 'side jackknife', 'bicycle', 'bicicleta', 'pallof'];

/** Expande os músculos de um exercício para a versão detalhada (cabeças do ombro, oblíquos). */
export function detailMuscles(ex: Exercise): { p: string[]; s: string[] } {
  const txt = `${ex.en ?? ''} ${ex.name}`.toLowerCase();
  const backDay = ex.p.some((m) => m === 'costas' || m === 'trapezio');
  const shoulderHeads = (primary: boolean): { p: string[]; s: string[] } => {
    if (has(txt, REAR)) return primary ? { p: ['ombro_tras'], s: [] } : { p: [], s: ['ombro_tras'] };
    if (has(txt, SIDE)) return primary ? { p: ['ombro_lado'], s: ['ombro_frente'] } : { p: [], s: ['ombro_lado'] };
    if (has(txt, PRESS) || (primary && txt.includes('press'))) return primary ? { p: ['ombro_frente'], s: ['ombro_lado'] } : { p: [], s: ['ombro_frente'] };
    if (backDay) return primary ? { p: ['ombro_tras'], s: [] } : { p: [], s: ['ombro_tras'] };
    return primary ? { p: ['ombro_frente'], s: [] } : { p: [], s: ['ombro_frente'] };
  };
  const p: string[] = [];
  const s: string[] = [];
  for (const m of ex.p) {
    if (m === 'ombros') {
      const h = shoulderHeads(true);
      p.push(...h.p);
      s.push(...h.s);
    } else p.push(m);
  }
  for (const m of ex.s) {
    if (m === 'ombros') s.push(...shoulderHeads(false).s);
    else s.push(m);
  }
  if (has(txt, OBLIQUE)) (ex.p.includes('abdominais') ? p : s).push('obliquos');
  else if (ex.p.includes('abdominais')) s.push('obliquos');
  const uniq = (a: string[]) => [...new Set(a)];
  const P = uniq(p);
  return { p: P, s: uniq(s).filter((m) => !P.includes(m)) };
}

/** Séries por músculo detalhado (principal = 1, secundário = 0,5). */
export function detailSets(workouts: Workout[], exById: (id: string) => Exercise | undefined): Record<string, number> {
  const m: Record<string, number> = {};
  for (const w of workouts)
    for (const e of w.exercises) {
      const ex = exById(e.exerciseId);
      if (!ex) continue;
      const n = e.sets.filter(isWorking).length;
      if (!n) continue;
      const d = detailMuscles(ex);
      d.p.forEach((x) => (m[x] = (m[x] ?? 0) + n));
      d.s.forEach((x) => (m[x] = (m[x] ?? 0) + n * 0.5));
    }
  return m;
}
