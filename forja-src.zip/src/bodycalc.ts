// Cálculos corporais. Fórmulas publicadas e usadas em estudos; são estimativas, não diagnósticos.
import type { BodyEntry, Profile } from './store';

export type Sex = 'm' | 'f';

export function ageNow(p: Profile): number {
  const years = (Date.now() - p.setAt) / (365.25 * 86400000);
  return Math.floor(p.age + years);
}

export function bmi(weight: number, heightCm: number): number {
  const h = heightCm / 100;
  return weight / (h * h);
}

export function bmiClass(v: number): { label: string; tone: 'good' | 'warn' | 'bad' } {
  if (v < 18.5) return { label: 'Abaixo do peso', tone: 'warn' };
  if (v < 25) return { label: 'Peso normal', tone: 'good' };
  if (v < 30) return { label: 'Excesso de peso', tone: 'warn' };
  return { label: 'Obesidade', tone: 'bad' };
}

/** Metabolismo basal — Mifflin-St Jeor (1990). */
export function bmrMifflin(weight: number, heightCm: number, age: number, sex: Sex): number {
  return 10 * weight + 6.25 * heightCm - 5 * age + (sex === 'm' ? 5 : -161);
}

/** Metabolismo basal — Katch-McArdle (usa massa magra; mais preciso quando se sabe a % de gordura). */
export function bmrKatch(leanKg: number): number {
  return 370 + 21.6 * leanKg;
}

export const ACTIVITY: { k: number; label: string; hint: string }[] = [
  { k: 1.2, label: 'Sedentário', hint: 'Escritório, sem treino' },
  { k: 1.375, label: 'Leve', hint: '1–2 treinos/semana' },
  { k: 1.55, label: 'Moderado', hint: '3–4 treinos/semana' },
  { k: 1.725, label: 'Alto', hint: '5–6 treinos/semana' },
];

/** % de gordura estimada só pelo IMC — Deurenberg (1991). Muito grosseira em quem treina. */
export function bfDeurenberg(bmiV: number, age: number, sex: Sex): number {
  return 1.2 * bmiV + 0.23 * age - 10.8 * (sex === 'm' ? 1 : 0) - 5.4;
}

/** % de gordura — método da Marinha dos EUA (Hodgdon & Beckett, 1984). Medidas em cm. */
export function bfNavy(sex: Sex, heightCm: number, waist?: number, neck?: number, hip?: number): number | null {
  const inch = (cm: number) => cm / 2.54;
  if (!waist || !neck) return null;
  if (sex === 'm') {
    const d = inch(waist) - inch(neck);
    if (d <= 0) return null;
    return 86.01 * Math.log10(d) - 70.041 * Math.log10(inch(heightCm)) + 36.76;
  }
  if (!hip) return null;
  const d = inch(waist) + inch(hip) - inch(neck);
  if (d <= 0) return null;
  return 163.205 * Math.log10(d) - 97.684 * Math.log10(inch(heightCm)) - 78.387;
}

/** Relative Fat Mass — Woolcott & Bergman (2018). Só precisa de altura e cintura. */
export function bfRFM(sex: Sex, heightCm: number, waist?: number): number | null {
  if (!waist) return null;
  return (sex === 'm' ? 64 : 76) - 20 * (heightCm / waist);
}

/** Índice de massa magra (FFMI) e versão normalizada para 1,80 m (Kouri et al., 1995). */
export function ffmi(leanKg: number, heightCm: number): { raw: number; norm: number } {
  const h = heightCm / 100;
  const raw = leanKg / (h * h);
  return { raw, norm: raw + 6.1 * (1.8 - h) };
}

export function bfClass(bf: number, sex: Sex): string {
  const t = sex === 'm' ? [6, 14, 18, 25] : [14, 21, 25, 32];
  if (bf < t[0]) return 'Essencial';
  if (bf < t[1]) return 'Atlético';
  if (bf < t[2]) return 'Em forma';
  if (bf < t[3]) return 'Médio';
  return 'Elevado';
}

export function ffmiClass(n: number): string {
  if (n < 18) return 'Abaixo da média';
  if (n < 20) return 'Média';
  if (n < 22) return 'Acima da média';
  if (n < 23.5) return 'Excelente';
  return 'Topo natural';
}

export type Derived = {
  bmi?: number;
  bfScale?: number;
  bfNavy?: number | null;
  bfRFM?: number | null;
  bfBest?: number;
  bfSource?: string;
  lean?: number;
  fatKg?: number;
  muscleKg?: number;
  ffmi?: { raw: number; norm: number };
  whtr?: number; // cintura / altura
  whr?: number; // cintura / anca
  vtaper?: number; // ombros / cintura
  armDiff?: number; // % diferença entre braços
  thighDiff?: number;
  bmr?: number;
  tdee?: number;
};

/** Junta tudo o que dá para tirar de um registo: dados da balança + cálculos pelas medidas. */
export function derive(e: BodyEntry, p: Profile): Derived {
  const d: Derived = {};
  const age = ageNow(p);
  const w = e.weight;
  if (w) d.bmi = bmi(w, p.heightCm);
  if (e.fat != null) d.bfScale = e.fat;
  d.bfNavy = bfNavy(p.sex, p.heightCm, e.waist, e.neck, e.hip);
  d.bfRFM = bfRFM(p.sex, p.heightCm, e.waist);
  // Preferência: Marinha (medidas) > balança > RFM
  if (d.bfNavy != null) {
    d.bfBest = d.bfNavy;
    d.bfSource = 'medidas (Marinha EUA)';
  } else if (d.bfScale != null) {
    d.bfBest = d.bfScale;
    d.bfSource = 'balança';
  } else if (d.bfRFM != null) {
    d.bfBest = d.bfRFM;
    d.bfSource = 'cintura (RFM)';
  }
  if (w && d.bfBest != null) {
    d.fatKg = (w * d.bfBest) / 100;
    d.lean = w - d.fatKg;
    d.ffmi = ffmi(d.lean, p.heightCm);
  }
  if (w && e.musclePct != null) d.muscleKg = (w * e.musclePct) / 100;
  if (e.waist) d.whtr = e.waist / p.heightCm;
  if (e.waist && e.hip) d.whr = e.waist / e.hip;
  if (e.waist && e.shoulders) d.vtaper = e.shoulders / e.waist;
  if (e.armL && e.armR) d.armDiff = (Math.abs(e.armL - e.armR) / Math.max(e.armL, e.armR)) * 100;
  if (e.thighL && e.thighR) d.thighDiff = (Math.abs(e.thighL - e.thighR) / Math.max(e.thighL, e.thighR)) * 100;
  if (w) {
    d.bmr = d.lean ? bmrKatch(d.lean) : bmrMifflin(w, p.heightCm, age, p.sex);
    d.tdee = d.bmr * p.activity;
  }
  return d;
}
