import { hcDelete, hcWrite } from './healthconnect';
import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { BASE_EXERCISES, Exercise } from './data/exercises';
import { DEFAULT_ROUTINES } from './data/routines';
import { e1rm, uid } from './util';

// ---------- Tipos ----------
export type SetKind = 'normal' | 'warmup' | 'drop' | 'failure';

export type SetPart = { kg: number | null; reps: number | null };

export type WSet = {
  id: string;
  kind: SetKind;
  kg: number | null;
  reps: number | null;
  secs: number | null;
  done: boolean;
  /** Cargas extra feitas na MESMA série, sem descanso (drop set, aquecimento seguido, etc.). */
  parts?: SetPart[];
};

export type WExercise = {
  id: string;
  exerciseId: string;
  restSec: number;
  repMin?: number;
  repMax?: number;
  note?: string;
  /** Exercícios seguidos com o mesmo `group` formam uma super série (A1, A2…). */
  group?: string;
  sets: WSet[];
};

export type Workout = {
  id: string;
  name: string;
  routineId?: string;
  start: number;
  end?: number;
  note?: string;
  exercises: WExercise[];
};

export type RoutineExercise = { exerciseId: string; sets: number; repMin: number; repMax: number; restSec: number; group?: string };
export type Routine = { id: string; name: string; place: 'gym' | 'home'; note?: string; exercises: RoutineExercise[] };

export type BodyEntry = {
  id: string;
  date: string; // YYYY-MM-DD
  // Balança de bioimpedância
  weight?: number;
  fat?: number; // % gordura
  water?: number; // % hidratação
  musclePct?: number; // % músculo
  bonePct?: number; // % massa óssea
  kcal?: number; // kcal recomendadas pela balança
  visceral?: number; // gordura visceral (índice)
  // Medidas (cm)
  neck?: number;
  shoulders?: number;
  chest?: number;
  waist?: number;
  hip?: number;
  armL?: number;
  armR?: number;
  thighL?: number;
  thighR?: number;
  calf?: number;
};

export type Profile = { name?: string; age: number; sex: 'm' | 'f'; heightCm: number; activity: number; setAt: number };

export type Settings = { defaultRest: number; leanGoalKg: number; partsV?: number; ssV?: number; hcSync?: boolean };

export type AppData = {
  version: 1;
  routines: Routine[];
  workouts: Workout[];
  body: BodyEntry[];
  custom: Exercise[];
  active: Workout | null;
  settings: Settings;
  profile: Profile | null;
};

const KEY = 'forja:data:v1';

const initial: AppData = {
  version: 1,
  routines: DEFAULT_ROUTINES,
  workouts: [],
  body: [],
  custom: [],
  active: null,
  settings: { defaultRest: 90, leanGoalKg: 10 },
  profile: null,
};

// ---------- Cálculos ----------
export const isWorking = (s: WSet) => s.done && s.kind !== 'warmup';

export function setVolume(s: WSet): number {
  if (!isWorking(s)) return 0;
  return [s, ...(s.parts ?? [])].reduce((a, p) => a + (p.kg && p.reps ? p.kg * p.reps : 0), 0);
}

/** Cada carga de uma série (principal + partes) como uma "mini-série" para cálculos de recordes. */
export function flatLoads(sets: WSet[]): WSet[] {
  const out: WSet[] = [];
  for (const s of sets) {
    out.push(s);
    for (const p of s.parts ?? []) out.push({ ...s, kg: p.kg, reps: p.reps, parts: undefined });
  }
  return out;
}

export function setLabel(s: WSet, type: 'weight' | 'reps' | 'time' = 'weight'): string {
  const one = (kg: number | null, reps: number | null) =>
    type === 'reps' ? `${kg ? `+${String(kg).replace('.', ',')} kg × ` : ''}${reps ?? 0}` : `${String(kg ?? 0).replace('.', ',')} × ${reps ?? 0}`;
  if (type === 'time') return `${s.secs ?? 0} s`;
  return [one(s.kg, s.reps), ...(s.parts ?? []).map((p) => one(p.kg, p.reps))].join(' + ');
}

// ---------- Super séries ----------
export type SSInfo = { letter: string; idx: number; size: number; first: boolean; last: boolean; group: string };

/** Etiquetas A1/A2, B1/B2… para exercícios seguidos com o mesmo `group` (2 ou mais). */
export function supersets<T extends { group?: string }>(list: T[]): (SSInfo | null)[] {
  const out: (SSInfo | null)[] = list.map(() => null);
  let letter = 0;
  for (let i = 0; i < list.length; ) {
    const g = list[i].group;
    let j = i;
    while (g && j + 1 < list.length && list[j + 1].group === g) j++;
    if (g && j > i) {
      const L = String.fromCharCode(65 + (letter++ % 26));
      for (let k = i; k <= j; k++) out[k] = { letter: L, idx: k - i + 1, size: j - i + 1, first: k === i, last: k === j, group: g };
    }
    i = j + 1;
  }
  return out;
}

/** "Modo" de um exercício num treino: sozinho ou em super série. As cargas só se comparam dentro do mesmo modo. */
export type Mode = 'solo' | 'ss';
export function modeOf(w: Workout, e: WExercise): Mode {
  if (!e.group) return 'solo';
  const i = w.exercises.indexOf(e);
  const ss = supersets(w.exercises)[i];
  return ss ? 'ss' : 'solo';
}

/** Parceiros de super série de um exercício nesse treino (para mostrar "c/ martelo"). */
export function partnersOf(w: Workout, e: WExercise): string[] {
  if (!e.group) return [];
  return w.exercises.filter((x) => x !== e && x.group === e.group).map((x) => x.exerciseId);
}

/** Migração: séries marcadas como "drop" passam a ser carga extra da série anterior; mais as séries que o Marcos fez seguidas. */
const MERGE_PAIRS: [string, string][] = [
  ['mv8gnlbxn7cku2', 'mv8gnlbxhepoyk'],
  ['mv8gnlbxz0jds0', 'mv8gnlbx8xrn8y'],
  ['mv8gnlbxsqh1j7', 'mv8ihka7zhlfsk'],
];
function migrateParts(d: AppData): AppData {
  const fix = (w: Workout): Workout => ({
    ...w,
    exercises: w.exercises.map((e) => {
      const out: WSet[] = [];
      for (const st of e.sets) {
        const prev = out[out.length - 1];
        const pair = MERGE_PAIRS.find((p) => p[1] === st.id && prev?.id === p[0]);
        if (prev && (st.kind === 'drop' || pair)) {
          out[out.length - 1] = { ...prev, parts: [...(prev.parts ?? []), { kg: st.kg, reps: st.reps }] };
        } else out.push(st);
      }
      return { ...e, sets: out };
    }),
  });
  return { ...d, workouts: d.workouts.map(fix), settings: { ...d.settings, partsV: 1 } };
}

/** Migração: o treino de casa de 18/10 foi feito em super séries (estava nas notas). */
const SS_FIX: Record<string, string[][]> = {
  mvee8qlgh3hgnx: [
    ['mvee9bjb2fj2rv', 'mveeb0ash97vqo', 'mveeb0as52tz3k'],
    ['mveedic1fmj3yl', 'mveedic1byvjwe'],
    ['mveecct3zojfi9', 'mveedic1ginhap'],
  ],
};
function migrateSupersets(d: AppData): AppData {
  const workouts = d.workouts.map((w) => {
    const groups = SS_FIX[w.id];
    if (!groups) return w;
    const gOf = new Map<string, string>();
    groups.forEach((g, i) => g.forEach((id) => gOf.set(id, `ss_${w.id}_${i}`)));
    return { ...w, exercises: w.exercises.map((e) => (gOf.has(e.id) ? { ...e, group: gOf.get(e.id) } : e)) };
  });
  return { ...d, workouts, settings: { ...d.settings, ssV: 1 } };
}
const migrate = (d: AppData): AppData => {
  let x = d.settings.partsV ? d : migrateParts(d);
  if (!x.settings.ssV) x = migrateSupersets(x);
  return x;
};

export function workoutVolume(w: Workout): number {
  return w.exercises.reduce((a, e) => a + e.sets.reduce((b, s) => b + setVolume(s), 0), 0);
}

export function workoutSets(w: Workout): number {
  return w.exercises.reduce((a, e) => a + e.sets.filter(isWorking).length, 0);
}

/** Envia treinos ao Health Connect (melhor esforço; nunca bloqueia nem falha a app). */
export function syncHc(ws: Workout[]): Promise<number> {
  return hcWrite(ws, (w) => ({ sets: workoutSets(w), volume: workoutVolume(w) })).catch(() => 0);
}

export type Bests = { maxKg: number; e1rm: number; setVol: number; maxReps: number; maxSecs: number };
const emptyBests = (): Bests => ({ maxKg: 0, e1rm: 0, setVol: 0, maxReps: 0, maxSecs: 0 });

export function bestsOf(sets: WSet[]): Bests {
  const b = emptyBests();
  for (const s of flatLoads(sets)) {
    if (!isWorking(s)) continue;
    const kg = s.kg ?? 0;
    const reps = s.reps ?? 0;
    b.maxKg = Math.max(b.maxKg, kg);
    b.e1rm = Math.max(b.e1rm, e1rm(kg, reps));
    b.setVol = Math.max(b.setVol, kg * reps);
    b.maxReps = Math.max(b.maxReps, reps);
    b.maxSecs = Math.max(b.maxSecs, s.secs ?? 0);
  }
  return b;
}

export type PR = { exerciseId: string; label: string; value: string };

/** Recordes batidos num treino face a todos os treinos anteriores. */
export function prsInWorkout(w: Workout, all: Workout[]): PR[] {
  const prev = all.filter((x) => x.id !== w.id && x.start < w.start);
  const out: PR[] = [];
  for (const we of w.exercises) {
    const before = emptyBests();
    let seen = false;
    const mode = modeOf(w, we);
    for (const pw of prev)
      for (const pe of pw.exercises)
        if (pe.exerciseId === we.exerciseId && modeOf(pw, pe) === mode) {
          seen = true;
          const b = bestsOf(pe.sets);
          (Object.keys(before) as (keyof Bests)[]).forEach((k) => (before[k] = Math.max(before[k], b[k])));
        }
    if (!seen) continue; // primeira vez não conta como recorde
    const now = bestsOf(we.sets);
    if (now.maxKg > before.maxKg && now.maxKg > 0) out.push({ exerciseId: we.exerciseId, label: 'Carga máxima', value: `${now.maxKg} kg` });
    if (now.e1rm > before.e1rm + 0.05 && now.e1rm > 0) out.push({ exerciseId: we.exerciseId, label: '1RM estimado', value: `${now.e1rm.toFixed(1)} kg` });
    if (now.setVol > before.setVol && now.setVol > 0 && now.maxKg <= before.maxKg) out.push({ exerciseId: we.exerciseId, label: 'Melhor série', value: `${Math.round(now.setVol)} kg` });
    if (now.maxKg === 0 && now.maxReps > before.maxReps) out.push({ exerciseId: we.exerciseId, label: 'Mais reps', value: `${now.maxReps}` });
    if (now.maxSecs > before.maxSecs && now.maxSecs > 0) out.push({ exerciseId: we.exerciseId, label: 'Mais tempo', value: `${now.maxSecs} s` });
  }
  return out;
}

// ---------- Contexto ----------
type Ctx = {
  ready: boolean;
  data: AppData;
  exercises: Exercise[];
  exById: (id: string) => Exercise | undefined;
  lastSets: (exerciseId: string, beforeTs?: number, mode?: Mode) => WSet[] | null;
  startWorkout: (routineId?: string) => void;
  updateActive: (fn: (w: Workout) => Workout) => void;
  finishWorkout: () => Workout | null;
  discardWorkout: () => void;
  deleteWorkout: (id: string) => void;
  updateWorkout: (w: Workout) => void;
  saveRoutine: (r: Routine) => void;
  deleteRoutine: (id: string) => void;
  saveBody: (b: BodyEntry) => void;
  deleteBody: (id: string) => void;
  addCustomExercise: (e: Omit<Exercise, 'id' | 'custom'>) => Exercise;
  setSettings: (s: Partial<Settings>) => void;
  setProfile: (p: Profile) => void;
  exportJSON: () => string;
  importJSON: (s: string) => void;
  resetRoutines: () => void;
};

const StoreCtx = createContext<Ctx | null>(null);

export function newSet(prev?: Partial<WSet>): WSet {
  return { id: uid(), kind: 'normal', kg: null, reps: null, secs: null, ...prev, done: false };
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<AppData>(initial);
  const [ready, setReady] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(KEY)
      .then((raw) => {
        if (raw) {
          const parsed = JSON.parse(raw) as AppData;
          const merged: AppData = { ...initial, ...parsed, settings: { ...initial.settings, ...parsed.settings } };
          setData(migrate(merged));
        }
      })
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  useEffect(() => {
    if (!ready) return;
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      AsyncStorage.setItem(KEY, JSON.stringify(data)).catch(() => {});
    }, 300);
  }, [data, ready]);

  const exercises = useMemo(() => [...data.custom, ...BASE_EXERCISES], [data.custom]);
  const exMap = useMemo(() => new Map(exercises.map((e) => [e.id, e])), [exercises]);
  const exById = useCallback((id: string) => exMap.get(id), [exMap]);

  const sorted = useMemo(() => [...data.workouts].sort((a, b) => b.start - a.start), [data.workouts]);

  const lastSets = useCallback(
    (exerciseId: string, beforeTs?: number, mode?: Mode) => {
      for (const w of sorted) {
        if (beforeTs && w.start >= beforeTs) continue;
        const e = w.exercises.find((x) => x.exerciseId === exerciseId && (!mode || modeOf(w, x) === mode));
        if (e && e.sets.some((s) => s.done)) return e.sets.filter((s) => s.done);
      }
      return null;
    },
    [sorted],
  );

  const startWorkout = useCallback(
    (routineId?: string) => {
      setData((d) => {
        const r = d.routines.find((x) => x.id === routineId);
        const w: Workout = {
          id: uid(),
          name: r ? r.name : 'Treino livre',
          routineId: r?.id,
          start: Date.now(),
          exercises: (r?.exercises ?? []).map((re) => ({
            id: uid(),
            exerciseId: re.exerciseId,
            restSec: re.restSec,
            repMin: re.repMin,
            repMax: re.repMax,
            group: re.group,
            sets: Array.from({ length: re.sets }, () => newSet()),
          })),
        };
        return { ...d, active: w };
      });
    },
    [],
  );

  const updateActive = useCallback((fn: (w: Workout) => Workout) => {
    setData((d) => (d.active ? { ...d, active: fn(d.active) } : d));
  }, []);

  const dataRef = useRef(data);
  dataRef.current = data;

  const finishWorkout = useCallback(() => {
    const a = dataRef.current.active;
    if (!a) return null;
    const w: Workout = {
      ...a,
      end: Date.now(),
      exercises: a.exercises.map((e) => ({ ...e, sets: e.sets.filter((s) => s.done) })).filter((e) => e.sets.length > 0),
    };
    setData((d) => (w.exercises.length ? { ...d, active: null, workouts: [...d.workouts, w] } : { ...d, active: null }));
    if (w.exercises.length && dataRef.current.settings.hcSync) syncHc([w]);
    return w.exercises.length ? w : null;
  }, []);

  const value: Ctx = {
    ready,
    data,
    exercises,
    exById,
    lastSets,
    startWorkout,
    updateActive,
    finishWorkout,
    discardWorkout: () => setData((d) => ({ ...d, active: null })),
    deleteWorkout: (id) => {
      setData((d) => ({ ...d, workouts: d.workouts.filter((w) => w.id !== id) }));
      if (dataRef.current.settings.hcSync) hcDelete(id);
    },
    updateWorkout: (w) => {
      setData((d) => ({ ...d, workouts: d.workouts.map((x) => (x.id === w.id ? w : x)) }));
      if (dataRef.current.settings.hcSync && w.end) syncHc([w]);
    },
    saveRoutine: (r) =>
      setData((d) => ({
        ...d,
        routines: d.routines.some((x) => x.id === r.id) ? d.routines.map((x) => (x.id === r.id ? r : x)) : [...d.routines, r],
      })),
    deleteRoutine: (id) => setData((d) => ({ ...d, routines: d.routines.filter((r) => r.id !== id) })),
    saveBody: (b) =>
      setData((d) => ({
        ...d,
        body: (d.body.some((x) => x.id === b.id) ? d.body.map((x) => (x.id === b.id ? b : x)) : [...d.body, b]).sort((a, c) =>
          a.date.localeCompare(c.date),
        ),
      })),
    deleteBody: (id) => setData((d) => ({ ...d, body: d.body.filter((b) => b.id !== id) })),
    addCustomExercise: (e) => {
      const ex: Exercise = { ...e, id: 'c_' + uid(), custom: true };
      setData((d) => ({ ...d, custom: [ex, ...d.custom] }));
      return ex;
    },
    setSettings: (s) => setData((d) => ({ ...d, settings: { ...d.settings, ...s } })),
    setProfile: (p) => setData((d) => ({ ...d, profile: p })),
    exportJSON: () => JSON.stringify({ ...data, active: null }),
    importJSON: (s) => {
      const parsed = JSON.parse(s) as AppData;
      if (!parsed || !Array.isArray(parsed.workouts) || !Array.isArray(parsed.routines)) throw new Error('Ficheiro inválido');
      const merged: AppData = { ...initial, ...parsed, settings: { ...initial.settings, ...parsed.settings }, active: null };
      setData(migrate(merged));
    },
    resetRoutines: () =>
      setData((d) => ({ ...d, routines: [...DEFAULT_ROUTINES, ...d.routines.filter((r) => !r.id.startsWith('r_'))] })),
  };

  return <StoreCtx.Provider value={value}>{children}</StoreCtx.Provider>;
}

export function useStore(): Ctx {
  const c = useContext(StoreCtx);
  if (!c) throw new Error('StoreProvider em falta');
  return c;
}
