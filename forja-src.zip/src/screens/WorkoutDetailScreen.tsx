import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import React, { useLayoutEffect, useMemo } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Alert } from '../components/dialog';
import { BodyMap } from '../components/BodyMap';
import { ExerciseDemo } from '../components/ExerciseDemo';
import { Btn, Card, Divider, Ionicons, Section, Stat, T } from '../components/ui';
import type { Nav, RootStack } from '../nav';
import { isWorking, prsInWorkout, setLabel, setVolume, supersets, useStore, WExercise, workoutSets, workoutVolume } from '../store';
import { useTheme } from '../theme';
import { detailSets } from '../muscles';
import { e1rm, fmtDate, fmtKg, fmtMin, fmtNum, uid } from '../util';

export default function WorkoutDetailScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { params } = useRoute<RouteProp<RootStack, 'WorkoutDetail'>>();
  const { data, exById, deleteWorkout, saveRoutine } = useStore();
  const w = data.workouts.find((x) => x.id === params.id);

  useLayoutEffect(() => {
    nav.setOptions({
      title: params.fresh ? 'Resumo' : 'Treino',
      headerBackVisible: !params.fresh,
      headerRight: params.fresh
        ? () => (
            <Pressable onPress={() => nav.goBack()} hitSlop={10}>
              <T color={t.accent} weight="700" size={16}>
                Concluir
              </T>
            </Pressable>
          )
        : () => (
            <Pressable onPress={() => nav.navigate('Workout', { editId: params.id })} hitSlop={10} style={{ paddingHorizontal: 6 }} accessibilityLabel="Editar treino">
              <T color={t.accent} weight="700" size={16}>
                Editar
              </T>
            </Pressable>
          ),
    });
  }, [nav, params.fresh, params.id, t.accent]);

  const prs = useMemo(() => (w ? prsInWorkout(w, data.workouts) : []), [w, data.workouts]);

  const muscleSets = useMemo(() => (w ? detailSets([w], exById) : {}), [w, exById]);
  const intensity = useMemo(() => Object.fromEntries(Object.entries(muscleSets).map(([k, v]) => [k, Math.min(1, v / 6)])), [muscleSets]);

  if (!w)
    return (
      <View style={{ flex: 1, backgroundColor: t.bg, alignItems: 'center', justifyContent: 'center' }}>
        <T sub>Treino não encontrado.</T>
      </View>
    );

  const count = data.workouts.filter((x) => x.start <= w.start).length;

  return (
    <ScrollView style={{ backgroundColor: t.bg }} contentContainerStyle={{ padding: 16, paddingBottom: 60 }}>
      {params.fresh && (
        <View style={{ alignItems: 'center', marginBottom: 16 }}>
          <View style={{ width: 70, height: 70, borderRadius: 35, backgroundColor: t.goodSoft, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="checkmark-done" size={36} color={t.good} />
          </View>
          <T size={22} weight="800" style={{ marginTop: 10 }}>
            Treino concluído!
          </T>
          <T sub>Este foi o teu treino nº {count}.</T>
        </View>
      )}
      <T size={20} weight="800">
        {w.name}
      </T>
      <T sub size={13}>
        {fmtDate(w.start)} · {new Date(w.start).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}
      </T>
      <Card style={{ marginTop: 14, flexDirection: 'row' }}>
        <Stat label="Duração" icon="time-outline" value={fmtMin((w.end ?? w.start) - w.start)} />
        <Stat label="Volume" icon="barbell-outline" value={fmtKg(workoutVolume(w))} />
        <Stat label="Séries" icon="layers-outline" value={String(workoutSets(w))} />
        <Stat label="Recordes" icon="trophy-outline" value={String(prs.length)} />
      </Card>

      {prs.length > 0 && (
        <Section title="Recordes pessoais">
          <Card>
            {prs.map((p, i) => (
              <View key={i} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 6 }}>
                <Ionicons name="trophy" size={18} color={t.gold} />
                <T weight="600" style={{ flex: 1, marginLeft: 10 }} numberOfLines={1}>
                  {exById(p.exerciseId)?.name}
                </T>
                <T size={13} sub>
                  {p.label}:{' '}
                </T>
                <T weight="800">{p.value}</T>
              </View>
            ))}
          </Card>
        </Section>
      )}

      <Section title="Músculos trabalhados">
        <Card>
          <BodyMap intensity={intensity} sets={muscleSets} height={260} />
        </Card>
      </Section>

      <Section title="Exercícios">
        {(() => {
          const ssList = supersets(w.exercises);
          const out: React.ReactNode[] = [];
          for (let i = 0; i < w.exercises.length; i++) {
            const e = w.exercises[i];
            const ss = ssList[i];
            if (!ss) {
              out.push(<ExerciseCard key={e.id} e={e} />);
              continue;
            }
            const members = w.exercises.slice(i, i + ss.size);
            i += ss.size - 1;
            const rounds = Math.max(...members.map((m) => m.sets.length));
            out.push(
              <Card key={e.id} style={{ marginBottom: 10, borderWidth: 1.5, borderColor: 'rgba(255,122,26,0.45)', backgroundColor: t.dark ? '#1A140F' : '#FFF4EB' }}>
                <View style={{ flexDirection: 'row', alignSelf: 'flex-start', alignItems: 'center', gap: 4, backgroundColor: '#FF7A1A', borderRadius: 999, paddingHorizontal: 9, paddingVertical: 3 }}>
                  <Ionicons name="flash" size={11} color="#1A0B00" />
                  <T size={11} weight="900" color="#1A0B00">
                    SUPER SÉRIE {ss.letter}
                  </T>
                </View>
                {members.map((m, k) => {
                  const ex = exById(m.exerciseId);
                  return (
                    <Pressable key={m.id} onPress={() => nav.navigate('ExerciseDetail', { id: m.exerciseId })} style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10 }}>
                      <ExerciseDemo id={m.exerciseId} size={36} animate={false} radius={18} />
                      <T weight="700" color={t.accent} style={{ flex: 1, marginLeft: 10 }} numberOfLines={1}>
                        <T weight="900" color="#FF7A1A">{`${ss.letter}${k + 1} · `}</T>
                        {ex?.name}
                      </T>
                      <Ionicons name="chevron-forward" size={18} color={t.faint} />
                    </Pressable>
                  );
                })}
                {members.some((m) => m.note) &&
                  members.map((m, k) =>
                    m.note ? (
                      <T key={m.id} size={12} sub style={{ marginTop: 6, fontStyle: 'italic' }}>
                        {`${ss.letter}${k + 1}: ${m.note}`}
                      </T>
                    ) : null,
                  )}
                <Divider />
                {Array.from({ length: rounds }, (_, r) => (
                  <View key={r} style={{ flexDirection: 'row', paddingVertical: 4 }}>
                    <T size={12} weight="800" color="#FF7A1A" style={{ width: 64, marginTop: 1 }}>
                      VOLTA {r + 1}
                    </T>
                    <T style={{ flex: 1 }}>
                      {members
                        .map((m) => {
                          const st = m.sets[r];
                          const ty = exById(m.exerciseId)?.type ?? 'weight';
                          return st ? (ty === 'time' ? `${st.secs} s` : setLabel(st, ty)) : null;
                        })
                        .filter(Boolean)
                        .join('  +  ')}
                    </T>
                  </View>
                ))}
                <T size={12} sub style={{ marginTop: 6 }}>
                  {'Volume: ' +
                    members
                      .map((m) => {
                        const v = m.sets.reduce((a, x) => a + setVolume(x), 0);
                        return `${exById(m.exerciseId)?.name ?? ''} ${v ? fmtKg(v) : `${m.sets.filter(isWorking).length} séries`}`;
                      })
                      .join(' · ')}
                </T>
              </Card>,
            );
          }
          return out;
        })()}
      </Section>

      <View style={{ gap: 10, marginTop: 16 }}>
        <Btn title="Editar treino" icon="create-outline" onPress={() => nav.navigate('Workout', { editId: w.id })} />
        <Btn
          title="Guardar como rotina"
          kind="secondary"
          icon="bookmark-outline"
          onPress={() => {
            saveRoutine({
              id: 'u_' + uid(),
              name: w.name + ' (novo)',
              place: 'gym',
              exercises: w.exercises.map((e) => ({ exerciseId: e.exerciseId, group: e.group, sets: e.sets.filter(isWorking).length || e.sets.length, repMin: e.repMin ?? 8, repMax: e.repMax ?? 12, restSec: e.restSec })),
            });
            Alert.alert('Rotina guardada', 'Encontras no separador Treinar.');
          }}
        />
        <Btn
          title="Apagar treino"
          kind="danger"
          icon="trash-outline"
          onPress={() =>
            Alert.alert('Apagar treino?', 'Isto não pode ser desfeito.', [
              { text: 'Cancelar', style: 'cancel' },
              {
                text: 'Apagar',
                style: 'destructive',
                onPress: () => {
                  nav.goBack();
                  deleteWorkout(w.id);
                },
              },
            ])
          }
        />
      </View>
    </ScrollView>
  );
}

function ExerciseCard({ e }: { e: WExercise }) {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { exById } = useStore();
  const ex = exById(e.exerciseId);
  let n = 0;
  return (
    <Card style={{ marginBottom: 10 }} onPress={() => nav.navigate('ExerciseDetail', { id: e.exerciseId })}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <ExerciseDemo id={e.exerciseId} size={40} animate={false} radius={20} />
        <T weight="700" color={t.accent} style={{ flex: 1, marginLeft: 10 }}>
          {ex?.name}
        </T>
        <Ionicons name="chevron-forward" size={18} color={t.faint} />
      </View>
      {e.note ? (
        <T size={13} sub style={{ marginTop: 6, fontStyle: 'italic' }}>
          {e.note}
        </T>
      ) : null}
      <Divider />
      {e.sets.map((s) => {
        const label = s.kind === 'warmup' ? 'A' : s.kind === 'drop' ? 'D' : s.kind === 'failure' ? 'F' : String(++n);
        const val = ex?.type === 'time' ? `${s.secs} s` : setLabel(s, ex?.type ?? 'weight') + (ex?.type === 'reps' ? ' reps' : '');
        return (
          <View key={s.id} style={{ flexDirection: 'row', paddingVertical: 3 }}>
            <T weight="700" sub style={{ width: 28 }}>
              {label}
            </T>
            <T style={{ flex: 1 }}>{val}</T>
            {ex?.type === 'weight' && s.kg && s.reps ? (
              <T size={12} faint>
                1RM≈{fmtNum(e1rm(s.kg, s.reps))}
              </T>
            ) : null}
          </View>
        );
      })}
    </Card>
  );
}
