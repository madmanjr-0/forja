import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import React, { useLayoutEffect, useMemo } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Alert } from '../components/dialog';
import { BodyMap } from '../components/BodyMap';
import { ExerciseDemo } from '../components/ExerciseDemo';
import { Btn, Card, Divider, Ionicons, Section, Stat, T } from '../components/ui';
import type { Nav, RootStack } from '../nav';
import { isWorking, prsInWorkout, useStore, workoutSets, workoutVolume } from '../store';
import { useTheme } from '../theme';
import { e1rm, fmtDate, fmtDuration, fmtKg, fmtNum, uid } from '../util';

export default function WorkoutDetailScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { params } = useRoute<RouteProp<RootStack, 'WorkoutDetail'>>();
  const { data, exById, deleteWorkout, saveRoutine } = useStore();
  const w = data.workouts.find((x) => x.id === params.id);

  useLayoutEffect(() => {
    nav.setOptions({
      title: params.fresh ? 'Resumo' : 'Treino',
      headerBackVisible: !params.fresh,
      headerRight: params.fresh
        ? () => (
            <Pressable onPress={() => nav.goBack()} hitSlop={10}>
              <T color={t.accent} weight="700" size={16}>
                Concluir
              </T>
            </Pressable>
          )
        : undefined,
    });
  }, [nav, params.fresh, t.accent]);

  const prs = useMemo(() => (w ? prsInWorkout(w, data.workouts) : []), [w, data.workouts]);

  const intensity = useMemo(() => {
    const m: Record<string, number> = {};
    if (!w) return m;
    for (const e of w.exercises) {
      const ex = exById(e.exerciseId);
      const n = e.sets.filter(isWorking).length;
      ex?.p.forEach((x) => (m[x] = (m[x] ?? 0) + n));
      ex?.s.forEach((x) => (m[x] = (m[x] ?? 0) + n * 0.5));
    }
    Object.keys(m).forEach((k) => (m[k] = Math.min(1, m[k] / 6)));
    return m;
  }, [w, exById]);

  if (!w)
    return (
      <View style={{ flex: 1, backgroundColor: t.bg, alignItems: 'center', justifyContent: 'center' }}>
        <T sub>Treino não encontrado.</T>
      </View>
    );

  const count = data.workouts.filter((x) => x.start <= w.start).length;

  return (
    <ScrollView style={{ backgroundColor: t.bg }} contentContainerStyle={{ padding: 16, paddingBottom: 60 }}>
      {params.fresh && (
        <View style={{ alignItems: 'center', marginBottom: 16 }}>
          <View style={{ width: 70, height: 70, borderRadius: 35, backgroundColor: t.goodSoft, alignItems: 'center', justifyContent: 'center' }}>
            <Ionicons name="checkmark-done" size={36} color={t.good} />
          </View>
          <T size={22} weight="800" style={{ marginTop: 10 }}>
            Treino concluído!
          </T>
          <T sub>Este foi o teu treino nº {count}.</T>
        </View>
      )}
      <T size={20} weight="800">
        {w.name}
      </T>
      <T sub size={13}>
        {fmtDate(w.start)} · {new Date(w.start).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}
      </T>
      <Card style={{ marginTop: 14, flexDirection: 'row' }}>
        <Stat label="Duração" icon="time-outline" value={fmtDuration((w.end ?? w.start) - w.start)} />
        <Stat label="Volume" icon="barbell-outline" value={fmtKg(workoutVolume(w))} />
        <Stat label="Séries" icon="layers-outline" value={String(workoutSets(w))} />
        <Stat label="Recordes" icon="trophy-outline" value={String(prs.length)} />
      </Card>

      {prs.length > 0 && (
        <Section title="Recordes pessoais">
          <Card>
            {prs.map((p, i) => (
              <View key={i} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 6 }}>
                <Ionicons name="trophy" size={18} color={t.gold} />
                <T weight="600" style={{ flex: 1, marginLeft: 10 }} numberOfLines={1}>
                  {exById(p.exerciseId)?.name}
                </T>
                <T size={13} sub>
                  {p.label}:{' '}
                </T>
                <T weight="800">{p.value}</T>
              </View>
            ))}
          </Card>
        </Section>
      )}

      <Section title="Músculos trabalhados">
        <Card>
          <BodyMap intensity={intensity} height={220} />
        </Card>
      </Section>

      <Section title="Exercícios">
        {w.exercises.map((e) => {
          const ex = exById(e.exerciseId);
          let n = 0;
          return (
            <Card key={e.id} style={{ marginBottom: 10 }} onPress={() => nav.navigate('ExerciseDetail', { id: e.exerciseId })}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <ExerciseDemo id={e.exerciseId} size={40} animate={false} radius={20} />
                <T weight="700" color={t.accent} style={{ flex: 1, marginLeft: 10 }}>
                  {ex?.name}
                </T>
                <Ionicons name="chevron-forward" size={18} color={t.faint} />
              </View>
              {e.note ? (
                <T size={13} sub style={{ marginTop: 6, fontStyle: 'italic' }}>
                  {e.note}
                </T>
              ) : null}
              <Divider />
              {e.sets.map((s) => {
                const label = s.kind === 'warmup' ? 'A' : s.kind === 'drop' ? 'D' : s.kind === 'failure' ? 'F' : String(++n);
                const val =
                  ex?.type === 'time' ? `${s.secs} s` : ex?.type === 'reps' ? `${s.kg ? `+${fmtNum(s.kg)} kg × ` : ''}${s.reps} reps` : `${fmtNum(s.kg ?? 0)} kg × ${s.reps}`;
                return (
                  <View key={s.id} style={{ flexDirection: 'row', paddingVertical: 3 }}>
                    <T weight="700" sub style={{ width: 28 }}>
                      {label}
                    </T>
                    <T style={{ flex: 1 }}>{val}</T>
                    {ex?.type === 'weight' && s.kg && s.reps ? (
                      <T size={12} faint>
                        1RM≈{fmtNum(e1rm(s.kg, s.reps))}
                      </T>
                    ) : null}
                  </View>
                );
              })}
            </Card>
          );
        })}
      </Section>

      <View style={{ gap: 10, marginTop: 16 }}>
        <Btn
          title="Guardar como rotina"
          kind="secondary"
          icon="bookmark-outline"
          onPress={() => {
            saveRoutine({
              id: 'u_' + uid(),
              name: w.name + ' (novo)',
              place: 'gym',
              exercises: w.exercises.map((e) => ({ exerciseId: e.exerciseId, sets: e.sets.filter(isWorking).length || e.sets.length, repMin: e.repMin ?? 8, repMax: e.repMax ?? 12, restSec: e.restSec })),
            });
            Alert.alert('Rotina guardada', 'Encontras no separador Treinar.');
          }}
        />
        <Btn
          title="Apagar treino"
          kind="danger"
          icon="trash-outline"
          onPress={() =>
            Alert.alert('Apagar treino?', 'Isto não pode ser desfeito.', [
              { text: 'Cancelar', style: 'cancel' },
              {
                text: 'Apagar',
                style: 'destructive',
                onPress: () => {
                  nav.goBack();
                  deleteWorkout(w.id);
                },
              },
            ])
          }
        />
      </View>
    </ScrollView>
  );
}
