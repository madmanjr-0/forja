import { useNavigation } from '@react-navigation/native';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { Alert } from '../components/dialog';
import { ActionMenu } from '../components/ActionMenu';
import { Btn, Card, Ionicons, Section, T } from '../components/ui';
import type { Nav } from '../nav';
import { Routine, useStore } from '../store';
import { useTheme } from '../theme';
import { DAY, fmtDuration, uid, weekStart } from '../util';

const DIAS = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'];

export default function TrainScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { data, startWorkout, exById, deleteRoutine, saveRoutine, discardWorkout } = useStore();
  const [menu, setMenu] = useState<Routine | null>(null);

  const wk = weekStart(Date.now());
  const weekDays = useMemo(() => {
    const set = new Set<number>();
    for (const w of data.workouts) if (w.start >= wk) set.add(Math.floor((w.start - wk) / DAY));
    return set;
  }, [data.workouts, wk]);
  const today = Math.floor((Date.now() - wk) / DAY);

  // Sugestão: alterna A/B com base no último treino de ginásio ou casa
  const next = useMemo(() => {
    const last = [...data.workouts].sort((a, b) => b.start - a.start).find((w) => w.routineId);
    const lastR = data.routines.find((r) => r.id === last?.routineId);
    const gym = data.routines.filter((r) => r.place === 'gym');
    const home = data.routines.filter((r) => r.place === 'home');
    const isB = !!lastR && /\bB\b/.test(lastR.name);
    const pick = (list: Routine[]) => list.find((r) => (isB ? /\bA\b/.test(r.name) : lastR ? /\bB\b/.test(r.name) : /\bA\b/.test(r.name))) ?? list[0];
    return { gym: pick(gym), home: pick(home) };
  }, [data.workouts, data.routines]);

  const start = (routineId?: string) => {
    if (data.active) {
      Alert.alert('Já tens um treino a decorrer', 'Queres retomá-lo ou descartá-lo e começar este?', [
        { text: 'Retomar', onPress: () => nav.navigate('Workout') },
        {
          text: 'Descartar e começar',
          style: 'destructive',
          onPress: () => {
            discardWorkout();
            setTimeout(() => {
              startWorkout(routineId);
              nav.navigate('Workout');
            }, 50);
          },
        },
        { text: 'Cancelar', style: 'cancel' },
      ]);
      return;
    }
    startWorkout(routineId);
    nav.navigate('Workout');
  };

  const groups: { title: string; list: Routine[] }[] = [
    { title: 'Ginásio', list: data.routines.filter((r) => r.place === 'gym') },
    { title: 'Casa', list: data.routines.filter((r) => r.place === 'home') },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: t.bg }}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 120 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <View>
            <T size={13} sub>
              Esta semana
            </T>
            <T size={20} weight="800">
              {weekDays.size} treino{weekDays.size === 1 ? '' : 's'}{' '}
              <T size={15} sub>
                / objetivo 3
              </T>
            </T>
          </View>
          <Pressable onPress={() => nav.navigate('Settings')} hitSlop={10}>
            <Ionicons name="settings-outline" size={24} color={t.sub} />
          </Pressable>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 }}>
          {DIAS.map((d, i) => {
            const on = weekDays.has(i);
            const isToday = i === today;
            return (
              <View key={i} style={{ alignItems: 'center', gap: 4 }}>
                <T size={11} sub weight={isToday ? '800' : '500'} color={isToday ? t.accent : undefined}>
                  {d}
                </T>
                <View
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 18,
                    backgroundColor: on ? t.accent : t.card,
                    borderWidth: isToday && !on ? 2 : 0,
                    borderColor: t.accent,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {on ? <Ionicons name="checkmark" size={18} color="#fff" /> : null}
                </View>
              </View>
            );
          })}
        </View>

        {data.active && (
          <Card style={{ marginTop: 18, borderColor: t.accent, borderWidth: 1.5 }} onPress={() => nav.navigate('Workout')}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: t.good, marginRight: 10 }} />
              <View style={{ flex: 1 }}>
                <T weight="700">{data.active.name}</T>
                <T size={13} sub>
                  A decorrer · {fmtDuration(Date.now() - data.active.start)}
                </T>
              </View>
              <T color={t.accent} weight="700">
                Retomar
              </T>
            </View>
          </Card>
        )}

        <Section title="Começar">
          <Btn title="Treino livre" icon="add" kind="secondary" onPress={() => start()} />
          {next.gym && (
            <Card style={{ marginTop: 10, backgroundColor: t.accent, borderColor: t.accent }} onPress={() => start(next.gym!.id)}>
              <T size={12} color="rgba(255,255,255,0.8)" weight="600">
                PRÓXIMO SUGERIDO
              </T>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 4 }}>
                <T size={18} weight="800" color="#fff" style={{ flex: 1 }}>
                  {next.gym.name}
                </T>
                <Ionicons name="play-circle" size={34} color="#fff" />
              </View>
              <T size={13} color="rgba(255,255,255,0.85)">
                {next.gym.exercises.length} exercícios · ~{Math.round(next.gym.exercises.reduce((a, e) => a + e.sets * (e.restSec + 45), 0) / 60)} min
              </T>
            </Card>
          )}
          {next.home && (
            <Pressable onPress={() => start(next.home!.id)} style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10, paddingVertical: 6 }}>
              <Ionicons name="home-outline" size={16} color={t.accent} />
              <T size={14} color={t.accent} style={{ marginLeft: 6 }}>
                Dia de preguiça? Começar {next.home.name}
              </T>
            </Pressable>
          )}
        </Section>

        {groups.map((g) => (
          <Section
            key={g.title}
            title={`Rotinas · ${g.title}`}
            right={
              g.title === 'Ginásio' ? (
                <Pressable onPress={() => nav.navigate('RoutineEdit', {})} hitSlop={8}>
                  <T color={t.accent} weight="600" size={14}>
                    + Nova
                  </T>
                </Pressable>
              ) : undefined
            }
          >
            {g.list.length === 0 && (
              <T faint size={14}>
                Sem rotinas.
              </T>
            )}
            {g.list.map((r) => (
              <Card key={r.id} style={{ marginBottom: 10 }}>
                <View style={{ flexDirection: 'row', alignItems: 'flex-start' }}>
                  <View style={{ flex: 1 }}>
                    <T size={16} weight="700">
                      {r.name}
                    </T>
                    <T size={13} sub numberOfLines={2} style={{ marginTop: 3, lineHeight: 18 }}>
                      {r.exercises.map((e) => exById(e.exerciseId)?.name ?? '?').join(', ')}
                    </T>
                  </View>
                  <Pressable onPress={() => setMenu(r)} hitSlop={10} style={{ paddingLeft: 8 }}>
                    <Ionicons name="ellipsis-horizontal" size={22} color={t.sub} />
                  </Pressable>
                </View>
                <Btn title="Começar rotina" small style={{ marginTop: 12 }} onPress={() => start(r.id)} />
              </Card>
            ))}
          </Section>
        ))}
      </ScrollView>

      <ActionMenu
        visible={!!menu}
        title={menu?.name}
        onClose={() => setMenu(null)}
        items={
          menu
            ? [
                { label: 'Editar rotina', icon: 'create-outline', onPress: () => nav.navigate('RoutineEdit', { id: menu.id }) },
                { label: 'Duplicar', icon: 'copy-outline', onPress: () => saveRoutine({ ...menu, id: 'u_' + uid(), name: menu.name + ' (cópia)' }) },
                {
                  label: 'Apagar rotina',
                  icon: 'trash-outline',
                  danger: true,
                  onPress: () =>
                    Alert.alert('Apagar rotina?', menu.name, [
                      { text: 'Cancelar', style: 'cancel' },
                      { text: 'Apagar', style: 'destructive', onPress: () => deleteRoutine(menu.id) },
                    ]),
                },
              ]
            : []
        }
      />
    </View>
  );
}
