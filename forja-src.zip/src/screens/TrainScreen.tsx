import { useNavigation } from '@react-navigation/native';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { ActionMenu } from '../components/ActionMenu';
import { Alert } from '../components/dialog';
import { RoutinePreview } from '../components/RoutinePreview';
import { Card, Ionicons, T } from '../components/ui';
import type { Nav } from '../nav';
import { estimateDuration, forecastDayIndex, nextRoutines, routineLetter, workoutMark } from '../plan';
import { Routine, useStore } from '../store';
import { useTheme } from '../theme';
import { DAY, fmtDuration, uid, weekStart } from '../util';

const DIAS = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'];

export default function TrainScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { data, startWorkout, deleteRoutine, saveRoutine, discardWorkout } = useStore();
  const [menu, setMenu] = useState<Routine | null>(null);
  const [preview, setPreview] = useState<Routine | null>(null);

  const now = Date.now();
  const wk = weekStart(now);
  const todayIdx = Math.floor((now - wk) / DAY);

  const marks = useMemo(() => {
    const m = new Map<number, string>();
    for (const w of [...data.workouts].sort((a, b) => a.start - b.start))
      if (w.start >= wk && w.start < wk + 7 * DAY) m.set(Math.floor((w.start - wk) / DAY), workoutMark(w, data.routines));
    return m;
  }, [data.workouts, data.routines, wk]);

  const next = useMemo(() => nextRoutines(data.routines, data.workouts), [data.routines, data.workouts]);
  const forecast = forecastDayIndex(data.workouts, wk, now);
  const forecastMark = next.gym ? routineLetter(next.gym.name) ?? '•' : '•';

  const gym = data.routines.filter((r) => r.place === 'gym');
  const gymA = data.routines.find((r) => r.id === 'r_gym_a') ?? gym[0];
  const gymB = data.routines.find((r) => r.id === 'r_gym_b') ?? gym.find((r) => r !== gymA);

  const start = (routineId?: string) => {
    if (data.active) {
      Alert.alert('Já tens um treino a decorrer', 'Queres retomá-lo ou descartá-lo e começar este?', [
        { text: 'Retomar', onPress: () => nav.navigate('Workout') },
        {
          text: 'Descartar e começar',
          style: 'destructive',
          onPress: () => {
            discardWorkout();
            setTimeout(() => {
              startWorkout(routineId);
              nav.navigate('Workout');
            }, 50);
          },
        },
        { text: 'Cancelar', style: 'cancel' },
      ]);
      return;
    }
    startWorkout(routineId);
    nav.navigate('Workout');
  };

  const cards: { key: string; tag: string; title: string; meta: string; routine?: Routine; color: string }[] = [];
  const meta = (r: Routine) => `${r.exercises.length} exercícios · ~${estimateDuration(r, data.workouts).min} min`;
  if (gymA) cards.push({ key: gymA.id, tag: 'GINÁSIO', title: gymA.name.replace(/ · .*$/, ''), meta: meta(gymA), routine: gymA, color: t.sub });
  if (gymB) cards.push({ key: gymB.id, tag: 'GINÁSIO', title: gymB.name.replace(/ · .*$/, ''), meta: meta(gymB), routine: gymB, color: t.sub });
  if (next.home) {
    const l = next.home.name.match(/^casa\s+([a-z0-9])/i)?.[1];
    cards.push({ key: next.home.id, tag: 'CASA', title: l ? `Treino ${l.toUpperCase()} casa` : next.home.name, meta: meta(next.home), routine: next.home, color: t.good });
  }
  cards.push({ key: 'free', tag: 'LIVRE', title: 'Treino livre', meta: 'Escolhes os exercícios', color: t.sub });

  return (
    <View style={{ flex: 1, backgroundColor: t.bg }}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <View>
            <T size={13} sub>
              Esta semana
            </T>
            <T size={22} weight="800">
              {marks.size} treino{marks.size === 1 ? '' : 's'}{' '}
              <T size={15} sub weight="700">
                / objetivo 3
              </T>
            </T>
          </View>
          <Pressable onPress={() => nav.navigate('Settings')} hitSlop={10} accessibilityLabel="Definições">
            <Ionicons name="settings-outline" size={24} color={t.sub} />
          </Pressable>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 14 }}>
          {DIAS.map((d, i) => {
            const mark = marks.get(i);
            const isToday = i === todayIdx;
            const isNext = !mark && forecast === i;
            const size = isToday ? 46 : 38;
            return (
              <View key={i} style={{ alignItems: 'center', gap: 5, width: 46 }}>
                <T size={isToday ? 10 : 11} weight="800" color={isToday ? t.accent : t.sub}>
                  {isToday ? 'HOJE' : d}
                </T>
                <View
                  style={{
                    width: size,
                    height: size,
                    borderRadius: size / 2,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: mark ? t.accent : isToday ? t.accentSoft : t.card,
                    borderWidth: isToday ? 2.5 : isNext ? 1.5 : 0,
                    borderStyle: isNext ? 'dashed' : 'solid',
                    borderColor: isToday ? t.accent : t.faint,
                  }}
                >
                  {mark ? (
                    mark === '✓' ? (
                      <Ionicons name="checkmark" size={18} color="#fff" />
                    ) : (
                      <T size={mark.length > 1 ? 11 : 14} weight="900" color="#fff">
                        {mark}
                      </T>
                    )
                  ) : isNext ? (
                    <T size={13} weight="800" color={t.sub}>
                      {forecastMark}
                    </T>
                  ) : null}
                </View>
              </View>
            );
          })}
        </View>

        {data.active && (
          <Card style={{ marginTop: 18, borderColor: t.accent, borderWidth: 1.5 }} onPress={() => nav.navigate('Workout')}>
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: t.good, marginRight: 10 }} />
              <View style={{ flex: 1 }}>
                <T weight="700">{data.active.name}</T>
                <T size={13} sub>
                  A decorrer · {fmtDuration(now - data.active.start)}
                </T>
              </View>
              <T color={t.accent} weight="700">
                Retomar
              </T>
            </View>
          </Card>
        )}

        {next.gym && (
          <Pressable
            onPress={() => start(next.gym!.id)}
            style={({ pressed }) => [st.pill, { backgroundColor: t.accent, opacity: pressed ? 0.85 : 1 }]}
            accessibilityRole="button"
          >
            <View style={{ flex: 1 }}>
              <T size={11} weight="800" color="rgba(255,255,255,0.85)" style={{ letterSpacing: 0.5 }}>
                COMEÇAR TREINO SUGERIDO
              </T>
              <T size={18} weight="800" color="#fff" numberOfLines={1}>
                {next.gym.name}
              </T>
            </View>
            <View style={st.pillPlay}>
              <Ionicons name="play" size={20} color={t.accent} />
            </View>
          </Pressable>
        )}

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 22, marginBottom: 10 }}>
          <T size={13} weight="700" sub style={{ letterSpacing: 0.6 }}>
            ROTINAS
          </T>
          <Pressable onPress={() => nav.navigate('RoutineEdit', {})} hitSlop={8}>
            <T color={t.accent} weight="700" size={15}>
              + Nova
            </T>
          </Pressable>
        </View>

        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 12 }}>
          {cards.map((c) => {
            const isNext = !!c.routine && c.routine.id === next.gym?.id;
            return (
              <View key={c.key} style={[st.card, { backgroundColor: t.card, borderColor: isNext ? t.accent : t.border }]}>
                <Pressable
                  onPress={() => (c.routine ? setPreview(c.routine) : start())}
                  onLongPress={() => c.routine && setMenu(c.routine)}
                  style={({ pressed }) => [st.cardTop, pressed && { backgroundColor: t.card2 }]}
                >
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <T size={11} weight="800" color={isNext ? t.accent : c.color} style={{ letterSpacing: 0.5 }}>
                      {isNext ? 'PRÓXIMO' : c.tag}
                    </T>
                    {c.routine ? <Ionicons name="eye-outline" size={16} color={t.faint} /> : null}
                  </View>
                  <T size={17} weight="800" numberOfLines={2} style={{ marginTop: 4 }}>
                    {c.title}
                  </T>
                  <T size={12} sub style={{ marginTop: 2 }}>
                    {c.meta}
                  </T>
                </Pressable>
                <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: t.border }} />
                <Pressable
                  onPress={() => start(c.routine?.id)}
                  style={({ pressed }) => [st.cardBottom, pressed && { backgroundColor: t.card2 }]}
                  accessibilityLabel={`Começar ${c.title}`}
                >
                  <View style={[st.play, { backgroundColor: isNext ? t.accent : t.card2 }]}>
                    <Ionicons name={c.routine ? 'play' : 'add'} size={c.routine ? 18 : 22} color={isNext ? '#fff' : t.text} />
                  </View>
                </Pressable>
              </View>
            );
          })}
        </View>

        <T size={13} weight="700" sub style={{ letterSpacing: 0.6, marginTop: 26, marginBottom: 6 }}>
          TODAS AS ROTINAS
        </T>
        {data.routines.map((r) => (
          <View key={r.id} style={[st.row, { borderColor: t.border }]}>
            <Pressable onPress={() => setPreview(r)} style={{ flex: 1 }}>
              <T weight="700">{r.name}</T>
              <T size={12} sub>
                {r.place === 'home' ? 'Casa' : 'Ginásio'} · {meta(r)}
              </T>
            </Pressable>
            <Pressable onPress={() => setMenu(r)} hitSlop={10} style={{ padding: 6 }} accessibilityLabel="Opções da rotina">
              <Ionicons name="ellipsis-horizontal" size={20} color={t.sub} />
            </Pressable>
            <Pressable onPress={() => start(r.id)} hitSlop={6} style={[st.playSmall, { backgroundColor: t.card2 }]} accessibilityLabel={`Começar ${r.name}`}>
              <Ionicons name="play" size={15} color={t.text} />
            </Pressable>
          </View>
        ))}
      </ScrollView>

      <RoutinePreview routine={preview} onClose={() => setPreview(null)} />
      <ActionMenu
        visible={!!menu}
        title={menu?.name}
        onClose={() => setMenu(null)}
        items={
          menu
            ? [
                { label: 'Ver treino', icon: 'eye-outline', onPress: () => setPreview(menu) },
                { label: 'Editar rotina', icon: 'create-outline', onPress: () => nav.navigate('RoutineEdit', { id: menu.id }) },
                { label: 'Duplicar', icon: 'copy-outline', onPress: () => saveRoutine({ ...menu, id: 'u_' + uid(), name: menu.name + ' (cópia)' }) },
                {
                  label: 'Apagar rotina',
                  icon: 'trash-outline',
                  danger: true,
                  onPress: () =>
                    Alert.alert('Apagar rotina?', menu.name, [
                      { text: 'Cancelar', style: 'cancel' },
                      { text: 'Apagar', style: 'destructive', onPress: () => deleteRoutine(menu.id) },
                    ]),
                },
              ]
            : []
        }
      />
    </View>
  );
}

const st = StyleSheet.create({
  pill: { flexDirection: 'row', alignItems: 'center', borderRadius: 999, paddingVertical: 12, paddingLeft: 22, paddingRight: 12, marginTop: 20, gap: 12 },
  pillPlay: { width: 46, height: 46, borderRadius: 23, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  card: { width: '48%', flexGrow: 1, borderRadius: 18, borderWidth: 1, overflow: 'hidden' },
  cardTop: { padding: 14, paddingBottom: 12, minHeight: 100 },
  cardBottom: { height: 64, alignItems: 'center', justifyContent: 'center' },
  play: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 11, borderBottomWidth: StyleSheet.hairlineWidth, gap: 6 },
  playSmall: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
});
