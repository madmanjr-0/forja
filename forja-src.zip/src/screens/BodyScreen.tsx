import { useNavigation } from '@react-navigation/native';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { MeasureSilhouette } from '../components/BodyMap';
import { LineChart } from '../components/Charts';
import { Btn, Card, Chip, Divider, Empty, Ionicons, Section, T } from '../components/ui';
import { ACTIVITY, ageNow, bfClass, bfDeurenberg, bmi, bmiClass, Derived, derive, ffmiClass } from '../bodycalc';
import type { Nav } from '../nav';
import { BodyEntry, Profile, useStore } from '../store';
import { useTheme } from '../theme';
import { fmtDate, fmtNum, isoToTs } from '../util';

type Key = string;
type Metric = { k: Key; label: string; unit: string; goodUp?: boolean; digits?: number; get: (e: BodyEntry, d: Derived) => number | undefined | null };

export const BODY_METRICS: Metric[] = [
  { k: 'weight', label: 'Peso', unit: 'kg', get: (e) => e.weight },
  { k: 'bf', label: '% gordura', unit: '%', goodUp: false, get: (_, d) => d.bfBest },
  { k: 'lean', label: 'Massa magra', unit: 'kg', goodUp: true, get: (_, d) => d.lean },
  { k: 'ffmi', label: 'FFMI', unit: '', goodUp: true, get: (_, d) => d.ffmi?.norm },
  { k: 'waist', label: 'Cintura', unit: 'cm', goodUp: false, get: (e) => e.waist },
  { k: 'vtaper', label: 'Ombros/cintura', unit: '', goodUp: true, digits: 2, get: (_, d) => d.vtaper },
  { k: 'chest', label: 'Peito', unit: 'cm', goodUp: true, get: (e) => e.chest },
  { k: 'shoulders', label: 'Ombros', unit: 'cm', goodUp: true, get: (e) => e.shoulders },
  { k: 'armL', label: 'Braço esq.', unit: 'cm', goodUp: true, get: (e) => e.armL },
  { k: 'armR', label: 'Braço dir.', unit: 'cm', goodUp: true, get: (e) => e.armR },
  { k: 'thighL', label: 'Coxa esq.', unit: 'cm', goodUp: true, get: (e) => e.thighL },
  { k: 'thighR', label: 'Coxa dir.', unit: 'cm', goodUp: true, get: (e) => e.thighR },
  { k: 'fat', label: 'Gordura (balança)', unit: '%', goodUp: false, get: (e) => e.fat },
  { k: 'muscle', label: 'Músculo (balança)', unit: 'kg', goodUp: true, get: (_, d) => d.muscleKg },
  { k: 'water', label: 'Hidratação', unit: '%', get: (e) => e.water },
  { k: 'bmi', label: 'IMC', unit: '', get: (_, d) => d.bmi },
];

export default function BodyScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { data } = useStore();
  const [metric, setMetric] = useState<Key>('weight');
  const p = data.profile as Profile;
  const entries = data.body;

  const rows = useMemo(() => entries.map((e) => ({ e, d: derive(e, p) })), [entries, p]);
  const lastWith = (m: Metric) => [...rows].reverse().find((r) => m.get(r.e, r.d) != null);
  const firstWith = (m: Metric) => rows.find((r) => m.get(r.e, r.d) != null);
  const M = (k: Key) => BODY_METRICS.find((m) => m.k === k)!;
  const cur = M(metric);
  const series = rows.filter((r) => cur.get(r.e, r.d) != null).map((r) => ({ x: isoToTs(r.e.date), y: cur.get(r.e, r.d)! }));

  if (!entries.length)
    return (
      <View style={{ flex: 1, backgroundColor: t.bg, padding: 16 }}>
        <Empty icon="body-outline" title="Sem registos" text="Adiciona o teu peso e, se quiseres, medidas e dados da balança." />
        <Btn title="Novo registo" icon="add" onPress={() => nav.navigate('BodyEntry', {})} />
      </View>
    );

  // "Último estado conhecido": combina o valor mais recente de cada campo
  const latest: BodyEntry = { id: 'latest', date: entries[entries.length - 1].date };
  for (const e of entries) for (const [k, v] of Object.entries(e)) if (v != null && k !== 'id' && k !== 'date') (latest as any)[k] = v;
  const D = derive(latest, p);
  const age = ageNow(p);
  const w = latest.weight;
  const bmiV = w ? bmi(w, p.heightCm) : undefined;
  const bmiC = bmiV ? bmiClass(bmiV) : undefined;
  const toneColor = (tone?: 'good' | 'warn' | 'bad') => (tone === 'good' ? t.good : tone === 'warn' ? t.warn : tone === 'bad' ? t.bad : t.sub);

  const leanM = M('lean');
  const lf = firstWith(leanM), ll = lastWith(leanM);
  const leanGain = lf && ll && lf !== ll ? leanM.get(ll.e, ll.d)! - leanM.get(lf.e, lf.d)! : null;
  const goal = data.settings.leanGoalKg;

  const measure = (['neck', 'shoulders', 'chest', 'armL', 'armR', 'waist', 'hip', 'thighL', 'thighR'] as const).map((k) => {
    const withK = entries.filter((e) => e[k] != null);
    const l = withK[withK.length - 1], f = withK[0];
    const labels: Record<string, string> = { neck: 'Pescoço', shoulders: 'Ombros', chest: 'Peito', armL: 'Braço esq.', armR: 'Braço dir.', waist: 'Cintura', hip: 'Anca', thighL: 'Coxa esq.', thighR: 'Coxa dir.' };
    return { key: k, label: labels[k], value: l?.[k], delta: l && f && l !== f ? (l[k] as number) - (f[k] as number) : undefined };
  });

  type Insight = { title: string; value: string; tag?: string; tone?: 'good' | 'warn' | 'bad'; why: string; missing?: string };
  const ins: Insight[] = [];
  ins.push(
    D.bfNavy != null
      ? { title: '% gordura · Marinha EUA', value: `${fmtNum(D.bfNavy)} %`, tag: bfClass(D.bfNavy, p.sex), why: 'Calculada com cintura, pescoço e altura. Erro típico de ±3–4 % face a DEXA — bom para seguir a tendência.' }
      : { title: '% gordura · Marinha EUA', value: '—', why: 'O método mais usado só com fita métrica.', missing: p.sex === 'm' ? 'pescoço e cintura' : 'pescoço, cintura e anca' },
  );
  if (D.bfRFM != null) ins.push({ title: '% gordura · RFM', value: `${fmtNum(D.bfRFM)} %`, tag: bfClass(D.bfRFM, p.sex), why: 'Relative Fat Mass: só cintura e altura. Serve de segunda opinião ao valor acima.' });
  ins.push(
    D.whtr != null
      ? { title: 'Cintura / altura', value: fmtNum(D.whtr, 2), tag: D.whtr < 0.5 ? 'Saudável' : D.whtr < 0.6 ? 'Atenção' : 'Risco elevado', tone: D.whtr < 0.5 ? 'good' : D.whtr < 0.6 ? 'warn' : 'bad', why: 'Melhor indicador de gordura abdominal e risco cardiovascular do que o IMC. Abaixo de 0,50 é o objetivo.' }
      : { title: 'Cintura / altura', value: '—', why: 'Indicador de gordura abdominal.', missing: 'cintura' },
  );
  ins.push(
    D.vtaper != null
      ? { title: 'Ombros / cintura (forma em V)', value: fmtNum(D.vtaper, 2), tag: D.vtaper >= 1.55 ? 'Forma em V marcada' : D.vtaper >= 1.4 ? 'Boa' : 'A desenvolver', tone: D.vtaper >= 1.4 ? 'good' : undefined, why: 'A proporção estética de referência é ~1,6 (o "rácio de Adónis"). Sobe com ombros e costas, desce a cintura.' }
      : { title: 'Ombros / cintura (forma em V)', value: '—', why: 'Mede a silhueta em V.', missing: 'ombros e cintura' },
  );
  if (D.ffmi)
    ins.push({ title: 'FFMI (índice de massa magra)', value: fmtNum(D.ffmi.norm), tag: ffmiClass(D.ffmi.norm), why: `Massa magra ajustada à altura (normalizado a 1,80 m). Mostra quanto músculo tens independentemente da gordura. ~25 é o teto típico natural. Calculado com a gordura de ${D.bfSource}.` });
  if (D.whr != null) ins.push({ title: 'Cintura / anca', value: fmtNum(D.whr, 2), tag: D.whr < (p.sex === 'm' ? 0.9 : 0.85) ? 'Saudável' : 'Elevado', tone: D.whr < (p.sex === 'm' ? 0.9 : 0.85) ? 'good' : 'warn', why: 'Critério da OMS para distribuição de gordura.' });
  if (D.armDiff != null) ins.push({ title: 'Assimetria dos braços', value: `${fmtNum(D.armDiff)} %`, tag: D.armDiff < 3 ? 'Equilibrado' : 'A corrigir', tone: D.armDiff < 3 ? 'good' : 'warn', why: 'Diferença entre esquerdo e direito. Acima de 3 % vale a pena começar as séries unilaterais pelo lado mais fraco.' });
  if (D.thighDiff != null) ins.push({ title: 'Assimetria das coxas', value: `${fmtNum(D.thighDiff)} %`, tag: D.thighDiff < 3 ? 'Equilibrado' : 'A corrigir', tone: D.thighDiff < 3 ? 'good' : 'warn', why: 'Diferença entre coxa esquerda e direita.' });

  const hasScale = latest.fat != null || latest.musclePct != null || latest.water != null || latest.kcal != null;
  const protein = w ? [Math.round(w * 1.6), Math.round(w * 2.2)] : null;
  const actLabel = ACTIVITY.find((a) => a.k === p.activity)?.label ?? '';

  return (
    <ScrollView style={{ backgroundColor: t.bg }} contentContainerStyle={{ padding: 16, paddingBottom: 60 }}>
      <Card onPress={() => nav.navigate('Settings')}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ flex: 1 }}>
            <T size={13} sub>
              {p.name ? `${p.name} · ` : ''}
              {age} anos · {fmtNum(p.heightCm, 0)} cm · {p.sex === 'm' ? 'homem' : 'mulher'}
            </T>
            <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 8, marginTop: 2 }}>
              <T size={26} weight="800">
                IMC {bmiV ? fmtNum(bmiV) : '—'}
              </T>
              {bmiC ? (
                <T size={13} weight="700" color={toneColor(bmiC.tone)}>
                  {bmiC.label}
                </T>
              ) : null}
            </View>
          </View>
          <Ionicons name="chevron-forward" size={18} color={t.faint} />
        </View>
        {bmiV && bmiC?.tone !== 'good' && D.bfBest != null && D.bfBest < (p.sex === 'm' ? 20 : 28) ? (
          <T size={12} sub style={{ marginTop: 6, lineHeight: 17 }}>
            O IMC não distingue músculo de gordura. Com a tua % de gordura, o valor do IMC não é preocupante.
          </T>
        ) : null}
        <Divider />
        <View style={{ flexDirection: 'row' }}>
          <Mini label="Metabolismo basal" value={D.bmr ? `${Math.round(D.bmr)} kcal` : '—'} />
          <Mini label="Gasto diário" value={D.tdee ? `${Math.round(D.tdee)} kcal` : '—'} />
          <Mini label="Proteína/dia" value={protein ? `${protein[0]}–${protein[1]} g` : '—'} />
        </View>
      </Card>

      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 10 }}>
        {(['weight', 'bf', 'lean', 'ffmi'] as Key[]).map((k) => {
          const m = M(k);
          const l = lastWith(m);
          const idx = l ? rows.indexOf(l) : -1;
          const prev = idx > 0 ? [...rows.slice(0, idx)].reverse().find((r) => m.get(r.e, r.d) != null) : undefined;
          const v = l ? m.get(l.e, l.d)! : undefined;
          const dlt = l && prev ? v! - m.get(prev.e, prev.d)! : null;
          const good = dlt == null || m.goodUp == null ? null : m.goodUp ? dlt > 0 : dlt < 0;
          const est = k === 'bf' && v == null && bmiV ? bfDeurenberg(bmiV, age, p.sex) : null;
          return (
            <Card key={k} style={{ width: '48%' }} onPress={() => setMetric(k)}>
              <T size={12} sub>
                {m.label}
              </T>
              <T size={22} weight="800" style={{ marginTop: 2 }}>
                {v != null ? fmtNum(v, m.digits ?? 1) : est != null ? `~${fmtNum(est, 0)}` : '—'}
                <T size={13} sub>
                  {' '}
                  {m.unit}
                </T>
              </T>
              {dlt != null && Math.abs(dlt) >= 0.05 ? (
                <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 2 }}>
                  <Ionicons name={dlt > 0 ? 'arrow-up' : 'arrow-down'} size={12} color={good == null ? t.sub : good ? t.good : t.bad} />
                  <T size={12} color={good == null ? t.sub : good ? t.good : t.bad}>
                    {fmtNum(Math.abs(dlt), m.digits ?? 1)} vs. anterior
                  </T>
                </View>
              ) : (
                <T size={11} faint style={{ marginTop: 2 }} numberOfLines={1}>
                  {k === 'bf' && D.bfSource ? `via ${D.bfSource}` : k === 'bf' && est != null ? 'estimativa pelo IMC' : k === 'ffmi' && D.ffmi ? ffmiClass(D.ffmi.norm) : ' '}
                </T>
              )}
            </Card>
          );
        })}
      </View>

      {leanGain != null && (
        <Card style={{ marginTop: 10 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <T weight="700">Meta de recomposição</T>
            <T sub size={13}>
              {leanGain >= 0 ? '+' : ''}
              {fmtNum(leanGain)} / +{goal} kg magra
            </T>
          </View>
          <View style={{ height: 10, backgroundColor: t.card2, borderRadius: 5, marginTop: 10, overflow: 'hidden' }}>
            <View style={{ width: `${Math.max(0, Math.min(100, (leanGain / goal) * 100))}%`, height: 10, backgroundColor: t.good, borderRadius: 5 }} />
          </View>
        </Card>
      )}

      <Section title="O que as tuas medidas dizem">
        <Card style={{ paddingVertical: 4 }}>
          {ins.map((it, i) => (
            <View key={it.title} style={{ paddingVertical: 12, borderTopWidth: i ? 0.5 : 0, borderColor: t.border }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <T weight="700" style={{ flex: 1 }}>
                  {it.title}
                </T>
                <T size={17} weight="800">
                  {it.value}
                </T>
              </View>
              {it.tag ? (
                <T size={12} weight="700" color={toneColor(it.tone)} style={{ marginTop: 2 }}>
                  {it.tag}
                </T>
              ) : null}
              <T size={12} sub style={{ marginTop: 4, lineHeight: 17 }}>
                {it.why}
              </T>
              {it.missing ? (
                <Pressable onPress={() => nav.navigate('BodyEntry', {})} style={{ flexDirection: 'row', alignItems: 'center', marginTop: 6 }}>
                  <Ionicons name="add-circle-outline" size={15} color={t.accent} />
                  <T size={12} color={t.accent} style={{ marginLeft: 4 }}>
                    Mede {it.missing} para desbloquear
                  </T>
                </Pressable>
              ) : null}
            </View>
          ))}
        </Card>
      </Section>

      {hasScale && (
        <Section title="Balança de bioimpedância">
          <Card>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', rowGap: 14 }}>
              {latest.fat != null && <Mini label="Gordura" value={`${fmtNum(latest.fat)} %`} sub={w ? `${fmtNum((w * latest.fat) / 100)} kg` : undefined} w="33%" />}
              {latest.musclePct != null && <Mini label="Músculo" value={`${fmtNum(latest.musclePct)} %`} sub={D.muscleKg ? `${fmtNum(D.muscleKg)} kg` : undefined} w="33%" />}
              {latest.water != null && <Mini label="Hidratação" value={`${fmtNum(latest.water)} %`} sub={latest.water < (p.sex === 'm' ? 50 : 45) ? 'baixa' : 'normal'} w="33%" />}
              {latest.bonePct != null && <Mini label="Massa óssea" value={`${fmtNum(latest.bonePct)} %`} w="33%" />}
              {latest.visceral != null && <Mini label="Visceral" value={fmtNum(latest.visceral)} sub={latest.visceral <= 9 ? 'normal' : 'elevada'} w="33%" />}
              {latest.kcal != null && <Mini label="Kcal (balança)" value={`${Math.round(latest.kcal)}`} sub={D.tdee ? `app: ${Math.round(D.tdee)}` : undefined} w="33%" />}
            </View>
            <T size={12} sub style={{ marginTop: 12, lineHeight: 17 }}>
              A bioimpedância mede a resistência elétrica do corpo e depende muito da água: pesa-te sempre à mesma hora, em jejum. A % de gordura pela fita (Marinha) é usada como referência quando existe.
            </T>
          </Card>
        </Section>
      )}

      <Section title="Silhueta">
        <Card>
          <MeasureSilhouette items={measure} height={320} />
          <T size={12} sub style={{ textAlign: 'center', marginTop: 4 }}>
            Valores atuais e variação desde o primeiro registo
          </T>
        </Card>
      </Section>

      <Section title="Evolução">
        <Card>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
            {BODY_METRICS.filter((m) => rows.some((r) => m.get(r.e, r.d) != null)).map((m) => (
              <Chip key={m.k} label={m.label} active={metric === m.k} onPress={() => setMetric(m.k)} />
            ))}
          </ScrollView>
          <LineChart data={series} unit={cur.unit} digits={cur.digits ?? 1} color={cur.goodUp === false ? t.warn : cur.goodUp ? t.good : t.accent} />
        </Card>
      </Section>

      <Section
        title="Registos"
        right={
          <Pressable onPress={() => nav.navigate('BodyEntry', {})}>
            <T color={t.accent} weight="600" size={14}>
              + Novo
            </T>
          </Pressable>
        }
      >
        {[...entries].reverse().map((e) => {
          const parts: string[] = [];
          if (e.weight != null) parts.push(`${fmtNum(e.weight)} kg`);
          if (e.fat != null) parts.push(`gordura ${fmtNum(e.fat)}%`);
          const nMeas = (['neck', 'shoulders', 'chest', 'waist', 'hip', 'armL', 'armR', 'thighL', 'thighR', 'calf'] as const).filter((k) => e[k] != null).length;
          if (nMeas) parts.push(`${nMeas} medidas`);
          return (
            <Card key={e.id} style={{ marginBottom: 8 }} onPress={() => nav.navigate('BodyEntry', { id: e.id })}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <T weight="700">{fmtDate(isoToTs(e.date))}</T>
                <Ionicons name="chevron-forward" size={16} color={t.faint} />
              </View>
              <T size={13} sub style={{ marginTop: 4 }}>
                {parts.join(' · ')}
              </T>
            </Card>
          );
        })}
      </Section>
    </ScrollView>
  );
}

function Mini({ label, value, sub, w }: { label: string; value: string; sub?: string; w?: `${number}%` }) {
  return (
    <View style={{ flex: w ? undefined : 1, width: w }}>
      <T size={11} sub numberOfLines={1}>
        {label}
      </T>
      <T size={15} weight="800" style={{ marginTop: 2 }}>
        {value}
      </T>
      {sub ? (
        <T size={11} faint>
          {sub}
        </T>
      ) : null}
    </View>
  );
}
