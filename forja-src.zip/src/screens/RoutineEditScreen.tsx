import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import React, { useLayoutEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { ExerciseDemo } from '../components/ExerciseDemo';
import { ExercisePicker } from '../components/ExercisePicker';
import { Btn, Card, Chip, Ionicons, T } from '../components/ui';
import type { Nav, RootStack } from '../nav';
import { Routine, RoutineExercise, supersets, useStore } from '../store';
import { useTheme } from '../theme';
import { fmtSecs, uid } from '../util';

const RESTS = [45, 60, 90, 120, 150, 180];

export default function RoutineEditScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { params } = useRoute<RouteProp<RootStack, 'RoutineEdit'>>();
  const { data, saveRoutine, exById } = useStore();
  const existing = data.routines.find((r) => r.id === params?.id);
  const [r, setR] = useState<Routine>(existing ?? { id: 'u_' + uid(), name: '', place: 'gym', note: '', exercises: [] });
  const [picker, setPicker] = useState(false);

  const save = () => {
    saveRoutine({ ...r, name: r.name.trim() || 'Nova rotina' });
    nav.goBack();
  };

  useLayoutEffect(() => {
    nav.setOptions({
      title: existing ? 'Editar rotina' : 'Nova rotina',
      headerRight: () => (
        <Pressable onPress={save} hitSlop={10}>
          <T color={t.accent} weight="700" size={16}>
            Guardar
          </T>
        </Pressable>
      ),
    });
  });

  const patch = (i: number, p: Partial<RoutineExercise>) => setR((x) => ({ ...x, exercises: x.exercises.map((e, j) => (j === i ? { ...e, ...p } : e)) }));
  // Liga/desliga a super série entre o exercício i e o seguinte
  const toggleLink = (i: number) =>
    setR((x) => {
      const arr = x.exercises.map((e) => ({ ...e }));
      const a = arr[i], b = arr[i + 1];
      if (a.group && a.group === b.group) {
        // separa: tudo a partir de b fica num grupo novo (ou sozinho)
        const g = a.group, ng = 'ss_' + uid();
        for (let k = i + 1; k < arr.length && arr[k].group === g; k++) arr[k].group = ng;
      } else {
        const g = a.group || b.group || 'ss_' + uid();
        const old = b.group;
        for (let k = i + 1; k < arr.length && (k === i + 1 || (old && arr[k].group === old)); k++) arr[k].group = g;
        a.group = g;
      }
      // grupos com 1 só exercício deixam de ser super série
      const count = new Map<string, number>();
      arr.forEach((e) => e.group && count.set(e.group, (count.get(e.group) ?? 0) + 1));
      return { ...x, exercises: arr.map((e) => (e.group && (count.get(e.group) ?? 0) < 2 ? { ...e, group: undefined } : e)) };
    });

  const move = (i: number, d: number) =>
    setR((x) => {
      const arr = [...x.exercises];
      const j = i + d;
      if (j < 0 || j >= arr.length) return x;
      [arr[i], arr[j]] = [arr[j], arr[i]];
      return { ...x, exercises: arr };
    });

  return (
    <View style={{ flex: 1, backgroundColor: t.bg }}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 80 }} keyboardShouldPersistTaps="handled">
        <TextInput
          value={r.name}
          onChangeText={(name) => setR({ ...r, name })}
          placeholder="Nome da rotina"
          placeholderTextColor={t.faint}
          style={{ fontSize: 22, fontWeight: '800', color: t.text, paddingVertical: 6 }}
        />
        <View style={{ flexDirection: 'row', marginTop: 8 }}>
          <Chip label="Ginásio" active={r.place === 'gym'} onPress={() => setR({ ...r, place: 'gym' })} />
          <Chip label="Casa" active={r.place === 'home'} onPress={() => setR({ ...r, place: 'home' })} />
        </View>
        <TextInput
          value={r.note}
          onChangeText={(note) => setR({ ...r, note })}
          placeholder="Notas da rotina"
          placeholderTextColor={t.faint}
          multiline
          style={{ fontSize: 14, color: t.sub, marginTop: 12 }}
        />

        {r.exercises.map((e, i) => {
          const ex = exById(e.exerciseId);
          const ssl = supersets(r.exercises);
          const ss = ssl[i];
          const next = r.exercises[i + 1];
          const linked = !!(ss && next && next.group === e.group);
          return (
            <View key={e.exerciseId + i}>
            <Card style={{ marginTop: ss && !ss.first ? 0 : 12, ...(ss ? { borderWidth: 1.5, borderColor: 'rgba(255,122,26,0.45)' } : {}) }}>
              {ss?.first && (
                <T size={11} weight="900" color="#FF7A1A" style={{ marginBottom: 8 }}>
                  ⚡ SUPER SÉRIE {ss.letter} · descanso só depois do último
                </T>
              )}
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <ExerciseDemo id={e.exerciseId} size={40} animate={false} radius={20} />
                <T weight="700" style={{ flex: 1, marginLeft: 10 }} numberOfLines={2}>
                  {ss ? <T weight="900" color="#FF7A1A">{`${ss.letter}${ss.idx}  `}</T> : null}
                  {ex?.name ?? e.exerciseId}
                </T>
                <Pressable onPress={() => move(i, -1)} hitSlop={6} style={{ padding: 4 }}>
                  <Ionicons name="chevron-up" size={20} color={t.sub} />
                </Pressable>
                <Pressable onPress={() => move(i, 1)} hitSlop={6} style={{ padding: 4 }}>
                  <Ionicons name="chevron-down" size={20} color={t.sub} />
                </Pressable>
                <Pressable onPress={() => setR((x) => ({ ...x, exercises: x.exercises.filter((_, j) => j !== i) }))} hitSlop={6} style={{ padding: 4 }}>
                  <Ionicons name="trash-outline" size={19} color={t.bad} />
                </Pressable>
              </View>
              <View style={st.grid}>
                <Field label="Séries">
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                    <Pressable onPress={() => patch(i, { sets: Math.max(1, e.sets - 1) })}>
                      <Ionicons name="remove-circle-outline" size={24} color={t.accent} />
                    </Pressable>
                    <T weight="700" size={16}>
                      {e.sets}
                    </T>
                    <Pressable onPress={() => patch(i, { sets: Math.min(10, e.sets + 1) })}>
                      <Ionicons name="add-circle-outline" size={24} color={t.accent} />
                    </Pressable>
                  </View>
                </Field>
                <Field label={ex?.type === 'time' ? 'Segundos' : 'Reps'}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <NumIn v={e.repMin} on={(n) => patch(i, { repMin: n })} />
                    <T sub> – </T>
                    <NumIn v={e.repMax} on={(n) => patch(i, { repMax: n })} />
                  </View>
                </Field>
                <Field label="Descanso">
                  <Pressable onPress={() => patch(i, { restSec: RESTS[(RESTS.indexOf(e.restSec) + 1) % RESTS.length] })}>
                    <T weight="700" color={t.accent} size={16}>
                      {fmtSecs(e.restSec)}
                    </T>
                  </Pressable>
                </Field>
              </View>
            </Card>
            {next && (
              <Pressable onPress={() => toggleLink(i)} hitSlop={6} style={{ alignSelf: 'center', flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 6 }}>
                <Ionicons name={linked ? 'flash' : 'flash-outline'} size={14} color={linked ? '#FF7A1A' : t.faint} />
                <T size={12} weight="700" color={linked ? '#FF7A1A' : t.faint}>
                  {linked ? 'Em super série com o seguinte (toca para separar)' : 'Juntar ao seguinte em super série'}
                </T>
              </Pressable>
            )}
            </View>
          );
        })}

        <Btn title="Adicionar exercícios" icon="add" style={{ marginTop: 16 }} onPress={() => setPicker(true)} />
      </ScrollView>
      <ExercisePicker
        visible={picker}
        onClose={() => setPicker(false)}
        onPick={(ids) =>
          setR((x) => ({
            ...x,
            exercises: [...x.exercises, ...ids.map((id) => ({ exerciseId: id, sets: 3, repMin: 8, repMax: 12, restSec: data.settings.defaultRest }))],
          }))
        }
      />
    </View>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View style={{ alignItems: 'center', flex: 1 }}>
      <T size={11} faint weight="700" style={{ marginBottom: 6 }}>
        {label.toUpperCase()}
      </T>
      {children}
    </View>
  );
}

function NumIn({ v, on }: { v: number; on: (n: number) => void }) {
  const t = useTheme();
  const [s, setS] = useState(String(v));
  return (
    <TextInput
      value={s}
      keyboardType="number-pad"
      selectTextOnFocus
      onChangeText={(x) => {
        setS(x);
        const n = parseInt(x, 10);
        if (!Number.isNaN(n)) on(n);
      }}
      style={{ width: 40, textAlign: 'center', fontSize: 16, fontWeight: '700', color: t.text, backgroundColor: t.card2, borderRadius: 6, paddingVertical: 4 }}
    />
  );
}

const st = StyleSheet.create({
  grid: { flexDirection: 'row', marginTop: 12 },
});
