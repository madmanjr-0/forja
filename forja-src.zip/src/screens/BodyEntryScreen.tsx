import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import React, { useLayoutEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { Alert } from '../components/dialog';
import { Btn, Card, T } from '../components/ui';
import type { Nav, RootStack } from '../nav';
import { BodyEntry, useStore } from '../store';
import { useTheme } from '../theme';
import { fmtNum, parseNum, todayISO, uid } from '../util';

type F = keyof Omit<BodyEntry, 'id' | 'date'>;

const GROUPS: { title: string; hint: string; fields: { k: F; label: string; unit: string; tip?: string }[] }[] = [
  {
    title: 'Peso',
    hint: 'De manhã, depois da casa de banho e antes de comer.',
    fields: [{ k: 'weight', label: 'Peso', unit: 'kg' }],
  },
  {
    title: 'Balança de bioimpedância (opcional)',
    hint: 'Copia os valores que a balança mostra. Variam com a hidratação: compara sempre à mesma hora.',
    fields: [
      { k: 'fat', label: 'Gordura', unit: '%' },
      { k: 'water', label: 'Hidratação', unit: '%' },
      { k: 'musclePct', label: 'Músculo', unit: '%' },
      { k: 'bonePct', label: 'Massa óssea', unit: '%' },
      { k: 'visceral', label: 'Gordura visceral', unit: '' },
      { k: 'kcal', label: 'Kcal recomendadas', unit: 'kcal' },
    ],
  },
  {
    title: 'Medidas com fita (opcional)',
    hint: 'Uma vez por mês. Com cintura + pescoço a app calcula a tua % de gordura sem balança.',
    fields: [
      { k: 'neck', label: 'Pescoço', unit: 'cm', tip: 'Logo abaixo da maçã de Adão' },
      { k: 'shoulders', label: 'Ombros', unit: 'cm', tip: 'À volta, na parte mais larga' },
      { k: 'chest', label: 'Peito', unit: 'cm', tip: 'À altura dos mamilos' },
      { k: 'waist', label: 'Cintura', unit: 'cm', tip: 'No umbigo, no fim de expirar' },
      { k: 'hip', label: 'Anca', unit: 'cm', tip: 'Na parte mais larga dos glúteos' },
      { k: 'armL', label: 'Braço esquerdo', unit: 'cm', tip: 'Relaxado, a meio do braço' },
      { k: 'armR', label: 'Braço direito', unit: 'cm' },
      { k: 'thighL', label: 'Coxa esquerda', unit: 'cm', tip: 'A meio da coxa' },
      { k: 'thighR', label: 'Coxa direita', unit: 'cm' },
      { k: 'calf', label: 'Gémeo', unit: 'cm', tip: 'Na parte mais larga' },
    ],
  },
];

export default function BodyEntryScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { params } = useRoute<RouteProp<RootStack, 'BodyEntry'>>();
  const { data, saveBody, deleteBody } = useStore();
  const existing = data.body.find((b) => b.id === params?.id);
  const last = data.body[data.body.length - 1];
  const [date, setDate] = useState(existing?.date ?? todayISO());
  const [vals, setVals] = useState<Record<string, string>>(() => {
    const o: Record<string, string> = {};
    if (existing) GROUPS.forEach((g) => g.fields.forEach((f) => existing[f.k] != null && (o[f.k] = fmtNum(existing[f.k] as number, 2))));
    return o;
  });

  const save = () => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      Alert.alert('Data inválida', 'Usa o formato AAAA-MM-DD.');
      return;
    }
    const e: BodyEntry = { id: existing?.id ?? uid(), date };
    for (const g of GROUPS)
      for (const f of g.fields) {
        const n = parseNum(vals[f.k] ?? '');
        if (n != null) e[f.k] = n;
      }
    saveBody(e);
    nav.goBack();
  };

  useLayoutEffect(() => {
    nav.setOptions({
      headerLeft: () => (
        <Pressable onPress={() => nav.goBack()} hitSlop={10}>
          <T color={t.accent} size={16}>
            Cancelar
          </T>
        </Pressable>
      ),
      headerRight: () => (
        <Pressable onPress={save} hitSlop={10}>
          <T color={t.accent} weight="700" size={16}>
            Guardar
          </T>
        </Pressable>
      ),
    });
  });

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: t.bg }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <Card style={st.row}>
          <T style={{ flex: 1 }}>Data</T>
          <TextInput value={date} onChangeText={setDate} style={[st.in, { color: t.text, width: 130 }]} placeholder="AAAA-MM-DD" placeholderTextColor={t.faint} />
        </Card>
        {GROUPS.map((g) => (
          <View key={g.title} style={{ marginTop: 20 }}>
            <T size={13} weight="700" sub style={{ textTransform: 'uppercase', letterSpacing: 0.6 }}>
              {g.title}
            </T>
            <T size={12} faint style={{ marginBottom: 8, marginTop: 2 }}>
              {g.hint}
            </T>
            <Card style={{ paddingVertical: 4 }}>
              {g.fields.map((f, i) => (
                <View key={f.k} style={[st.row, i > 0 && { borderTopWidth: StyleSheet.hairlineWidth, borderColor: t.border }]}>
                  <View style={{ flex: 1 }}>
                    <T>{f.label}</T>
                    {f.tip ? (
                      <T size={11} faint>
                        {f.tip}
                      </T>
                    ) : null}
                  </View>
                  <TextInput
                    value={vals[f.k] ?? ''}
                    onChangeText={(v) => setVals((o) => ({ ...o, [f.k]: v }))}
                    keyboardType="decimal-pad"
                    placeholder={last && last[f.k] != null && !existing ? fmtNum(last[f.k] as number, 2) : '—'}
                    placeholderTextColor={t.faint}
                    style={[st.in, { color: t.text }]}
                  />
                  <T sub style={{ width: 38 }}>
                    {f.unit}
                  </T>
                </View>
              ))}
            </Card>
          </View>
        ))}
        <Btn title="Guardar" style={{ marginTop: 24 }} onPress={save} />
        {existing && (
          <Btn
            title="Apagar registo"
            kind="danger"
            style={{ marginTop: 10 }}
            onPress={() =>
              Alert.alert('Apagar registo?', undefined, [
                { text: 'Cancelar', style: 'cancel' },
                {
                  text: 'Apagar',
                  style: 'destructive',
                  onPress: () => {
                    deleteBody(existing.id);
                    nav.goBack();
                  },
                },
              ])
            }
          />
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10 },
  in: { textAlign: 'right', fontSize: 16, fontWeight: '600', width: 80, paddingVertical: 4, marginRight: 6 },
});
