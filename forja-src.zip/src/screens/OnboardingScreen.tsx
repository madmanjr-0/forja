import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Btn, Chip, Ionicons, T } from '../components/ui';
import { useStore } from '../store';
import { useTheme } from '../theme';
import { parseNum, todayISO, uid } from '../util';

/** Primeiro arranque: pede só idade, sexo, altura e peso. O resto calcula-se. */
export default function OnboardingScreen() {
  const t = useTheme();
  const { setProfile, saveBody } = useStore();
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [sex, setSex] = useState<'m' | 'f' | null>(null);
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [err, setErr] = useState('');

  const submit = () => {
    const a = parseNum(age), h = parseNum(height), w = parseNum(weight);
    if (!a || a < 14 || a > 99) return setErr('Indica uma idade entre 14 e 99 anos.');
    if (!sex) return setErr('Escolhe o sexo — é usado nas fórmulas de gordura e metabolismo.');
    if (!h || h < 120 || h > 230) return setErr('Indica a altura em centímetros (ex.: 169).');
    if (!w || w < 30 || w > 250) return setErr('Indica o peso em kg (ex.: 71,6).');
    setProfile({ name: name.trim() || undefined, age: Math.round(a), sex, heightCm: h, activity: 1.55, setAt: Date.now() });
    saveBody({ id: uid(), date: todayISO(), weight: w });
  };

  const field = (label: string, value: string, set: (v: string) => void, unit: string, placeholder: string, decimal = false) => (
    <View style={[st.row, { borderColor: t.border }]}>
      <T style={{ flex: 1 }} size={16}>
        {label}
      </T>
      <TextInput
        value={value}
        onChangeText={(v) => {
          set(v);
          setErr('');
        }}
        placeholder={placeholder}
        placeholderTextColor={t.faint}
        keyboardType={decimal ? 'decimal-pad' : 'number-pad'}
        style={[st.in, { color: t.text }]}
      />
      <T sub style={{ width: 42 }}>
        {unit}
      </T>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ padding: 24, paddingTop: 40, maxWidth: 520, width: '100%', alignSelf: 'center' }} keyboardShouldPersistTaps="handled">
          <View style={[st.logo, { backgroundColor: t.accent }]}>
            <Ionicons name="barbell" size={34} color="#fff" />
          </View>
          <T size={30} weight="900" style={{ marginTop: 18 }}>
            Bem-vindo à Forja
          </T>
          <T sub size={16} style={{ marginTop: 6, lineHeight: 23 }}>
            Para começar, só precisamos do teu ponto de partida. Tudo fica guardado apenas neste telemóvel.
          </T>

          <View style={[st.card, { backgroundColor: t.card, borderColor: t.border }]}>
            <View style={[st.row, { borderColor: t.border }]}>
              <T style={{ flex: 1 }} size={16}>
                Nome <T faint size={13}>(opcional)</T>
              </T>
              <TextInput value={name} onChangeText={setName} placeholder="Marcos" placeholderTextColor={t.faint} style={[st.in, { color: t.text, width: 140 }]} />
            </View>
            {field('Idade', age, setAge, 'anos', '24')}
            <View style={[st.row, { borderColor: t.border }]}>
              <T style={{ flex: 1 }} size={16}>
                Sexo
              </T>
              <Chip label="Homem" active={sex === 'm'} onPress={() => setSex('m')} />
              <Chip label="Mulher" active={sex === 'f'} onPress={() => setSex('f')} />
            </View>
            {field('Altura', height, setHeight, 'cm', '169', true)}
            <View style={[st.row, { borderBottomWidth: 0 }]}>
              <T style={{ flex: 1 }} size={16}>
                Peso
              </T>
              <TextInput
                value={weight}
                onChangeText={(v) => {
                  setWeight(v);
                  setErr('');
                }}
                placeholder="71,6"
                placeholderTextColor={t.faint}
                keyboardType="decimal-pad"
                style={[st.in, { color: t.text }]}
              />
              <T sub style={{ width: 42 }}>
                kg
              </T>
            </View>
          </View>

          {err ? (
            <T color={t.bad} size={14} style={{ marginTop: 12 }}>
              {err}
            </T>
          ) : null}

          <Btn title="Começar" style={{ marginTop: 20 }} onPress={submit} />
          <T faint size={13} style={{ marginTop: 14, lineHeight: 19, textAlign: 'center' }}>
            Medidas corporais e dados da balança de bioimpedância são opcionais. Podes adicioná-los depois no separador Corpo.
          </T>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const st = StyleSheet.create({
  logo: { width: 64, height: 64, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  card: { marginTop: 28, borderRadius: 16, borderWidth: StyleSheet.hairlineWidth, paddingHorizontal: 16 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  in: { textAlign: 'right', fontSize: 17, fontWeight: '700', width: 90, marginRight: 6, paddingVertical: 2 },
});
