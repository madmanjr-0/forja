import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import React, { useLayoutEffect, useMemo, useState } from 'react';
import { ScrollView, View } from 'react-native';
import { LineChart } from '../components/Charts';
import { ExerciseDemo } from '../components/ExerciseDemo';
import { ExerciseAbout } from '../components/ExerciseInfoSheet';
import { Card, Chip, Empty, Ionicons, Section, T } from '../components/ui';
import type { Nav, RootStack } from '../nav';
import { bestsOf, isWorking, useStore } from '../store';
import { useTheme } from '../theme';
import { e1rm, fmtDate, fmtNum } from '../util';

type Metric = 'e1rm' | 'maxKg' | 'vol' | 'reps' | 'secs';

export default function ExerciseDetailScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { params } = useRoute<RouteProp<RootStack, 'ExerciseDetail'>>();
  const { data, exById } = useStore();
  const ex = exById(params.id);
  const [tab, setTab] = useState<'sum' | 'how'>('sum');
  const [metric, setMetric] = useState<Metric>(ex?.type === 'time' ? 'secs' : ex?.type === 'reps' ? 'reps' : 'e1rm');

  useLayoutEffect(() => {
    nav.setOptions({ title: ex?.name ?? 'Exercício' });
  }, [nav, ex?.name]);

  const sessions = useMemo(
    () =>
      data.workouts
        .flatMap((w) => w.exercises.filter((e) => e.exerciseId === params.id).map((e) => ({ ts: w.start, wid: w.id, sets: e.sets.filter(isWorking) })))
        .filter((s) => s.sets.length)
        .sort((a, b) => a.ts - b.ts),
    [data.workouts, params.id],
  );

  const series = useMemo(
    () =>
      sessions.map((s) => {
        const b = bestsOf(s.sets);
        const vol = s.sets.reduce((a, x) => a + (x.kg ?? 0) * (x.reps ?? 0), 0);
        const y = { e1rm: b.e1rm, maxKg: b.maxKg, vol, reps: b.maxReps, secs: b.maxSecs }[metric];
        return { x: s.ts, y };
      }),
    [sessions, metric],
  );

  const records = useMemo(() => {
    const all = sessions.flatMap((s) => s.sets);
    const b = bestsOf(all);
    // Melhor carga por nº de reps (1–12)
    const byReps: { reps: number; kg: number }[] = [];
    for (let r = 1; r <= 12; r++) {
      const kg = Math.max(0, ...all.filter((s) => (s.reps ?? 0) >= r).map((s) => s.kg ?? 0));
      if (kg > 0) byReps.push({ reps: r, kg });
    }
    return { b, byReps };
  }, [sessions]);

  if (!ex) return null;

  const metrics: { k: Metric; label: string; unit: string }[] =
    ex.type === 'time'
      ? [{ k: 'secs', label: 'Tempo máx.', unit: 's' }]
      : ex.type === 'reps'
        ? [
            { k: 'reps', label: 'Reps máx.', unit: 'reps' },
            { k: 'maxKg', label: 'Carga extra', unit: 'kg' },
          ]
        : [
            { k: 'e1rm', label: '1RM estimado', unit: 'kg' },
            { k: 'maxKg', label: 'Carga máx.', unit: 'kg' },
            { k: 'vol', label: 'Volume', unit: 'kg' },
            { k: 'reps', label: 'Reps máx.', unit: 'reps' },
          ];
  const cur = metrics.find((m) => m.k === metric) ?? metrics[0];

  return (
    <View style={{ flex: 1, backgroundColor: t.bg }}>
      <View style={{ flexDirection: 'row', paddingHorizontal: 16, paddingBottom: 8 }}>
        <Chip label="Resumo" active={tab === 'sum'} onPress={() => setTab('sum')} />
        <Chip label="Como fazer" active={tab === 'how'} onPress={() => setTab('how')} />
      </View>
      {tab === 'how' ? (
        <ExerciseAbout id={ex.id} />
      ) : (
        <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 4, paddingBottom: 60 }}>
          <ExerciseDemo id={ex.id} size="full" radius={16} />
          {sessions.length === 0 ? (
            <Empty icon="analytics-outline" title="Sem registos ainda" text="Faz este exercício num treino para veres a evolução." />
          ) : (
            <>
              <Section title="Evolução">
                <Card>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
                    {metrics.map((m) => (
                      <Chip key={m.k} label={m.label} active={metric === m.k} onPress={() => setMetric(m.k)} />
                    ))}
                  </ScrollView>
                  <LineChart data={series} unit={cur.unit} digits={metric === 'vol' ? 0 : 1} />
                </Card>
              </Section>

              <Section title="Recordes pessoais">
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
                  {ex.type === 'weight' && <Rec label="Carga máxima" v={`${fmtNum(records.b.maxKg)} kg`} />}
                  {ex.type === 'weight' && <Rec label="1RM estimado" v={`${fmtNum(records.b.e1rm)} kg`} />}
                  {ex.type === 'weight' && <Rec label="Melhor série" v={`${Math.round(records.b.setVol)} kg`} />}
                  {ex.type !== 'time' && <Rec label="Mais reps" v={`${records.b.maxReps}`} />}
                  {ex.type === 'time' && <Rec label="Mais tempo" v={`${records.b.maxSecs} s`} />}
                  <Rec label="Sessões" v={String(sessions.length)} />
                </View>
              </Section>

              {ex.type === 'weight' && records.byReps.length > 0 && (
                <Section title="Melhor carga por reps">
                  <Card>
                    {records.byReps.map((r) => (
                      <View key={r.reps} style={{ flexDirection: 'row', paddingVertical: 5 }}>
                        <T sub style={{ width: 80 }}>
                          {r.reps} rep{r.reps > 1 ? 's' : ''}
                        </T>
                        <T weight="700" style={{ flex: 1 }}>
                          {fmtNum(r.kg)} kg
                        </T>
                        <T size={12} faint>
                          1RM≈{fmtNum(e1rm(r.kg, r.reps))}
                        </T>
                      </View>
                    ))}
                  </Card>
                </Section>
              )}

              <Section title="Histórico">
                {[...sessions].reverse().map((s) => (
                  <Card key={s.wid + s.ts} style={{ marginBottom: 8 }} onPress={() => nav.navigate('WorkoutDetail', { id: s.wid })}>
                    <T weight="700" size={14}>
                      {fmtDate(s.ts)}
                    </T>
                    <T size={13} sub style={{ marginTop: 4 }}>
                      {s.sets
                        .map((x) => (ex.type === 'time' ? `${x.secs}s` : ex.type === 'reps' ? `${x.reps}${x.kg ? `(+${fmtNum(x.kg)})` : ''}` : `${fmtNum(x.kg ?? 0)}×${x.reps}`))
                        .join('   ')}
                    </T>
                  </Card>
                ))}
              </Section>
            </>
          )}
        </ScrollView>
      )}
    </View>
  );
}

function Rec({ label, v }: { label: string; v: string }) {
  const t = useTheme();
  return (
    <Card style={{ width: '48%', paddingVertical: 12 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Ionicons name="trophy-outline" size={13} color={t.gold} />
        <T size={12} sub style={{ marginLeft: 4 }}>
          {label}
        </T>
      </View>
      <T size={19} weight="800" style={{ marginTop: 4 }}>
        {v}
      </T>
    </Card>
  );
}
