import { useNavigation } from '@react-navigation/native';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { Card, Ionicons, T } from '../components/ui';
import type { Nav } from '../nav';
import { workoutMark } from '../plan';
import { bestsOf, prsInWorkout, useStore, Workout, workoutSets, workoutVolume } from '../store';
import { useTheme } from '../theme';
import { fmtDate, fmtKg, fmtMin, fmtNum } from '../util';

const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
const DIAS = ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'];
const dayKey = (d: Date) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;

export default function HistoryScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { data, exById } = useStore();
  const today = new Date();
  const [month, setMonth] = useState({ y: today.getFullYear(), m: today.getMonth() });
  const [sel, setSel] = useState<string | null>(null);

  const byDay = useMemo(() => {
    const map = new Map<string, Workout[]>();
    for (const w of [...data.workouts].sort((a, b) => a.start - b.start)) {
      const k = dayKey(new Date(w.start));
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(w);
    }
    return map;
  }, [data.workouts]);

  const typeColor = (w: Workout) => {
    const r = data.routines.find((x) => x.id === w.routineId);
    if (!r) return '#8A7CFF';
    return r.place === 'home' ? t.good : t.accent;
  };

  // Grelha do mês com semanas a começar à segunda
  const first = new Date(month.y, month.m, 1);
  const offset = (first.getDay() + 6) % 7;
  const days = new Date(month.y, month.m + 1, 0).getDate();
  const cells: { date: Date; inMonth: boolean }[] = [];
  for (let i = 0; i < offset; i++) cells.push({ date: new Date(month.y, month.m, i - offset + 1), inMonth: false });
  for (let d = 1; d <= days; d++) cells.push({ date: new Date(month.y, month.m, d), inMonth: true });
  while (cells.length % 7) cells.push({ date: new Date(month.y, month.m + 1, cells.length - offset - days + 1), inMonth: false });

  const monthWorkouts = data.workouts.filter((w) => {
    const d = new Date(w.start);
    return d.getFullYear() === month.y && d.getMonth() === month.m;
  });
  const mDur = monthWorkouts.reduce((a, w) => a + ((w.end ?? w.start) - w.start), 0);
  const mVol = monthWorkouts.reduce((a, w) => a + workoutVolume(w), 0);

  const shift = (d: number) => {
    setSel(null);
    setMonth(({ y, m }) => {
      const n = new Date(y, m + d, 1);
      return { y: n.getFullYear(), m: n.getMonth() };
    });
  };

  const selList = sel ? byDay.get(sel) ?? [] : [];

  return (
    <ScrollView style={{ backgroundColor: t.bg }} contentContainerStyle={{ padding: 16, paddingBottom: 60 }}>
      <View style={[st.cal, { backgroundColor: t.card, borderColor: t.border }]}>
        <View style={st.head}>
          <Pressable onPress={() => shift(-1)} hitSlop={10} style={st.nav} accessibilityLabel="Mês anterior">
            <Ionicons name="chevron-back" size={22} color={t.text} />
          </Pressable>
          <View style={{ alignItems: 'center' }}>
            <T size={17} weight="800">
              {MESES[month.m]} {month.y}
            </T>
            <T size={12} sub>
              {monthWorkouts.length} treino{monthWorkouts.length === 1 ? '' : 's'}
              {monthWorkouts.length ? ` · ${fmtMin(mDur)} · ${fmtKg(mVol)}` : ''}
            </T>
          </View>
          <Pressable onPress={() => shift(1)} hitSlop={10} style={st.nav} accessibilityLabel="Mês seguinte">
            <Ionicons name="chevron-forward" size={22} color={t.text} />
          </Pressable>
        </View>
        <View style={st.grid}>
          {DIAS.map((d, i) => (
            <T key={i} size={12} weight="700" faint style={st.dow}>
              {d}
            </T>
          ))}
        </View>
        <View style={st.grid}>
          {cells.map((c, i) => {
            const k = dayKey(c.date);
            const ws = byDay.get(k);
            const w = ws?.[ws.length - 1];
            const isToday = k === dayKey(today);
            const isSel = k === sel;
            const mark = w ? workoutMark(w, data.routines) : '';
            return (
              <Pressable
                key={i}
                disabled={!ws}
                onPress={() => setSel(isSel ? null : k)}
                style={[st.cell, { backgroundColor: isSel ? t.card2 : 'transparent', opacity: c.inMonth ? 1 : 0.35 }]}
              >
                <T size={13} weight={isToday ? '900' : '600'} color={isToday ? t.accent : t.text}>
                  {c.date.getDate()}
                </T>
                <View
                  style={{
                    width: 26,
                    height: 26,
                    borderRadius: 13,
                    marginTop: 3,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: w ? typeColor(w) : 'transparent',
                    borderWidth: isToday && !w ? 2 : 0,
                    borderColor: t.accent,
                  }}
                >
                  {w ? (
                    mark === '✓' ? (
                      <Ionicons name="checkmark" size={14} color="#fff" />
                    ) : (
                      <T size={mark.length > 1 ? 9 : 11} weight="900" color="#fff">
                        {mark}
                      </T>
                    )
                  ) : null}
                </View>
                {ws && ws.length > 1 ? (
                  <T size={9} weight="800" color={t.sub}>
                    +{ws.length - 1}
                  </T>
                ) : null}
              </Pressable>
            );
          })}
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 16, paddingTop: 10 }}>
          <Legend color={t.accent} label="Ginásio" />
          <Legend color={t.good} label="Casa" />
          <Legend color="#8A7CFF" label="Livre" />
        </View>
      </View>

      {!sel ? (
        <T faint style={{ textAlign: 'center', marginTop: 22 }}>
          {data.workouts.length ? 'Toca num dia marcado para veres o treino.' : 'Ainda sem treinos. Quando terminares o primeiro, aparece aqui.'}
        </T>
      ) : (
        <View style={{ marginTop: 14, gap: 10 }}>
          {selList.map((w) => (
            <WorkoutCard key={w.id} w={w} onPress={() => nav.navigate('WorkoutDetail', { id: w.id })} />
          ))}
        </View>
      )}
    </ScrollView>
  );

  function WorkoutCard({ w, onPress }: { w: Workout; onPress: () => void }) {
    const prs = prsInWorkout(w, data.workouts).length;
    return (
      <Card onPress={onPress}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <View style={{ flex: 1 }}>
            <T size={16} weight="700">
              {w.name}
            </T>
            <T size={13} sub>
              {fmtDate(w.start)} · {new Date(w.start).toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}
            </T>
          </View>
          {prs > 0 && (
            <View style={[st.pr, { backgroundColor: t.dark ? '#3A2F12' : '#FFF4D6' }]}>
              <Ionicons name="trophy" size={13} color={t.gold} />
              <T size={12} weight="700" color={t.gold} style={{ marginLeft: 4 }}>
                {prs} PR
              </T>
            </View>
          )}
        </View>
        <View style={{ flexDirection: 'row', gap: 18, marginTop: 10 }}>
          <T size={13} weight="700">{fmtMin((w.end ?? w.start) - w.start)}</T>
          <T size={13} weight="700">{fmtKg(workoutVolume(w))}</T>
          <T size={13} weight="700">{workoutSets(w)} séries</T>
        </View>
        <View style={{ marginTop: 8 }}>
          {w.exercises.slice(0, 4).map((e) => {
            const b = bestsOf(e.sets);
            const ex = exById(e.exerciseId);
            const best = ex?.type === 'time' ? `${b.maxSecs} s` : b.maxKg ? `${fmtNum(b.maxKg)} kg` : `${b.maxReps} reps`;
            return (
              <View key={e.id} style={{ flexDirection: 'row', marginTop: 3 }}>
                <T size={13} sub style={{ flex: 1 }} numberOfLines={1}>
                  {e.sets.length} × {ex?.name ?? '?'}
                </T>
                <T size={13} faint>
                  {best}
                </T>
              </View>
            );
          })}
          {w.exercises.length > 4 && (
            <T size={13} faint style={{ marginTop: 3 }}>
              +{w.exercises.length - 4} exercícios
            </T>
          )}
        </View>
        <T size={14} weight="700" color={t.accent} style={{ marginTop: 8 }}>
          Ver treino completo ›
        </T>
      </Card>
    );
  }
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
      <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: color }} />
      <T size={11} sub>
        {label}
      </T>
    </View>
  );
}

const st = StyleSheet.create({
  cal: { borderRadius: 20, borderWidth: StyleSheet.hairlineWidth, paddingHorizontal: 8, paddingTop: 12, paddingBottom: 12 },
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 4, paddingBottom: 10 },
  nav: { padding: 6 },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  dow: { width: `${100 / 7}%`, textAlign: 'center', paddingBottom: 6 },
  cell: { width: `${100 / 7}%`, height: 58, alignItems: 'center', paddingTop: 4, borderRadius: 12 },
  pr: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, borderRadius: 10, height: 24 },
});
