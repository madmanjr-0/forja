import { useNavigation } from '@react-navigation/native';
import React, { useMemo } from 'react';
import { SectionList, View } from 'react-native';
import { Card, Empty, Ionicons, T } from '../components/ui';
import type { Nav } from '../nav';
import { bestsOf, prsInWorkout, useStore, Workout, workoutSets, workoutVolume } from '../store';
import { useTheme } from '../theme';
import { fmtDate, fmtDuration, fmtKg, fmtNum } from '../util';

const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

export default function HistoryScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { data, exById } = useStore();

  const sections = useMemo(() => {
    const sorted = [...data.workouts].sort((a, b) => b.start - a.start);
    const map = new Map<string, Workout[]>();
    for (const w of sorted) {
      const d = new Date(w.start);
      const k = `${MESES[d.getMonth()]} ${d.getFullYear()}`;
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(w);
    }
    return [...map.entries()].map(([title, list]) => ({ title, data: list }));
  }, [data.workouts]);

  const prCount = useMemo(() => {
    const m = new Map<string, number>();
    for (const w of data.workouts) m.set(w.id, prsInWorkout(w, data.workouts).length);
    return m;
  }, [data.workouts]);

  if (!data.workouts.length)
    return (
      <View style={{ flex: 1, backgroundColor: t.bg }}>
        <Empty icon="calendar-outline" title="Ainda sem treinos" text="Quando terminares o primeiro treino ele aparece aqui, com volume, duração e recordes." />
      </View>
    );

  return (
    <SectionList
      style={{ backgroundColor: t.bg }}
      contentContainerStyle={{ padding: 16, paddingBottom: 60 }}
      sections={sections}
      keyExtractor={(w) => w.id}
      stickySectionHeadersEnabled={false}
      renderSectionHeader={({ section }) => (
        <T size={13} weight="700" sub style={{ marginTop: 12, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.6 }}>
          {section.title} · {section.data.length} treinos
        </T>
      )}
      renderItem={({ item: w }) => {
        const prs = prCount.get(w.id) ?? 0;
        return (
          <Card style={{ marginBottom: 10 }} onPress={() => nav.navigate('WorkoutDetail', { id: w.id })}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <View style={{ flex: 1 }}>
                <T size={16} weight="700">
                  {w.name}
                </T>
                <T size={13} sub>
                  {fmtDate(w.start)}
                </T>
              </View>
              {prs > 0 && (
                <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: t.dark ? '#3A2F12' : '#FFF4D6', paddingHorizontal: 8, borderRadius: 10, height: 24 }}>
                  <Ionicons name="trophy" size={13} color={t.gold} />
                  <T size={12} weight="700" color={t.gold} style={{ marginLeft: 4 }}>
                    {prs} PR
                  </T>
                </View>
              )}
            </View>
            <View style={{ flexDirection: 'row', gap: 18, marginTop: 10 }}>
              <Mini icon="time-outline" v={fmtDuration((w.end ?? w.start) - w.start)} />
              <Mini icon="barbell-outline" v={fmtKg(workoutVolume(w))} />
              <Mini icon="layers-outline" v={`${workoutSets(w)} séries`} />
            </View>
            <View style={{ marginTop: 10 }}>
              {w.exercises.slice(0, 5).map((e) => {
                const b = bestsOf(e.sets);
                const ex = exById(e.exerciseId);
                const best = ex?.type === 'time' ? `${b.maxSecs} s` : b.maxKg ? `${fmtNum(b.maxKg)} kg` : `${b.maxReps} reps`;
                return (
                  <View key={e.id} style={{ flexDirection: 'row', marginTop: 3 }}>
                    <T size={13} sub style={{ flex: 1 }} numberOfLines={1}>
                      {e.sets.length} × {ex?.name ?? '?'}
                    </T>
                    <T size={13} faint>
                      {best}
                    </T>
                  </View>
                );
              })}
              {w.exercises.length > 5 && (
                <T size={13} faint style={{ marginTop: 3 }}>
                  +{w.exercises.length - 5} exercícios
                </T>
              )}
            </View>
          </Card>
        );
      }}
    />
  );
}

function Mini({ icon, v }: { icon: any; v: string }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Ionicons name={icon} size={14} color={t.sub} />
      <T size={13} style={{ marginLeft: 4 }} weight="600">
        {v}
      </T>
    </View>
  );
}
