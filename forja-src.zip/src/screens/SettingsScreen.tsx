import React, { useState } from 'react';
import { Platform, ScrollView, Share, StyleSheet, TextInput, View } from 'react-native';
import { Alert } from '../components/dialog';
import { Btn, Card, Chip, Section, T } from '../components/ui';
import { ACTIVITY, ageNow } from '../bodycalc';
import { useStore } from '../store';
import { useTheme } from '../theme';

export default function SettingsScreen() {
  const t = useTheme();
  const { data, setSettings, setProfile, exportJSON, importJSON, resetRoutines } = useStore();
  const prof = data.profile!;
  const [paste, setPaste] = useState('');
  const [exported, setExported] = useState('');
  const [h, setH] = useState(String(prof.heightCm));
  const [age, setAge] = useState(String(ageNow(prof)));
  const [name, setName] = useState(prof.name ?? '');
  const [g, setG] = useState(String(data.settings.leanGoalKg));

  return (
    <ScrollView style={{ backgroundColor: t.bg }} contentContainerStyle={{ padding: 16, paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
      <Section title="Treino" style={{ marginTop: 0 }}>
        <Card>
          <T sub size={13} style={{ marginBottom: 8 }}>
            Descanso por defeito (exercícios novos)
          </T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {[60, 90, 120, 180].map((s) => (
              <Chip key={s} label={`${s}s`} active={data.settings.defaultRest === s} onPress={() => setSettings({ defaultRest: s })} />
            ))}
          </View>
        </Card>
      </Section>

      <Section title="Perfil">
        <Card>
          <View style={st.row}>
            <T style={{ flex: 1 }}>Nome</T>
            <TextInput value={name} onChangeText={setName} onEndEditing={() => setProfile({ ...prof, name: name.trim() || undefined })} style={[st.in, { color: t.text, width: 140 }]} />
          </View>
          <View style={[st.row, st.sep, { borderColor: t.border }]}>
            <T style={{ flex: 1 }}>Idade</T>
            <TextInput value={age} onChangeText={setAge} onEndEditing={() => setProfile({ ...prof, age: Number(age) || prof.age, setAt: Date.now() })} keyboardType="number-pad" style={[st.in, { color: t.text }]} />
          </View>
          <View style={[st.row, st.sep, { borderColor: t.border }]}>
            <T style={{ flex: 1 }}>Sexo</T>
            <Chip label="Homem" active={prof.sex === 'm'} onPress={() => setProfile({ ...prof, sex: 'm' })} />
            <Chip label="Mulher" active={prof.sex === 'f'} onPress={() => setProfile({ ...prof, sex: 'f' })} />
          </View>
          <View style={[st.row, st.sep, { borderColor: t.border }]}>
            <T style={{ flex: 1 }}>Altura (cm)</T>
            <TextInput value={h} onChangeText={setH} onEndEditing={() => setProfile({ ...prof, heightCm: Number(h.replace(',', '.')) || prof.heightCm })} keyboardType="decimal-pad" style={[st.in, { color: t.text }]} />
          </View>
          <View style={[st.sep, { borderColor: t.border, paddingTop: 10 }]}>
            <T style={{ marginBottom: 8 }}>Nível de atividade</T>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
              {ACTIVITY.map((a) => (
                <Chip key={a.k} label={`${a.label} · ${a.hint}`} active={prof.activity === a.k} onPress={() => setProfile({ ...prof, activity: a.k })} />
              ))}
            </View>
          </View>
          <View style={[st.row, st.sep, { borderColor: t.border, marginTop: 10 }]}>
            <T style={{ flex: 1 }}>Meta de massa magra (+kg)</T>
            <TextInput value={g} onChangeText={setG} onEndEditing={() => setSettings({ leanGoalKg: Number(g.replace(',', '.')) || 10 })} keyboardType="decimal-pad" style={[st.in, { color: t.text }]} />
          </View>
        </Card>
      </Section>

      <Section title="Backup">
        <Card>
          <T sub size={13} style={{ lineHeight: 19 }}>
            Os dados ficam só neste telemóvel. Exporta de vez em quando (envia para ti por email ou guarda nas Notas) para não perderes nada se trocares de telemóvel.
          </T>
          <T size={13} style={{ marginTop: 8 }}>
            {data.workouts.length} treinos · {data.body.length} registos corporais · {data.routines.length} rotinas
          </T>
          <Btn
            title="Exportar dados"
            icon="share-outline"
            style={{ marginTop: 12 }}
            onPress={() => {
              const json = exportJSON();
              if (Platform.OS === 'web') {
                setExported(json);
                const nav: any = (globalThis as any).navigator;
                nav?.clipboard?.writeText?.(json).then(() => Alert.alert('Copiado', 'Cola o texto num email para ti ou nas Notas.')).catch(() => {});
              } else Share.share({ message: json, title: 'Forja backup' }).catch(() => {});
            }}
          />
          {exported ? (
            <TextInput value={exported} editable={false} selectTextOnFocus multiline style={{ color: t.sub, backgroundColor: t.card2, borderRadius: 10, padding: 10, marginTop: 8, maxHeight: 100, fontSize: 11 }} />
          ) : null}
          <TextInput
            value={paste}
            onChangeText={setPaste}
            placeholder="Cola aqui um backup para importar…"
            placeholderTextColor={t.faint}
            multiline
            style={{ color: t.text, backgroundColor: t.card2, borderRadius: 10, padding: 10, marginTop: 14, minHeight: 70, maxHeight: 140 }}
          />
          <Btn
            title="Importar backup"
            kind="secondary"
            style={{ marginTop: 8 }}
            disabled={!paste.trim()}
            onPress={() =>
              Alert.alert('Importar?', 'Substitui todos os dados atuais.', [
                { text: 'Cancelar', style: 'cancel' },
                {
                  text: 'Importar',
                  style: 'destructive',
                  onPress: () => {
                    try {
                      importJSON(paste.trim());
                      setPaste('');
                      Alert.alert('Feito', 'Dados importados.');
                    } catch {
                      Alert.alert('Erro', 'Este texto não é um backup válido.');
                    }
                  },
                },
              ])
            }
          />
        </Card>
      </Section>

      <Section title="Rotinas">
        <Btn
          title="Repor rotinas A/B e Casa originais"
          kind="secondary"
          onPress={() =>
            Alert.alert('Repor rotinas?', 'As 4 rotinas pré-definidas voltam ao original. As tuas rotinas criadas mantêm-se.', [
              { text: 'Cancelar', style: 'cancel' },
              { text: 'Repor', onPress: resetRoutines },
            ])
          }
        />
      </Section>

      <T size={12} faint style={{ marginTop: 28, textAlign: 'center', lineHeight: 18 }}>
        Forja · app pessoal de treino{'\n'}Imagens e instruções: free-exercise-db (domínio público)
      </T>
    </ScrollView>
  );
}

const st = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  in: { textAlign: 'right', fontSize: 16, fontWeight: '600', width: 80 },
  sep: { borderTopWidth: StyleSheet.hairlineWidth },
});
