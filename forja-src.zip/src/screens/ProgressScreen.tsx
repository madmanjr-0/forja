import { useNavigation } from '@react-navigation/native';
import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { BodyMap } from '../components/BodyMap';
import { BarChart, Radar } from '../components/Charts';
import { ExerciseDemo } from '../components/ExerciseDemo';
import { Card, Chip, Empty, Ionicons, Section, T } from '../components/ui';
import type { Nav } from '../nav';
import { bestsOf, isWorking, useStore, workoutVolume } from '../store';
import { MUSCLE_LABEL, RADAR_AXES, useTheme } from '../theme';
import { DAY, fmtKg, weekStart } from '../util';

const BODY_ORDER = ['peito', 'costas', 'ombros', 'biceps', 'triceps', 'abdominais', 'quadriceps', 'isquios', 'gluteos', 'gemeos', 'trapezio', 'lombar', 'antebracos'];

export default function ProgressScreen() {
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const { data, exById } = useStore();
  const [range, setRange] = useState<7 | 30>(7);
  const now = Date.now();

  const sets = useMemo(() => {
    // Séries por músculo em janelas: [0, d) e [d, 2d)
    const calc = (from: number, to: number) => {
      const m: Record<string, number> = {};
      for (const w of data.workouts) {
        if (w.start < from || w.start >= to) continue;
        for (const e of w.exercises) {
          const ex = exById(e.exerciseId);
          const n = e.sets.filter(isWorking).length;
          ex?.p.forEach((x) => (m[x] = (m[x] ?? 0) + n));
          ex?.s.forEach((x) => (m[x] = (m[x] ?? 0) + n * 0.5));
        }
      }
      return m;
    };
    return {
      week: calc(now - 7 * DAY, now + 1),
      cur: calc(now - range * DAY, now + 1),
      prev: calc(now - 2 * range * DAY, now - range * DAY),
    };
  }, [data.workouts, exById, range, now]);

  // Scouter de força: e1RM atual (últimos 30 dias) vs. primeiro registo de cada exercício.
  const strength = useMemo(() => {
    const byEx = new Map<string, { first: number; firstTs: number; cur: number }>();
    const sorted = [...data.workouts].sort((a, b) => a.start - b.start);
    for (const w of sorted)
      for (const e of w.exercises) {
        const b = bestsOf(e.sets).e1rm;
        if (!b) continue;
        const r = byEx.get(e.exerciseId);
        if (!r) byEx.set(e.exerciseId, { first: b, firstTs: w.start, cur: w.start >= now - 30 * DAY ? b : 0 });
        else if (w.start >= now - 30 * DAY) r.cur = Math.max(r.cur, b);
      }
    const axes = RADAR_AXES.map((ax) => {
      let ratios: number[] = [];
      let best = 0;
      for (const [id, r] of byEx) {
        const ex = exById(id);
        if (!ex || !ex.p.some((m) => ax.muscles.includes(m))) continue;
        const cur = r.cur || r.first;
        best = Math.max(best, cur);
        ratios.push(cur / r.first);
      }
      const avg = ratios.length ? ratios.reduce((a, b) => a + b, 0) / ratios.length : 0;
      return { label: ax.label, ratio: avg, best, has: ratios.length > 0 };
    });
    const power = Math.round(axes.reduce((a, x) => a + x.best, 0) * 10);
    return { axes, power };
  }, [data.workouts, exById, now]);

  const weekly = useMemo(() => {
    const bars: { label: string; value: number; n: number }[] = [];
    const ws = weekStart(now);
    for (let i = 7; i >= 0; i--) {
      const from = ws - i * 7 * DAY;
      const to = from + 7 * DAY;
      const list = data.workouts.filter((w) => w.start >= from && w.start < to);
      const d = new Date(from);
      bars.push({ label: `${d.getDate()}/${d.getMonth() + 1}`, value: list.reduce((a, w) => a + workoutVolume(w), 0), n: list.length });
    }
    return bars;
  }, [data.workouts, now]);

  const exList = useMemo(() => {
    const m = new Map<string, { last: number; count: number }>();
    for (const w of data.workouts)
      for (const e of w.exercises) {
        const r = m.get(e.exerciseId) ?? { last: 0, count: 0 };
        m.set(e.exerciseId, { last: Math.max(r.last, w.start), count: r.count + 1 });
      }
    return [...m.entries()].sort((a, b) => b[1].last - a[1].last);
  }, [data.workouts]);

  if (!data.workouts.length)
    return (
      <View style={{ flex: 1, backgroundColor: t.bg }}>
        <Empty icon="stats-chart-outline" title="Os gráficos aparecem aqui" text="Radar de força, distribuição muscular, mapa do corpo e evolução de cargas — tudo calculado a partir dos teus treinos." />
      </View>
    );

  const axisVal = (m: Record<string, number>) => RADAR_AXES.map((ax) => ax.muscles.reduce((a, k) => a + (m[k] ?? 0), 0));
  const cur = axisVal(sets.cur);
  const prev = axisVal(sets.prev);
  const maxSets = Math.max(1, ...cur, ...prev);

  // ratio 1.0 (ponto de partida) = metade do raio; +50% = raio total
  const sVals = strength.axes.map((a) => (a.has ? Math.min(1, Math.max(0.08, 0.5 + (a.ratio - 1))) : 0.04));

  return (
    <ScrollView style={{ backgroundColor: t.bg }} contentContainerStyle={{ padding: 16, paddingBottom: 60 }}>
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <View>
            <T size={16} weight="800">
              Scouter de força
            </T>
            <T size={12} sub>
              1RM estimado atual vs. o teu ponto de partida
            </T>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <T size={11} sub weight="700">
              POWER LEVEL
            </T>
            <T size={22} weight="900" color={strength.power > 9000 ? t.gold : t.accent}>
              {strength.power.toLocaleString('pt-PT')}
            </T>
          </View>
        </View>
        <Radar
          axes={strength.axes.map((a) => a.label)}
          valueLabels={strength.axes.map((a) => (a.has ? `${a.ratio >= 1 ? '+' : ''}${Math.round((a.ratio - 1) * 100)}%` : '—'))}
          series={[
            { label: 'Início', values: strength.axes.map((a) => (a.has ? 0.5 : 0)), color: t.faint, fill: false },
            { label: 'Agora', values: sVals, color: t.accent },
          ]}
        />
      </Card>

      <Section
        title="Distribuição muscular"
        right={
          <View style={{ flexDirection: 'row' }}>
            <Chip label="7 dias" active={range === 7} onPress={() => setRange(7)} />
            <Chip label="30 dias" active={range === 30} onPress={() => setRange(30)} />
          </View>
        }
      >
        <Card>
          <Radar
            axes={RADAR_AXES.map((a) => a.label)}
            valueLabels={cur.map((v) => `${Math.round(v)} séries`)}
            series={[
              { label: `${range} dias anteriores`, values: prev.map((v) => v / maxSets), color: t.warn, fill: false },
              { label: `Últimos ${range} dias`, values: cur.map((v) => v / maxSets), color: t.accent },
            ]}
          />
        </Card>
      </Section>

      <Section title="Mapa muscular · últimos 7 dias">
        <Card>
          <BodyMap intensity={Object.fromEntries(Object.entries(sets.week).map(([k, v]) => [k, v / 10]))} height={240} />
          <T size={12} sub style={{ textAlign: 'center', marginTop: 8 }}>
            Cor cheia = 10+ séries/semana (zona de hipertrofia: 10–20)
          </T>
          <View style={{ marginTop: 12 }}>
            {BODY_ORDER.map((m) => {
              const v = sets.week[m] ?? 0;
              const color = v >= 10 ? t.good : v >= 6 ? t.accent : v > 0 ? t.warn : t.faint;
              return (
                <View key={m} style={{ flexDirection: 'row', alignItems: 'center', marginTop: 6 }}>
                  <T size={13} style={{ width: 96 }}>
                    {MUSCLE_LABEL[m]}
                  </T>
                  <View style={{ flex: 1, height: 8, backgroundColor: t.card2, borderRadius: 4, overflow: 'hidden' }}>
                    <View style={{ width: `${Math.min(100, (v / 20) * 100)}%`, height: 8, backgroundColor: color, borderRadius: 4 }} />
                  </View>
                  <T size={12} sub style={{ width: 36, textAlign: 'right' }}>
                    {Math.round(v * 10) / 10}
                  </T>
                </View>
              );
            })}
          </View>
        </Card>
      </Section>

      <Section title="Volume semanal">
        <Card>
          <BarChart bars={weekly} format={(v) => fmtKg(v)} />
          <T size={12} sub style={{ marginTop: 6 }}>
            Treinos por semana: {weekly.map((w) => w.n).join(' · ')}
          </T>
        </Card>
      </Section>

      <Section title="Exercícios">
        {exList.map(([id, info]) => {
          const ex = exById(id);
          return (
            <Pressable key={id} onPress={() => nav.navigate('ExerciseDetail', { id })} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 8 }}>
              <ExerciseDemo id={id} size={44} animate={false} radius={22} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <T weight="600" numberOfLines={1}>
                  {ex?.name ?? id}
                </T>
                <T size={12} sub>
                  {info.count} sessões
                </T>
              </View>
              <Ionicons name="chevron-forward" size={18} color={t.faint} />
            </Pressable>
          );
        })}
      </Section>
    </ScrollView>
  );
}
