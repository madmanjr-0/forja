import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import { useKeepAwake } from 'expo-keep-awake';
import React, { memo, useEffect, useMemo, useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, TextInput, Vibration, View } from 'react-native';
import { Alert } from '../components/dialog';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { ActionMenu, MenuItem } from '../components/ActionMenu';
import { ExerciseDemo } from '../components/ExerciseDemo';
import { ExerciseInfoSheet } from '../components/ExerciseInfoSheet';
import { ExercisePicker } from '../components/ExercisePicker';
import { Btn, Ionicons, T } from '../components/ui';
import type { Exercise } from '../data/exercises';
import { isWorking, newSet, SetKind, SetPart, setLabel, SSInfo, supersets, useStore, WExercise, Workout, WSet, workoutSets, workoutVolume } from '../store';
import { useTheme } from '../theme';
import { fmtDuration, fmtKg, fmtNum, fmtSecs, parseNum, uid } from '../util';
import type { Nav, RootStack } from '../nav';

const KIND_LABEL: Record<SetKind, string> = { normal: '', warmup: 'A', failure: 'F', drop: 'D' };
const REST_OPTIONS = [0, 45, 60, 90, 120, 150, 180, 240];

type Rest = { endAt: number; total: number } | null;

export default function WorkoutScreen() {
  useKeepAwake();
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const insets = useSafeAreaInsets();
  const { params } = useRoute<RouteProp<RootStack, 'Workout'>>();
  const editId = params?.editId;
  const { data, updateActive: updateLive, finishWorkout, discardWorkout, exById, lastSets, updateWorkout } = useStore();
  // Modo edição: trabalha numa cópia do treino do histórico; só grava ao carregar em "Guardar".
  const [draft, setDraft] = useState<Workout | null>(() => {
    const src = editId ? data.workouts.find((x) => x.id === editId) : null;
    return src ? (JSON.parse(JSON.stringify(src)) as Workout) : null;
  });
  const editing = !!editId;
  const w = editing ? draft : data.active;
  const updateActive = (fn: (w: Workout) => Workout) => (editing ? setDraft((d) => (d ? fn(d) : d)) : updateLive(fn));
  const [now, setNow] = useState(Date.now());
  const [rest, setRest] = useState<Rest>(null);
  const [picker, setPicker] = useState<{ replace?: string; ss?: boolean } | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const restDone = useRef(false);
  const finishing = useRef(false);
  const [menu, setMenu] = useState<number | null>(null);

  useEffect(() => {
    const i = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(i);
  }, []);

  useEffect(() => {
    if (!rest) return;
    if (now >= rest.endAt && !restDone.current) {
      restDone.current = true;
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      Vibration.vibrate([0, 300, 150, 300]);
      setTimeout(() => setRest(null), 1200);
    }
  }, [now, rest]);

  // Saiu do treino (terminado/descartado) → fecha o ecrã
  useEffect(() => {
    if (!w && !finishing.current && nav.canGoBack()) nav.goBack();
  }, [w, nav]);
  const original = useRef(editing ? JSON.stringify(draft) : '');
  const dirty = editing && JSON.stringify(draft) !== original.current;
  const dirtyRef = useRef(dirty);
  dirtyRef.current = dirty;
  useEffect(() => {
    if (!editing) return;
    return nav.addListener('beforeRemove', (e) => {
      if (!dirtyRef.current || finishing.current) return;
      e.preventDefault();
      Alert.alert('Sair sem guardar?', 'As alterações a este treino perdem-se.', [
        { text: 'Continuar a editar', style: 'cancel' },
        { text: 'Sair', style: 'destructive', onPress: () => nav.dispatch(e.data.action) },
      ]);
    });
  }, [editing, nav]);

  if (!w) return <View style={{ flex: 1, backgroundColor: t.bg }} />;

  const vol = workoutVolume(w);
  const sets = workoutSets(w);

  const startRest = (secs: number) => {
    if (!secs || editing) return;
    restDone.current = false;
    setRest({ endAt: Date.now() + secs * 1000, total: secs });
  };

  const patchEx = (exId: string, fn: (e: WExercise) => WExercise) =>
    updateActive((a) => ({ ...a, exercises: a.exercises.map((e) => (e.id === exId ? fn(e) : e)) }));

  const menuItems = (we: WExercise, idx: number): MenuItem[] => [
    { label: 'Ver demonstração', icon: 'play-circle-outline', onPress: () => setInfo(we.exerciseId) },
    { label: 'Mover para cima', icon: 'arrow-up', onPress: () => move(idx, -1) },
    { label: 'Mover para baixo', icon: 'arrow-down', onPress: () => move(idx, 1) },
    { label: 'Substituir exercício', icon: 'swap-horizontal', onPress: () => setPicker({ replace: we.id }) },
    ...(idx < (w?.exercises.length ?? 0) - 1 && !(ssList[idx] && ssList[idx]!.group === w!.exercises[idx + 1].group)
      ? [{ label: 'Juntar ao seguinte em super série', icon: 'flash-outline' as const, onPress: () => joinNext(idx) }]
      : []),
    ...(ssList[idx] ? [{ label: 'Tirar da super série', icon: 'remove-circle-outline' as const, onPress: () => leaveGroup(idx) }] : []),
    { label: 'Remover exercício', icon: 'trash-outline', danger: true, onPress: () => updateActive((a) => ({ ...a, exercises: a.exercises.filter((e) => e.id !== we.id) })) },
  ];

  const ssList = supersets(w.exercises);
  const joinNext = (idx: number) =>
    updateActive((a) => {
      const arr = [...a.exercises];
      const g = arr[idx].group || arr[idx + 1].group || 'ss_' + uid();
      const old = [arr[idx].group, arr[idx + 1].group].filter(Boolean);
      return { ...a, exercises: arr.map((e, i) => (i === idx || i === idx + 1 || (e.group && old.includes(e.group)) ? { ...e, group: g } : e)) };
    });
  const leaveGroup = (idx: number) =>
    updateActive((a) => {
      const g = a.exercises[idx].group;
      let arr = a.exercises.map((e, i) => (i === idx ? { ...e, group: undefined } : e));
      // se o grupo ficar só com um exercício, deixa de ser super série
      if (g && arr.filter((e) => e.group === g).length < 2) arr = arr.map((e) => (e.group === g ? { ...e, group: undefined } : e));
      // tirar do meio de uma super série: põe-no a seguir ao bloco
      const ex = arr[idx];
      const rest = arr.filter((_, i) => i !== idx);
      let end = idx;
      while (g && end < rest.length && rest[end].group === g) end++;
      rest.splice(end, 0, ex);
      return { ...a, exercises: rest };
    });

  const move = (idx: number, d: number) =>
    updateActive((a) => {
      const arr = [...a.exercises];
      const j = idx + d;
      if (j < 0 || j >= arr.length) return a;
      [arr[idx], arr[j]] = [arr[j], arr[idx]];
      return { ...a, exercises: arr };
    });

  const finish = () => {
    const pending = w.exercises.reduce((a, e) => a + e.sets.filter((s) => !s.done).length, 0);
    const doIt = () => {
      finishing.current = true;
      const done = finishWorkout();
      if (done) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
        nav.replace('WorkoutDetail', { id: done.id, fresh: true });
      }
    };
    if (sets === 0) {
      Alert.alert('Treino vazio', 'Ainda não marcaste nenhuma série como feita.', [
        { text: 'Continuar', style: 'cancel' },
        { text: 'Descartar treino', style: 'destructive', onPress: discardWorkout },
      ]);
      return;
    }
    Alert.alert('Terminar treino?', pending ? `Há ${pending} série(s) por marcar — serão ignoradas.` : 'Bom trabalho! 💪', [
      { text: 'Continuar a treinar', style: 'cancel' },
      { text: 'Terminar', onPress: doIt },
    ]);
  };

  const body = () =>
    w.exercises.map((we, idx) => {
            const ex = exById(we.exerciseId);
            if (!ex) return null;
            const ss = ssList[idx];
            const block = (
              <ExerciseBlock
                key={we.id}
                we={we}
                ex={ex}
                ss={ss}
                prev={lastSets(we.exerciseId, w.start, ss ? 'ss' : 'solo')}
                onMenu={() => setMenu(idx)}
                onInfo={() => setInfo(we.exerciseId)}
                onPatch={(fn) => patchEx(we.id, fn)}
                onSetDone={(done) => {
                  if (done) {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
                    // super série: só descansa no fim da volta (depois do último exercício do bloco)
                    if (!ss || ss.last) startRest(we.restSec);
                  }
                }}
              />
            );
            if (!ss) return block;
            return (
              <View
                key={we.id}
                style={{
                  marginHorizontal: 8,
                  marginTop: ss.first ? 14 : 0,
                  paddingBottom: ss.last ? 12 : 0,
                  backgroundColor: SS_BG(t.dark),
                  borderColor: SS_BORDER,
                  borderLeftWidth: 1.5,
                  borderRightWidth: 1.5,
                  borderTopWidth: ss.first ? 1.5 : 0,
                  borderBottomWidth: ss.last ? 1.5 : 0,
                  borderTopLeftRadius: ss.first ? 16 : 0,
                  borderTopRightRadius: ss.first ? 16 : 0,
                  borderBottomLeftRadius: ss.last ? 16 : 0,
                  borderBottomRightRadius: ss.last ? 16 : 0,
                }}
              >
                {ss.first && (
                  <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 8, paddingTop: 10 }}>
                    <View style={[st.ssTag, { backgroundColor: SS_COLOR }]}>
                      <Ionicons name="flash" size={11} color="#1A0B00" />
                      <T size={11} weight="900" color="#1A0B00" style={{ letterSpacing: 0.5 }}>
                        SUPER SÉRIE {ss.letter}
                      </T>
                    </View>
                    <T size={12} sub style={{ marginLeft: 8, flex: 1 }} numberOfLines={1}>
                      Descanso só no fim de cada volta
                    </T>
                  </View>
                )}
                <View style={{ marginHorizontal: -8 }}>{block}</View>
                {!ss.last && (
                  <T size={12} weight="700" color={SS_COLOR} style={{ textAlign: 'center', marginTop: 10 }}>
                    ↓ sem descanso ↓
                  </T>
                )}
              </View>
            );
          });

  const sheets = () => (
    <>
      <ExercisePicker
        visible={!!picker}
        multi={!picker?.replace}
        onClose={() => setPicker(null)}
        onPick={(ids) => {
          if (picker?.replace) {
            const target = picker.replace;
            patchEx(target, (e) => ({ ...e, exerciseId: ids[0], sets: e.sets.map((s) => ({ ...s, done: false, kg: null, reps: null, secs: null })) }));
          } else {
            if (picker?.ss && ids.length < 2) {
              Alert.alert('Super série', 'Escolhe pelo menos 2 exercícios para fazer seguidos.');
              return;
            }
            const g = picker?.ss ? 'ss_' + uid() : undefined;
            updateActive((a) => ({
              ...a,
              exercises: [
                ...a.exercises,
                ...ids.map((id) => ({ id: uid(), exerciseId: id, restSec: data.settings.defaultRest, group: g, sets: [newSet(), newSet(), newSet()] })),
              ],
            }));
          }
        }}
      />
      <ExerciseInfoSheet id={info} onClose={() => setInfo(null)} />
      <ActionMenu
        visible={menu != null && !!w.exercises[menu]}
        title={menu != null && w.exercises[menu] ? exById(w.exercises[menu].exerciseId)?.name : undefined}
        items={menu != null && w.exercises[menu] ? menuItems(w.exercises[menu], menu) : []}
        onClose={() => setMenu(null)}
      />
    </>
  );

  const saveEdit = () => {
    if (!w) return;
    const clean: Workout = {
      ...w,
      exercises: w.exercises.map((e) => ({ ...e, sets: e.sets.filter((s) => s.done) })).filter((e) => e.sets.length > 0),
    };
    if (!clean.exercises.length) {
      Alert.alert('Treino sem séries', 'Marca pelo menos uma série como feita (✓). Se quiseres apagar o treino, usa "Apagar treino" no resumo.');
      return;
    }
    const pending = w.exercises.reduce((a, e) => a + e.sets.filter((s) => !s.done).length, 0);
    const doIt = () => {
      finishing.current = true;
      updateWorkout(clean);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      nav.goBack();
    };
    if (pending) Alert.alert('Guardar alterações?', `Há ${pending} série(s) sem ✓ — não ficam guardadas.`, [{ text: 'Voltar', style: 'cancel' }, { text: 'Guardar', onPress: doIt }]);
    else doIt();
  };
  const cancelEdit = () => nav.goBack();

  if (editing)
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }} edges={['top']}>
        <View style={[st.header, { borderColor: t.border }]}>
          <Pressable onPress={cancelEdit} hitSlop={12}>
            <T size={16} color={t.sub}>
              Cancelar
            </T>
          </Pressable>
          <View style={{ flex: 1, marginHorizontal: 12, alignItems: 'center' }}>
            <T size={16} weight="700">
              Editar treino
            </T>
            <T size={12} sub>
              {fmtKg(vol)} · {sets} séries
            </T>
          </View>
          <Btn title="Guardar" kind="good" small onPress={saveEdit} />
        </View>
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={8}>
          <ScrollView contentContainerStyle={{ paddingBottom: 120 + insets.bottom }} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
            <EditMeta w={w} onChange={(p) => updateActive((a) => ({ ...a, ...p }))} />
            {body()}
            <View style={{ padding: 16, gap: 10 }}>
              <Btn title="Adicionar exercício" icon="add" onPress={() => setPicker({})} />
              <Btn title="Nova super série" icon="flash-outline" kind="secondary" onPress={() => setPicker({ ss: true })} />
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
        {sheets()}
      </SafeAreaView>
    );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }} edges={['top']}>
      <View style={[st.header, { borderColor: t.border }]}>
        <Pressable onPress={() => nav.goBack()} hitSlop={12}>
          <Ionicons name="chevron-down" size={26} color={t.text} />
        </Pressable>
        <View style={{ flex: 1, marginHorizontal: 12 }}>
          <T size={16} weight="700" numberOfLines={1}>
            {w.name}
          </T>
          <T size={13} sub>
            {fmtDuration(now - w.start)} · {fmtKg(vol)} · {sets} séries
          </T>
        </View>
        <Btn title="Terminar" kind="good" small onPress={finish} />
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={8}>
        <ScrollView contentContainerStyle={{ paddingBottom: 160 + insets.bottom }} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
          {body()}

          <View style={{ padding: 16, gap: 10 }}>
            <Btn title="Adicionar exercício" icon="add" onPress={() => setPicker({})} />
            <Btn title="Nova super série" icon="flash-outline" kind="secondary" onPress={() => setPicker({ ss: true })} />
            <Btn
              title="Descartar treino"
              kind="danger"
              onPress={() =>
                Alert.alert('Descartar treino?', 'Perdes tudo o que registaste neste treino.', [
                  { text: 'Cancelar', style: 'cancel' },
                  { text: 'Descartar', style: 'destructive', onPress: discardWorkout },
                ])
              }
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      {rest && <RestBar rest={rest} now={now} onAdjust={(d) => setRest((r) => (r ? { endAt: Math.max(Date.now(), r.endAt + d * 1000), total: Math.max(5, r.total + d) } : r))} onSkip={() => setRest(null)} bottom={insets.bottom} />}

      {sheets()}
    </SafeAreaView>
  );
}

function RestBar({ rest, now, onAdjust, onSkip, bottom }: { rest: NonNullable<Rest>; now: number; onAdjust: (d: number) => void; onSkip: () => void; bottom: number }) {
  const t = useTheme();
  const left = Math.max(0, Math.ceil((rest.endAt - now) / 1000));
  const frac = Math.min(1, Math.max(0, 1 - left / rest.total));
  const done = left === 0;
  return (
    <View style={[st.restBar, { backgroundColor: t.card, borderColor: t.border, paddingBottom: 12 + bottom }]}>
      <View style={{ height: 4, backgroundColor: t.card2, borderRadius: 2, overflow: 'hidden', marginBottom: 10 }}>
        <View style={{ height: 4, width: `${frac * 100}%`, backgroundColor: done ? t.good : t.accent }} />
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Btn title="-15" kind="secondary" small onPress={() => onAdjust(-15)} />
        <View style={{ flex: 1, alignItems: 'center' }}>
          <T size={12} sub>
            {done ? 'Bora para a próxima!' : 'Descanso'}
          </T>
          <T size={26} weight="800" color={done ? t.good : t.text} style={{ fontVariant: ['tabular-nums'] }}>
            {fmtSecs(left)}
          </T>
        </View>
        <Btn title="+15" kind="secondary" small onPress={() => onAdjust(15)} />
        <Btn title="Saltar" kind="ghost" small onPress={onSkip} style={{ marginLeft: 4 }} />
      </View>
    </View>
  );
}

const SS_COLOR = '#FF7A1A';
const SS_BORDER = 'rgba(255,122,26,0.45)';
const SS_BG = (dark: boolean) => (dark ? '#1A140F' : '#FFF4EB');

const ExerciseBlock = memo(function ExerciseBlock({
  we,
  ex,
  ss,
  prev,
  onMenu,
  onInfo,
  onPatch,
  onSetDone,
}: {
  we: WExercise;
  ex: Exercise;
  ss?: SSInfo | null;
  prev: WSet[] | null;
  onMenu: () => void;
  onInfo: () => void;
  onPatch: (fn: (e: WExercise) => WExercise) => void;
  onSetDone: (done: boolean) => void;
}) {
  const t = useTheme();
  const [showNote, setShowNote] = useState(!!we.note);

  // Progressão dupla: se da última vez todas as séries chegaram ao topo da gama → sobe carga.
  const hint = useMemo(() => {
    if (!prev || !we.repMax || ex.type !== 'weight') return null;
    const work = prev.filter(isWorking);
    if (!work.length) return null;
    const top = work.every((s) => (s.reps ?? 0) >= (we.repMax ?? 99));
    const maxKg = Math.max(...work.map((s) => s.kg ?? 0));
    if (top) return { up: true, text: `Chegaste às ${we.repMax} reps em todas as séries — sobe ~${maxKg >= 40 ? '2,5–5' : '1–2,5'} kg` };
    return { up: false, text: `Mantém ${fmtNum(maxKg)} kg e tenta +1 rep por série` };
  }, [prev, we.repMax, ex.type]);

  const cycleRest = () => {
    const i = REST_OPTIONS.indexOf(we.restSec);
    onPatch((e) => ({ ...e, restSec: REST_OPTIONS[(i + 1) % REST_OPTIONS.length] }));
  };

  let normalIdx = 0;
  const workCols = ex.type === 'time' ? ['SEG'] : ex.type === 'reps' ? ['+KG', 'REPS'] : ['KG', 'REPS'];

  return (
    <View style={{ paddingTop: 16, paddingHorizontal: 16 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Pressable onPress={onInfo}>
          <ExerciseDemo id={ex.id} size={46} animate={false} radius={23} />
          <View style={[st.playBadge, { backgroundColor: t.accent }]}>
            <Ionicons name="play" size={9} color="#fff" />
          </View>
        </Pressable>
        <Pressable onPress={onInfo} style={{ flex: 1, marginLeft: 12 }}>
          <T size={16} weight="700" color={t.accent} numberOfLines={2}>
            {ss ? (
              <T size={14} weight="900" color={SS_COLOR}>
                {`${ss.letter}${ss.idx}  `}
              </T>
            ) : null}
            {ex.name}
          </T>
          {we.repMin ? (
            <T size={12} sub>
              Alvo {we.repMin}–{we.repMax} {ex.type === 'time' ? 's' : 'reps'}
            </T>
          ) : null}
        </Pressable>
        <Pressable onPress={() => setShowNote((v) => !v)} hitSlop={8} style={{ padding: 6 }}>
          <Ionicons name="create-outline" size={20} color={t.sub} />
        </Pressable>
        <Pressable onPress={onMenu} hitSlop={8} style={{ padding: 6 }}>
          <Ionicons name="ellipsis-horizontal" size={22} color={t.sub} />
        </Pressable>
      </View>

      {showNote && (
        <TextInput
          value={we.note ?? ''}
          onChangeText={(v) => onPatch((e) => ({ ...e, note: v }))}
          placeholder="Nota (ex.: banco no 3, cotovelo ok)"
          placeholderTextColor={t.faint}
          style={{ color: t.text, marginTop: 8, fontSize: 14, paddingVertical: 4 }}
          multiline
        />
      )}

      {hint && (
        <View style={[st.hint, { backgroundColor: hint.up ? t.goodSoft : t.card2 }]}>
          <Ionicons name={hint.up ? 'trending-up' : 'repeat'} size={14} color={hint.up ? t.good : t.sub} />
          <T size={12} color={hint.up ? t.good : t.sub} style={{ marginLeft: 6, flex: 1 }}>
            {hint.text}
          </T>
        </View>
      )}

      {ss && !ss.last ? (
        <T size={12} sub style={{ marginTop: 8 }}>
          {prev ? 'Anterior = última vez em super série' : 'Primeira vez em super série'}
        </T>
      ) : (
        <Pressable onPress={cycleRest} style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8 }}>
          <Ionicons name="timer-outline" size={15} color={t.accent} />
          <T size={13} color={t.accent} style={{ marginLeft: 4 }}>
            {ss ? 'Descanso no fim da volta' : 'Descanso'}: {we.restSec ? fmtSecs(we.restSec) : 'desligado'}
          </T>
        </Pressable>
      )}

      <View style={[st.row, { marginTop: 6 }]}>
        <T size={11} weight="700" faint style={st.cSet}>
          SÉRIE
        </T>
        <T size={11} weight="700" faint style={st.cPrev}>
          ANTERIOR
        </T>
        {workCols.map((c) => (
          <T key={c} size={11} weight="700" faint style={st.cIn}>
            {c}
          </T>
        ))}
        <View style={st.cChk}>
          <Ionicons name="checkmark" size={14} color={t.faint} />
        </View>
      </View>

      {we.sets.map((s, i) => {
        if (s.kind !== 'warmup') normalIdx++;
        return (
          <SetRow
            key={s.id}
            set={s}
            label={s.kind === 'normal' || s.kind === 'drop' ? String(normalIdx) : KIND_LABEL[s.kind]}
            prev={prev?.[i] ?? null}
            type={ex.type}
            onKind={(k) => onPatch((e) => ({ ...e, sets: e.sets.map((x) => (x.id === s.id ? { ...x, kind: k } : x)) }))}
            onChange={(p) => onPatch((e) => ({ ...e, sets: e.sets.map((x) => (x.id === s.id ? { ...x, ...p } : x)) }))}
            onDelete={() => onPatch((e) => ({ ...e, sets: e.sets.filter((x) => x.id !== s.id) }))}
            onDone={onSetDone}
          />
        );
      })}

      <Btn
        title="Adicionar série"
        icon="add"
        kind="secondary"
        small
        style={{ marginTop: 6 }}
        onPress={() =>
          onPatch((e) => {
            const last = e.sets[e.sets.length - 1];
            return {
              ...e,
              sets: [
                ...e.sets,
                newSet(last ? { kg: last.kg, reps: last.reps, secs: last.secs, kind: last.kind === 'warmup' ? 'normal' : last.kind, parts: last.parts?.map((p) => ({ ...p })) } : {}),
              ],
            };
          })
        }
      />
    </View>
  );
});

function prevLabel(p: WSet | null, type: Exercise['type']): string {
  if (!p) return '—';
  if (type === 'time') return p.secs ? `${p.secs} s` : '—';
  return setLabel(p, type);
}

const SetRow = memo(function SetRow({
  set,
  label,
  prev,
  type,
  onKind,
  onChange,
  onDelete,
  onDone,
}: {
  set: WSet;
  label: string;
  prev: WSet | null;
  type: Exercise['type'];
  onKind: (k: SetKind) => void;
  onChange: (p: Partial<WSet>) => void;
  onDelete: () => void;
  onDone: (done: boolean) => void;
}) {
  const t = useTheme();
  const [kg, setKg] = useState(set.kg != null ? fmtNum(set.kg, 2) : '');
  const [reps, setReps] = useState(set.reps != null ? String(set.reps) : '');
  const [secs, setSecs] = useState(set.secs != null ? String(set.secs) : '');
  const [menu, setMenu] = useState(false);
  const parts = set.parts ?? [];

  const kindColor = { normal: t.text, warmup: t.warn, failure: t.bad, drop: t.text }[set.kind];
  const bg = set.done ? t.goodSoft : 'transparent';

  const toggleDone = () => {
    if (set.done) {
      onChange({ done: false });
      onDone(false);
      return;
    }
    // Campos vazios herdam o valor da última vez (como no Hevy)
    let k = parseNum(kg), r = parseNum(reps), sc = parseNum(secs);
    if (k == null && prev?.kg != null && type !== 'time') {
      k = prev.kg;
      setKg(fmtNum(k, 2));
    }
    if (r == null && prev?.reps != null && type !== 'time') {
      r = prev.reps;
      setReps(String(r));
    }
    if (sc == null && prev?.secs != null && type === 'time') {
      sc = prev.secs;
      setSecs(String(sc));
    }
    if (type === 'weight' && (r == null || r === 0)) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(() => {});
      return;
    }
    if (type === 'reps' && (r == null || r === 0)) return;
    if (type === 'time' && (sc == null || sc === 0)) return;
    // Cargas extra: herdam da última vez quando vazias; sem reps são descartadas
    const fixedParts = parts
      .map((p, i) => ({ kg: p.kg ?? prev?.parts?.[i]?.kg ?? null, reps: p.reps ?? prev?.parts?.[i]?.reps ?? null }))
      .filter((p) => p.reps);
    onChange({ kg: k, reps: r != null ? Math.round(r) : null, secs: sc, done: true, parts: fixedParts.length ? fixedParts : undefined });
    onDone(true);
  };

  const input = (value: string, set_: (v: string) => void, commit: (n: number | null) => void, placeholder: string, decimal: boolean) => (
    <TextInput
      value={value}
      onChangeText={(v) => {
        set_(v);
        commit(parseNum(v));
      }}
      placeholder={placeholder}
      placeholderTextColor={t.faint}
      keyboardType={decimal ? 'decimal-pad' : 'number-pad'}
      selectTextOnFocus
      returnKeyType="done"
      style={[st.input, { color: t.text, backgroundColor: set.done ? 'transparent' : t.card2 }]}
    />
  );

  const addPart = () => {
    const base = parts[parts.length - 1] ?? { kg: set.kg, reps: null };
    // Sugestão: drop de ~20% da carga anterior
    const suggestion = base.kg ? Math.round(base.kg * 0.8 * 2) / 2 : null;
    onChange({ parts: [...parts, { kg: suggestion, reps: null }], done: false });
  };
  const patchPart = (i: number, p: Partial<SetPart>) => onChange({ parts: parts.map((x, j) => (j === i ? { ...x, ...p } : x)) });
  const removePart = (i: number) => onChange({ parts: parts.filter((_, j) => j !== i) });

  return (
    <View style={{ backgroundColor: bg, borderRadius: 8, marginTop: 4 }}>
      <Pressable onLongPress={() => setMenu(true)} style={[st.row, { marginTop: 0, paddingVertical: 5 }]}>
        <Pressable onPress={() => setMenu(true)} style={st.cSet} hitSlop={6} accessibilityLabel="Opções da série">
          <View style={[st.setBadge, { backgroundColor: set.done ? 'transparent' : t.card2 }]}>
            <T weight="800" size={14} color={kindColor}>
              {label}
            </T>
            {parts.length ? <View style={[st.partDot, { backgroundColor: t.accent }]} /> : null}
          </View>
        </Pressable>
        <T size={13} sub style={st.cPrev} numberOfLines={2}>
          {prevLabel(prev, type)}
        </T>
        {type === 'time' ? (
          <View style={st.cIn}>{input(secs, setSecs, (n) => onChange({ secs: n }), prev?.secs ? String(prev.secs) : '0', false)}</View>
        ) : (
          <>
            <View style={st.cIn}>{input(kg, setKg, (n) => onChange({ kg: n }), prev?.kg != null ? fmtNum(prev.kg, 2) : '0', true)}</View>
            <View style={st.cIn}>{input(reps, setReps, (n) => onChange({ reps: n != null ? Math.round(n) : null }), prev?.reps != null ? String(prev.reps) : '0', false)}</View>
          </>
        )}
        <Pressable onPress={toggleDone} style={st.cChk} hitSlop={6}>
          <View style={[st.check, { backgroundColor: set.done ? t.good : t.card2 }]}>
            <Ionicons name="checkmark" size={18} color={set.done ? '#fff' : t.faint} />
          </View>
        </Pressable>
      </Pressable>

      {type !== 'time' &&
        parts.map((p, i) => (
          <PartRow
            key={i}
            part={p}
            done={set.done}
            prev={prev?.parts?.[i] ?? null}
            onChange={(x) => patchPart(i, x)}
            onRemove={() => removePart(i)}
          />
        ))}

      <ActionMenu
        visible={menu}
        title={`Série ${label}`}
        onClose={() => setMenu(false)}
        items={[
          ...(type !== 'time'
            ? [{ label: 'Adicionar carga na mesma série', icon: 'git-branch-outline' as const, onPress: addPart }]
            : []),
          { label: 'Série normal', icon: 'ellipse-outline' as const, onPress: () => onKind('normal') },
          { label: 'Aquecimento (não conta)', icon: 'flame-outline' as const, onPress: () => onKind('warmup') },
          { label: 'Até à falha', icon: 'flash-outline' as const, onPress: () => onKind('failure') },
          { label: 'Apagar série', icon: 'trash-outline' as const, danger: true, onPress: onDelete },
        ]}
      />
    </View>
  );
});

/** Carga extra dentro da mesma série (sem descanso): drop set, aquecimento seguido, etc. */
function PartRow({ part, prev, done, onChange, onRemove }: { part: SetPart; prev: SetPart | null; done: boolean; onChange: (p: Partial<SetPart>) => void; onRemove: () => void }) {
  const t = useTheme();
  const [kg, setKg] = useState(part.kg != null ? fmtNum(part.kg, 2) : '');
  const [reps, setReps] = useState(part.reps != null ? String(part.reps) : '');
  const inp = (v: string, set_: (s: string) => void, commit: (n: number | null) => void, ph: string, dec: boolean) => (
    <TextInput
      value={v}
      onChangeText={(x) => {
        set_(x);
        commit(parseNum(x));
      }}
      placeholder={ph}
      placeholderTextColor={t.faint}
      keyboardType={dec ? 'decimal-pad' : 'number-pad'}
      selectTextOnFocus
      style={[st.input, { color: t.text, backgroundColor: done ? 'transparent' : t.card2, paddingVertical: 5, fontSize: 15 }]}
    />
  );
  return (
    <View style={[st.row, { marginTop: 0, paddingBottom: 5 }]}>
      <View style={st.cSet}>
        <Ionicons name="return-down-forward" size={16} color={t.accent} />
      </View>
      <T size={11} color={t.accent} style={st.cPrev}>
        sem descanso
      </T>
      <View style={st.cIn}>{inp(kg, setKg, (n) => onChange({ kg: n }), prev?.kg != null ? fmtNum(prev.kg, 2) : 'kg', true)}</View>
      <View style={st.cIn}>{inp(reps, setReps, (n) => onChange({ reps: n != null ? Math.round(n) : null }), prev?.reps != null ? String(prev.reps) : 'reps', false)}</View>
      <Pressable onPress={onRemove} style={st.cChk} hitSlop={6} accessibilityLabel="Remover carga">
        <Ionicons name="close-circle-outline" size={20} color={t.faint} />
      </Pressable>
    </View>
  );
}

const pad2 = (n: number) => String(n).padStart(2, '0');

/** Nome, data, hora e duração de um treino do histórico. */
function EditMeta({ w, onChange }: { w: Workout; onChange: (p: Partial<Workout>) => void }) {
  const t = useTheme();
  const d0 = new Date(w.start);
  const [name, setName] = useState(w.name);
  const [date, setDate] = useState(`${pad2(d0.getDate())}/${pad2(d0.getMonth() + 1)}/${d0.getFullYear()}`);
  const [time, setTime] = useState(`${pad2(d0.getHours())}:${pad2(d0.getMinutes())}`);
  const [dur, setDur] = useState(String(Math.max(1, Math.round(((w.end ?? w.start) - w.start) / 60000))));
  const [bad, setBad] = useState<string | null>(null);

  const commit = (nd = date, nt = time, nm = dur) => {
    const dm = nd.trim().match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})$/);
    const tm = nt.trim().match(/^(\d{1,2})[:h.](\d{2})$/);
    const mins = parseNum(nm);
    if (!dm) return setBad('Data no formato DD/MM/AAAA');
    if (!tm) return setBad('Hora no formato HH:MM');
    if (mins == null || mins <= 0 || mins > 600) return setBad('Duração em minutos (1–600)');
    let y = +dm[3];
    if (y < 100) y += 2000;
    const start = new Date(y, +dm[2] - 1, +dm[1], +tm[1], +tm[2]).getTime();
    if (isNaN(start) || +dm[2] > 12 || +dm[1] > 31 || +tm[1] > 23 || +tm[2] > 59) return setBad('Data ou hora inválida');
    if (start > Date.now()) return setBad('A data não pode ser no futuro');
    setBad(null);
    onChange({ start, end: start + Math.round(mins) * 60000 });
  };

  const field = (label: string, value: string, set: (v: string) => void, onEnd: (v: string) => void, kb: 'default' | 'number-pad' | 'numbers-and-punctuation', flex = 1) => (
    <View style={{ flex }}>
      <T size={11} weight="700" faint>
        {label}
      </T>
      <TextInput
        value={value}
        onChangeText={set}
        onEndEditing={(e) => onEnd(e.nativeEvent.text)}
        onBlur={() => onEnd(value)}
        keyboardType={kb}
        selectTextOnFocus
        placeholderTextColor={t.faint}
        style={[st.input, { color: t.text, backgroundColor: t.card2, marginTop: 4, textAlign: 'left', paddingHorizontal: 10 }]}
      />
    </View>
  );

  return (
    <View style={{ margin: 16, marginBottom: 0, padding: 14, borderRadius: 14, backgroundColor: t.card, gap: 12 }}>
      {field('NOME', name, setName, (v) => v.trim() && onChange({ name: v.trim() }), 'default')}
      <View style={{ flexDirection: 'row', gap: 10 }}>
        {field('DATA', date, setDate, (v) => commit(v, time, dur), 'numbers-and-punctuation', 1.4)}
        {field('INÍCIO', time, setTime, (v) => commit(date, v, dur), 'numbers-and-punctuation')}
        {field('DURAÇÃO (MIN)', dur, setDur, (v) => commit(date, time, v), 'number-pad')}
      </View>
      {bad ? (
        <T size={12} color={t.bad}>
          {bad}
        </T>
      ) : (
        <T size={12} faint>
          Séries com ✓ ficam guardadas. Tira o ✓ ou apaga a série para a remover.
        </T>
      )}
    </View>
  );
}

const st = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth },
  row: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  cSet: { width: 44, alignItems: 'center', textAlign: 'center' },
  cPrev: { flex: 1.3, textAlign: 'center' },
  cIn: { flex: 1, alignItems: 'center', textAlign: 'center', paddingHorizontal: 4 },
  cChk: { width: 46, alignItems: 'center' },
  input: { width: '100%', textAlign: 'center', fontSize: 16, fontWeight: '600', borderRadius: 8, paddingVertical: 7 },
  setBadge: { width: 30, height: 30, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  check: { width: 34, height: 30, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  ssTag: { flexDirection: 'row', alignItems: 'center', gap: 4, borderRadius: 999, paddingHorizontal: 9, paddingVertical: 3 },
  partDot: { position: 'absolute', right: -2, top: -2, width: 8, height: 8, borderRadius: 4 },
  hint: { flexDirection: 'row', alignItems: 'center', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 7, marginTop: 10 },
  restBar: { position: 'absolute', left: 0, right: 0, bottom: 0, paddingHorizontal: 16, paddingTop: 12, borderTopWidth: StyleSheet.hairlineWidth, shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 12, elevation: 12 },
  playBadge: { position: 'absolute', right: -2, bottom: -2, width: 18, height: 18, borderRadius: 9, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
});
