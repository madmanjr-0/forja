import { useNavigation } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import { useKeepAwake } from 'expo-keep-awake';
import React, { memo, useEffect, useMemo, useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, TextInput, Vibration, View } from 'react-native';
import { Alert } from '../components/dialog';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { ActionMenu, MenuItem } from '../components/ActionMenu';
import { ExerciseDemo } from '../components/ExerciseDemo';
import { ExerciseInfoSheet } from '../components/ExerciseInfoSheet';
import { ExercisePicker } from '../components/ExercisePicker';
import { Btn, Ionicons, T } from '../components/ui';
import type { Exercise } from '../data/exercises';
import { isWorking, newSet, SetKind, useStore, WExercise, WSet, workoutSets, workoutVolume } from '../store';
import { useTheme } from '../theme';
import { fmtDuration, fmtKg, fmtNum, fmtSecs, parseNum, uid } from '../util';
import type { Nav } from '../nav';

const KIND_NEXT: Record<SetKind, SetKind> = { normal: 'warmup', warmup: 'failure', failure: 'drop', drop: 'normal' };
const KIND_LABEL: Record<SetKind, string> = { normal: '', warmup: 'A', failure: 'F', drop: 'D' };
const REST_OPTIONS = [0, 45, 60, 90, 120, 150, 180, 240];

type Rest = { endAt: number; total: number } | null;

export default function WorkoutScreen() {
  useKeepAwake();
  const t = useTheme();
  const nav = useNavigation<Nav>();
  const insets = useSafeAreaInsets();
  const { data, updateActive, finishWorkout, discardWorkout, exById, lastSets } = useStore();
  const w = data.active;
  const [now, setNow] = useState(Date.now());
  const [rest, setRest] = useState<Rest>(null);
  const [picker, setPicker] = useState<{ replace?: string } | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const restDone = useRef(false);
  const finishing = useRef(false);
  const [menu, setMenu] = useState<number | null>(null);

  useEffect(() => {
    const i = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(i);
  }, []);

  useEffect(() => {
    if (!rest) return;
    if (now >= rest.endAt && !restDone.current) {
      restDone.current = true;
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
      Vibration.vibrate([0, 300, 150, 300]);
      setTimeout(() => setRest(null), 1200);
    }
  }, [now, rest]);

  // Saiu do treino (terminado/descartado) → fecha o ecrã
  useEffect(() => {
    if (!w && !finishing.current && nav.canGoBack()) nav.goBack();
  }, [w, nav]);

  if (!w) return <View style={{ flex: 1, backgroundColor: t.bg }} />;

  const vol = workoutVolume(w);
  const sets = workoutSets(w);

  const startRest = (secs: number) => {
    if (!secs) return;
    restDone.current = false;
    setRest({ endAt: Date.now() + secs * 1000, total: secs });
  };

  const patchEx = (exId: string, fn: (e: WExercise) => WExercise) =>
    updateActive((a) => ({ ...a, exercises: a.exercises.map((e) => (e.id === exId ? fn(e) : e)) }));

  const menuItems = (we: WExercise, idx: number): MenuItem[] => [
    { label: 'Ver demonstração', icon: 'play-circle-outline', onPress: () => setInfo(we.exerciseId) },
    { label: 'Mover para cima', icon: 'arrow-up', onPress: () => move(idx, -1) },
    { label: 'Mover para baixo', icon: 'arrow-down', onPress: () => move(idx, 1) },
    { label: 'Substituir exercício', icon: 'swap-horizontal', onPress: () => setPicker({ replace: we.id }) },
    { label: 'Remover exercício', icon: 'trash-outline', danger: true, onPress: () => updateActive((a) => ({ ...a, exercises: a.exercises.filter((e) => e.id !== we.id) })) },
  ];

  const move = (idx: number, d: number) =>
    updateActive((a) => {
      const arr = [...a.exercises];
      const j = idx + d;
      if (j < 0 || j >= arr.length) return a;
      [arr[idx], arr[j]] = [arr[j], arr[idx]];
      return { ...a, exercises: arr };
    });

  const finish = () => {
    const pending = w.exercises.reduce((a, e) => a + e.sets.filter((s) => !s.done).length, 0);
    const doIt = () => {
      finishing.current = true;
      const done = finishWorkout();
      if (done) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
        nav.replace('WorkoutDetail', { id: done.id, fresh: true });
      }
    };
    if (sets === 0) {
      Alert.alert('Treino vazio', 'Ainda não marcaste nenhuma série como feita.', [
        { text: 'Continuar', style: 'cancel' },
        { text: 'Descartar treino', style: 'destructive', onPress: discardWorkout },
      ]);
      return;
    }
    Alert.alert('Terminar treino?', pending ? `Há ${pending} série(s) por marcar — serão ignoradas.` : 'Bom trabalho! 💪', [
      { text: 'Continuar a treinar', style: 'cancel' },
      { text: 'Terminar', onPress: doIt },
    ]);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }} edges={['top']}>
      <View style={[st.header, { borderColor: t.border }]}>
        <Pressable onPress={() => nav.goBack()} hitSlop={12}>
          <Ionicons name="chevron-down" size={26} color={t.text} />
        </Pressable>
        <View style={{ flex: 1, marginHorizontal: 12 }}>
          <T size={16} weight="700" numberOfLines={1}>
            {w.name}
          </T>
          <T size={13} sub>
            {fmtDuration(now - w.start)} · {fmtKg(vol)} · {sets} séries
          </T>
        </View>
        <Btn title="Terminar" kind="good" small onPress={finish} />
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined} keyboardVerticalOffset={8}>
        <ScrollView contentContainerStyle={{ paddingBottom: 160 + insets.bottom }} keyboardShouldPersistTaps="handled" keyboardDismissMode="on-drag">
          {w.exercises.map((we, idx) => {
            const ex = exById(we.exerciseId);
            if (!ex) return null;
            return (
              <ExerciseBlock
                key={we.id}
                we={we}
                ex={ex}
                prev={lastSets(we.exerciseId, w.start)}
                onMenu={() => setMenu(idx)}
                onInfo={() => setInfo(we.exerciseId)}
                onPatch={(fn) => patchEx(we.id, fn)}
                onSetDone={(done) => {
                  if (done) {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium).catch(() => {});
                    startRest(we.restSec);
                  }
                }}
              />
            );
          })}

          <View style={{ padding: 16, gap: 10 }}>
            <Btn title="Adicionar exercício" icon="add" onPress={() => setPicker({})} />
            <Btn
              title="Descartar treino"
              kind="danger"
              onPress={() =>
                Alert.alert('Descartar treino?', 'Perdes tudo o que registaste neste treino.', [
                  { text: 'Cancelar', style: 'cancel' },
                  { text: 'Descartar', style: 'destructive', onPress: discardWorkout },
                ])
              }
            />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      {rest && <RestBar rest={rest} now={now} onAdjust={(d) => setRest((r) => (r ? { endAt: Math.max(Date.now(), r.endAt + d * 1000), total: Math.max(5, r.total + d) } : r))} onSkip={() => setRest(null)} bottom={insets.bottom} />}

      <ExercisePicker
        visible={!!picker}
        multi={!picker?.replace}
        onClose={() => setPicker(null)}
        onPick={(ids) => {
          if (picker?.replace) {
            const target = picker.replace;
            patchEx(target, (e) => ({ ...e, exerciseId: ids[0], sets: e.sets.map((s) => ({ ...s, done: false, kg: null, reps: null, secs: null })) }));
          } else
            updateActive((a) => ({
              ...a,
              exercises: [
                ...a.exercises,
                ...ids.map((id) => ({ id: uid(), exerciseId: id, restSec: data.settings.defaultRest, sets: [newSet(), newSet(), newSet()] })),
              ],
            }));
        }}
      />
      <ExerciseInfoSheet id={info} onClose={() => setInfo(null)} />
      <ActionMenu
        visible={menu != null && !!w.exercises[menu]}
        title={menu != null && w.exercises[menu] ? exById(w.exercises[menu].exerciseId)?.name : undefined}
        items={menu != null && w.exercises[menu] ? menuItems(w.exercises[menu], menu) : []}
        onClose={() => setMenu(null)}
      />
    </SafeAreaView>
  );
}

function RestBar({ rest, now, onAdjust, onSkip, bottom }: { rest: NonNullable<Rest>; now: number; onAdjust: (d: number) => void; onSkip: () => void; bottom: number }) {
  const t = useTheme();
  const left = Math.max(0, Math.ceil((rest.endAt - now) / 1000));
  const frac = Math.min(1, Math.max(0, 1 - left / rest.total));
  const done = left === 0;
  return (
    <View style={[st.restBar, { backgroundColor: t.card, borderColor: t.border, paddingBottom: 12 + bottom }]}>
      <View style={{ height: 4, backgroundColor: t.card2, borderRadius: 2, overflow: 'hidden', marginBottom: 10 }}>
        <View style={{ height: 4, width: `${frac * 100}%`, backgroundColor: done ? t.good : t.accent }} />
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Btn title="-15" kind="secondary" small onPress={() => onAdjust(-15)} />
        <View style={{ flex: 1, alignItems: 'center' }}>
          <T size={12} sub>
            {done ? 'Bora para a próxima!' : 'Descanso'}
          </T>
          <T size={26} weight="800" color={done ? t.good : t.text} style={{ fontVariant: ['tabular-nums'] }}>
            {fmtSecs(left)}
          </T>
        </View>
        <Btn title="+15" kind="secondary" small onPress={() => onAdjust(15)} />
        <Btn title="Saltar" kind="ghost" small onPress={onSkip} style={{ marginLeft: 4 }} />
      </View>
    </View>
  );
}

const ExerciseBlock = memo(function ExerciseBlock({
  we,
  ex,
  prev,
  onMenu,
  onInfo,
  onPatch,
  onSetDone,
}: {
  we: WExercise;
  ex: Exercise;
  prev: WSet[] | null;
  onMenu: () => void;
  onInfo: () => void;
  onPatch: (fn: (e: WExercise) => WExercise) => void;
  onSetDone: (done: boolean) => void;
}) {
  const t = useTheme();
  const [showNote, setShowNote] = useState(!!we.note);

  // Progressão dupla: se da última vez todas as séries chegaram ao topo da gama → sobe carga.
  const hint = useMemo(() => {
    if (!prev || !we.repMax || ex.type !== 'weight') return null;
    const work = prev.filter(isWorking);
    if (!work.length) return null;
    const top = work.every((s) => (s.reps ?? 0) >= (we.repMax ?? 99));
    const maxKg = Math.max(...work.map((s) => s.kg ?? 0));
    if (top) return { up: true, text: `Chegaste às ${we.repMax} reps em todas as séries — sobe ~${maxKg >= 40 ? '2,5–5' : '1–2,5'} kg` };
    return { up: false, text: `Mantém ${fmtNum(maxKg)} kg e tenta +1 rep por série` };
  }, [prev, we.repMax, ex.type]);

  const cycleRest = () => {
    const i = REST_OPTIONS.indexOf(we.restSec);
    onPatch((e) => ({ ...e, restSec: REST_OPTIONS[(i + 1) % REST_OPTIONS.length] }));
  };

  let normalIdx = 0;
  const workCols = ex.type === 'time' ? ['SEG'] : ex.type === 'reps' ? ['+KG', 'REPS'] : ['KG', 'REPS'];

  return (
    <View style={{ paddingTop: 16, paddingHorizontal: 16 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
        <Pressable onPress={onInfo}>
          <ExerciseDemo id={ex.id} size={46} animate={false} radius={23} />
          <View style={[st.playBadge, { backgroundColor: t.accent }]}>
            <Ionicons name="play" size={9} color="#fff" />
          </View>
        </Pressable>
        <Pressable onPress={onInfo} style={{ flex: 1, marginLeft: 12 }}>
          <T size={16} weight="700" color={t.accent} numberOfLines={2}>
            {ex.name}
          </T>
          {we.repMin ? (
            <T size={12} sub>
              Alvo {we.repMin}–{we.repMax} {ex.type === 'time' ? 's' : 'reps'}
            </T>
          ) : null}
        </Pressable>
        <Pressable onPress={() => setShowNote((v) => !v)} hitSlop={8} style={{ padding: 6 }}>
          <Ionicons name="create-outline" size={20} color={t.sub} />
        </Pressable>
        <Pressable onPress={onMenu} hitSlop={8} style={{ padding: 6 }}>
          <Ionicons name="ellipsis-horizontal" size={22} color={t.sub} />
        </Pressable>
      </View>

      {showNote && (
        <TextInput
          value={we.note ?? ''}
          onChangeText={(v) => onPatch((e) => ({ ...e, note: v }))}
          placeholder="Nota (ex.: banco no 3, cotovelo ok)"
          placeholderTextColor={t.faint}
          style={{ color: t.text, marginTop: 8, fontSize: 14, paddingVertical: 4 }}
          multiline
        />
      )}

      {hint && (
        <View style={[st.hint, { backgroundColor: hint.up ? t.goodSoft : t.card2 }]}>
          <Ionicons name={hint.up ? 'trending-up' : 'repeat'} size={14} color={hint.up ? t.good : t.sub} />
          <T size={12} color={hint.up ? t.good : t.sub} style={{ marginLeft: 6, flex: 1 }}>
            {hint.text}
          </T>
        </View>
      )}

      <Pressable onPress={cycleRest} style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8 }}>
        <Ionicons name="timer-outline" size={15} color={t.accent} />
        <T size={13} color={t.accent} style={{ marginLeft: 4 }}>
          Descanso: {we.restSec ? fmtSecs(we.restSec) : 'desligado'}
        </T>
      </Pressable>

      <View style={[st.row, { marginTop: 6 }]}>
        <T size={11} weight="700" faint style={st.cSet}>
          SÉRIE
        </T>
        <T size={11} weight="700" faint style={st.cPrev}>
          ANTERIOR
        </T>
        {workCols.map((c) => (
          <T key={c} size={11} weight="700" faint style={st.cIn}>
            {c}
          </T>
        ))}
        <View style={st.cChk}>
          <Ionicons name="checkmark" size={14} color={t.faint} />
        </View>
      </View>

      {we.sets.map((s, i) => {
        if (s.kind !== 'warmup') normalIdx++;
        return (
          <SetRow
            key={s.id}
            set={s}
            label={s.kind === 'normal' ? String(normalIdx) : KIND_LABEL[s.kind]}
            prev={prev?.[i] ?? null}
            type={ex.type}
            onKind={() => onPatch((e) => ({ ...e, sets: e.sets.map((x) => (x.id === s.id ? { ...x, kind: KIND_NEXT[x.kind] } : x)) }))}
            onChange={(p) => onPatch((e) => ({ ...e, sets: e.sets.map((x) => (x.id === s.id ? { ...x, ...p } : x)) }))}
            onDelete={() => onPatch((e) => ({ ...e, sets: e.sets.filter((x) => x.id !== s.id) }))}
            onDone={onSetDone}
          />
        );
      })}

      <Btn
        title="Adicionar série"
        icon="add"
        kind="secondary"
        small
        style={{ marginTop: 6 }}
        onPress={() =>
          onPatch((e) => {
            const last = e.sets[e.sets.length - 1];
            return { ...e, sets: [...e.sets, newSet(last ? { kg: last.kg, reps: last.reps, secs: last.secs, kind: last.kind === 'warmup' ? 'normal' : last.kind } : {})] };
          })
        }
      />
    </View>
  );
});

function prevLabel(p: WSet | null, type: Exercise['type']): string {
  if (!p) return '—';
  if (type === 'time') return p.secs ? `${p.secs} s` : '—';
  if (type === 'reps') return `${p.kg ? `+${fmtNum(p.kg)} × ` : ''}${p.reps ?? 0}`;
  return `${fmtNum(p.kg ?? 0)} × ${p.reps ?? 0}`;
}

const SetRow = memo(function SetRow({
  set,
  label,
  prev,
  type,
  onKind,
  onChange,
  onDelete,
  onDone,
}: {
  set: WSet;
  label: string;
  prev: WSet | null;
  type: Exercise['type'];
  onKind: () => void;
  onChange: (p: Partial<WSet>) => void;
  onDelete: () => void;
  onDone: (done: boolean) => void;
}) {
  const t = useTheme();
  const [kg, setKg] = useState(set.kg != null ? fmtNum(set.kg, 2) : '');
  const [reps, setReps] = useState(set.reps != null ? String(set.reps) : '');
  const [secs, setSecs] = useState(set.secs != null ? String(set.secs) : '');

  const kindColor = { normal: t.text, warmup: t.warn, failure: t.bad, drop: t.accent }[set.kind];
  const bg = set.done ? t.goodSoft : 'transparent';

  const toggleDone = () => {
    if (set.done) {
      onChange({ done: false });
      onDone(false);
      return;
    }
    // Campos vazios herdam o valor da última vez (como no Hevy)
    let k = parseNum(kg), r = parseNum(reps), sc = parseNum(secs);
    if (k == null && prev?.kg != null && type !== 'time') {
      k = prev.kg;
      setKg(fmtNum(k, 2));
    }
    if (r == null && prev?.reps != null && type !== 'time') {
      r = prev.reps;
      setReps(String(r));
    }
    if (sc == null && prev?.secs != null && type === 'time') {
      sc = prev.secs;
      setSecs(String(sc));
    }
    if (type === 'weight' && (r == null || r === 0)) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning).catch(() => {});
      return;
    }
    if (type === 'reps' && (r == null || r === 0)) return;
    if (type === 'time' && (sc == null || sc === 0)) return;
    onChange({ kg: k, reps: r != null ? Math.round(r) : null, secs: sc, done: true });
    onDone(true);
  };

  const input = (value: string, set_: (v: string) => void, commit: (n: number | null) => void, placeholder: string, decimal: boolean) => (
    <TextInput
      value={value}
      onChangeText={(v) => {
        set_(v);
        commit(parseNum(v));
      }}
      placeholder={placeholder}
      placeholderTextColor={t.faint}
      keyboardType={decimal ? 'decimal-pad' : 'number-pad'}
      selectTextOnFocus
      returnKeyType="done"
      style={[st.input, { color: t.text, backgroundColor: set.done ? 'transparent' : t.card2 }]}
    />
  );

  return (
    <Pressable
      onLongPress={() =>
        Alert.alert('Apagar série?', undefined, [
          { text: 'Cancelar', style: 'cancel' },
          { text: 'Apagar', style: 'destructive', onPress: onDelete },
        ])
      }
      style={[st.row, { backgroundColor: bg, borderRadius: 8, paddingVertical: 5 }]}
    >
      <Pressable onPress={onKind} style={st.cSet} hitSlop={6}>
        <View style={[st.setBadge, { backgroundColor: set.done ? 'transparent' : t.card2 }]}>
          <T weight="800" size={14} color={kindColor}>
            {label}
          </T>
        </View>
      </Pressable>
      <T size={13} sub style={st.cPrev} numberOfLines={1}>
        {prevLabel(prev, type)}
      </T>
      {type === 'time' ? (
        <View style={st.cIn}>{input(secs, setSecs, (n) => onChange({ secs: n }), prev?.secs ? String(prev.secs) : '0', false)}</View>
      ) : (
        <>
          <View style={st.cIn}>{input(kg, setKg, (n) => onChange({ kg: n }), prev?.kg != null ? fmtNum(prev.kg, 2) : '0', true)}</View>
          <View style={st.cIn}>{input(reps, setReps, (n) => onChange({ reps: n != null ? Math.round(n) : null }), prev?.reps != null ? String(prev.reps) : '0', false)}</View>
        </>
      )}
      <Pressable onPress={toggleDone} style={st.cChk} hitSlop={6}>
        <View style={[st.check, { backgroundColor: set.done ? t.good : t.card2 }]}>
          <Ionicons name="checkmark" size={18} color={set.done ? '#fff' : t.faint} />
        </View>
      </Pressable>
    </Pressable>
  );
});

const st = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth },
  row: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  cSet: { width: 44, alignItems: 'center', textAlign: 'center' },
  cPrev: { flex: 1.3, textAlign: 'center' },
  cIn: { flex: 1, alignItems: 'center', textAlign: 'center', paddingHorizontal: 4 },
  cChk: { width: 46, alignItems: 'center' },
  input: { width: '100%', textAlign: 'center', fontSize: 16, fontWeight: '600', borderRadius: 8, paddingVertical: 7 },
  setBadge: { width: 30, height: 30, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  check: { width: 34, height: 30, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  hint: { flexDirection: 'row', alignItems: 'center', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 7, marginTop: 10 },
  restBar: { position: 'absolute', left: 0, right: 0, bottom: 0, paddingHorizontal: 16, paddingTop: 12, borderTopWidth: StyleSheet.hairlineWidth, shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 12, elevation: 12 },
  playBadge: { position: 'absolute', right: -2, bottom: -2, width: 18, height: 18, borderRadius: 9, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
});
