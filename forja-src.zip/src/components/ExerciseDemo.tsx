import React, { useEffect, useRef, useState } from 'react';
import { Animated, Image, LayoutChangeEvent, StyleProp, View, ViewStyle } from 'react-native';
import { GRID, POS, SHEETS } from '../data/sprites';
import { useTheme } from '../theme';
import { Ionicons } from './ui';

/** Demo animada do exercício: as frames vêm de sprite sheets guardadas na app (offline). */
export function ExerciseDemo({
  id,
  size,
  animate = true,
  style,
  radius = 10,
}: {
  id: string;
  size: number | 'full';
  animate?: boolean;
  style?: StyleProp<ViewStyle>;
  radius?: number;
}) {
  const t = useTheme();
  const pos = POS[id];
  const fade = useRef(new Animated.Value(0)).current;
  const [box, setBox] = useState<{ w: number; h: number }>(typeof size === 'number' ? { w: size, h: size } : { w: 0, h: 0 });

  useEffect(() => {
    if (!animate || !pos) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(700),
        Animated.timing(fade, { toValue: 1, duration: 450, useNativeDriver: false }),
        Animated.delay(900),
        Animated.timing(fade, { toValue: 0, duration: 450, useNativeDriver: false }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [animate, pos, fade]);

  const dims: ViewStyle = size === 'full' ? { width: '100%', aspectRatio: 1.5 } : { width: size, height: size };
  const onLayout = size === 'full' ? (e: LayoutChangeEvent) => setBox({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height }) : undefined;

  if (!pos)
    return (
      <View style={[dims, { borderRadius: radius, backgroundColor: t.card2, alignItems: 'center', justifyContent: 'center' }, style]}>
        <Ionicons name="barbell-outline" size={typeof size === 'number' ? size * 0.45 : 48} color={t.faint} />
      </View>
    );

  const frame = (idx: number, opacity?: Animated.Value | number) => {
    const sheet = Math.floor(idx / GRID.per);
    const k = idx % GRID.per;
    const s = Math.max(box.w / GRID.fw, box.h / GRID.fh);
    const fw = GRID.fw * s, fh = GRID.fh * s;
    const ox = (box.w - fw) / 2, oy = (box.h - fh) / 2;
    return (
      <Animated.View key={idx} style={{ position: 'absolute', left: 0, top: 0, width: box.w, height: box.h, overflow: 'hidden', opacity: opacity ?? 1 }}>
        <Image
          source={SHEETS[sheet]}
          style={{ position: 'absolute', width: fw * GRID.cols, height: fh * GRID.rows, left: ox - (k % GRID.cols) * fw, top: oy - Math.floor(k / GRID.cols) * fh }}
        />
      </Animated.View>
    );
  };

  return (
    <View onLayout={onLayout} style={[dims, { borderRadius: radius, overflow: 'hidden', backgroundColor: '#fff' }, style]}>
      {box.w > 0 && frame(pos[0])}
      {box.w > 0 && animate && frame(pos[1], fade)}
    </View>
  );
}
