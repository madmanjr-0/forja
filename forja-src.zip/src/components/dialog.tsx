import React, { useEffect, useState } from 'react';
import { Modal, Pressable, StyleSheet, View } from 'react-native';
import { useTheme } from '../theme';
import { T } from './ui';

export type DialogButton = { text: string; style?: 'default' | 'cancel' | 'destructive'; onPress?: () => void };
type Req = { title: string; message?: string; buttons: DialogButton[] };

let push: ((r: Req) => void) | null = null;
const queue: Req[] = [];

/** Substituto do Alert nativo que funciona igual em Android, iOS e browser. */
export const Alert = {
  alert(title: string, message?: string, buttons?: DialogButton[]) {
    const r = { title, message, buttons: buttons?.length ? buttons : [{ text: 'OK' }] };
    if (push) push(r);
    else queue.push(r);
  },
};

export function DialogHost() {
  const t = useTheme();
  const [cur, setCur] = useState<Req | null>(null);
  useEffect(() => {
    push = (r) => setCur(r);
    if (queue.length) setCur(queue.shift()!);
    return () => {
      push = null;
    };
  }, []);
  if (!cur) return null;
  const close = (b?: DialogButton) => {
    setCur(null);
    if (b?.onPress) setTimeout(b.onPress, 50);
  };
  const cancel = cur.buttons.find((b) => b.style === 'cancel');
  const many = cur.buttons.length > 2;
  return (
    <Modal visible transparent animationType="fade" onRequestClose={() => close(cancel)}>
      <Pressable style={st.backdrop} onPress={() => close(cancel)}>
        <Pressable style={[st.box, { backgroundColor: t.card }]}>
          <T size={17} weight="700" style={{ textAlign: 'center' }}>
            {cur.title}
          </T>
          {cur.message ? (
            <T sub style={{ textAlign: 'center', marginTop: 8, lineHeight: 20 }}>
              {cur.message}
            </T>
          ) : null}
          <View style={{ flexDirection: many ? 'column' : 'row', gap: 8, marginTop: 18 }}>
            {cur.buttons.map((b, i) => {
              const bg = b.style === 'destructive' ? t.bad : b.style === 'cancel' ? t.card2 : t.accent;
              const fg = b.style === 'cancel' ? t.text : '#fff';
              return (
                <Pressable key={i} onPress={() => close(b)} style={({ pressed }) => [st.btn, { backgroundColor: bg, opacity: pressed ? 0.8 : 1 }, !many && { flex: 1 }]}>
                  <T weight="700" color={fg}>
                    {b.text}
                  </T>
                </Pressable>
              );
            })}
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const st = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', padding: 28 },
  box: { borderRadius: 18, padding: 20, maxWidth: 420, width: '100%', alignSelf: 'center' },
  btn: { borderRadius: 10, paddingVertical: 12, alignItems: 'center', justifyContent: 'center' },
});
