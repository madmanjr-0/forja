import React from 'react';
import { Modal, Pressable, ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useStore } from '../store';
import { MUSCLE_LABEL, useTheme } from '../theme';
import { ExerciseDemo } from './ExerciseDemo';
import { Ionicons, T } from './ui';

/** Ficha do exercício: animação, músculos, dicas PT e instruções. */
export function ExerciseInfoSheet({ id, onClose }: { id: string | null; onClose: () => void }) {
  const t = useTheme();
  const { exById } = useStore();
  const ex = id ? exById(id) : undefined;
  return (
    <Modal visible={!!ex} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }} edges={['top', 'bottom']}>
        <View style={{ flexDirection: 'row', justifyContent: 'flex-end', padding: 12 }}>
          <Pressable onPress={onClose} hitSlop={12}>
            <Ionicons name="close-circle" size={30} color={t.faint} />
          </Pressable>
        </View>
        {ex ? <ExerciseAbout id={ex.id} /> : null}
      </SafeAreaView>
    </Modal>
  );
}

export function ExerciseAbout({ id, header }: { id: string; header?: React.ReactNode }) {
  const t = useTheme();
  const { exById } = useStore();
  const ex = exById(id);
  if (!ex) return null;
  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingTop: 0, paddingBottom: 40 }}>
      <ExerciseDemo id={ex.id} size="full" radius={16} />
      <T size={22} weight="800" style={{ marginTop: 16 }}>
        {ex.name}
      </T>
      {ex.en && ex.en !== ex.name ? (
        <T size={13} faint>
          {ex.en}
        </T>
      ) : null}
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 10 }}>
        <Tag label={ex.eq} />
        {ex.p.map((m) => (
          <Tag key={m} label={MUSCLE_LABEL[m]} strong />
        ))}
        {ex.s.map((m) => (
          <Tag key={m} label={MUSCLE_LABEL[m]} />
        ))}
      </View>
      {header}
      {ex.cues.length > 0 && (
        <View style={{ marginTop: 18, backgroundColor: t.accentSoft, borderRadius: 12, padding: 14 }}>
          <T weight="700" color={t.accent} style={{ marginBottom: 6 }}>
            Dicas de execução
          </T>
          {ex.cues.map((c, i) => (
            <T key={i} style={{ marginTop: 4, lineHeight: 21 }}>
              • {c}
            </T>
          ))}
        </View>
      )}
      {ex.ins.length > 0 && (
        <View style={{ marginTop: 18 }}>
          <T weight="700" style={{ marginBottom: 6 }}>
            Instruções {ex.pt && ex.cues.length ? '(EN)' : ''}
          </T>
          {ex.ins.map((c, i) => (
            <View key={i} style={{ flexDirection: 'row', marginTop: 8 }}>
              <T sub weight="700" style={{ width: 22 }}>
                {i + 1}.
              </T>
              <T sub style={{ flex: 1, lineHeight: 20 }}>
                {c}
              </T>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

function Tag({ label, strong }: { label: string; strong?: boolean }) {
  const t = useTheme();
  return (
    <View style={{ paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12, backgroundColor: strong ? t.accent : t.card2 }}>
      <T size={12} weight="600" color={strong ? t.onAccent : t.sub}>
        {label}
      </T>
    </View>
  );
}
