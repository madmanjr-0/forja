import React from 'react';
import { Modal, Pressable, ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { estimateDuration, totalSets } from '../plan';
import { Routine, useStore } from '../store';
import { MUSCLE_LABEL, useTheme } from '../theme';
import { ExerciseDemo } from './ExerciseDemo';
import { Ionicons, T } from './ui';

/** Pré-visualização em ecrã inteiro, só de leitura: toca em qualquer sítio para fechar. */
export function RoutinePreview({ routine, onClose }: { routine: Routine | null; onClose: () => void }) {
  const t = useTheme();
  const { exById, data } = useStore();
  if (!routine) return null;
  const est = estimateDuration(routine, data.workouts);
  return (
    <Modal visible animationType="fade" presentationStyle="fullScreen" onRequestClose={onClose}>
      <Pressable onPress={onClose} style={{ flex: 1, backgroundColor: t.bg }}>
        <SafeAreaView style={{ flex: 1 }} edges={['top', 'bottom']}>
          <View style={{ paddingHorizontal: 20, paddingTop: 12, paddingBottom: 14, borderBottomWidth: 0.5, borderColor: t.border }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <T size={12} weight="800" color={t.accent} style={{ letterSpacing: 0.6 }}>
                PRÉ-VISUALIZAÇÃO
              </T>
              <View style={{ width: 32, height: 32, borderRadius: 16, backgroundColor: t.card2, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name="close" size={18} color={t.sub} />
              </View>
            </View>
            <T size={25} weight="800" style={{ marginTop: 6 }}>
              {routine.name}
            </T>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
              <Box label="Exercícios" value={String(routine.exercises.length)} />
              <Box label="Séries" value={String(totalSets(routine))} />
              <Box label="Duração" value={`~${est.min} min`} />
            </View>
            <T size={12} faint style={{ marginTop: 8 }}>
              {est.fromHistory
                ? `Média dos teus últimos ${est.fromHistory} treinos desta rotina${est.lo !== est.hi ? ` (${est.lo}–${est.hi} min)` : ''}`
                : 'Estimativa pelas séries e descansos — afina-se com os teus treinos'}
            </T>
          </View>
          <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 20 }}>
            {routine.exercises.map((e, i) => {
              const ex = exById(e.exerciseId);
              return (
                <View key={e.exerciseId + i} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8, borderBottomWidth: 0.5, borderColor: t.border }}>
                  <ExerciseDemo id={e.exerciseId} size={64} radius={10} />
                  <View style={{ flex: 1 }}>
                    <T weight="700" numberOfLines={2}>
                      {ex?.name ?? e.exerciseId}
                    </T>
                    <T size={12} sub>
                      {ex?.p.map((m) => MUSCLE_LABEL[m]).join(', ')}
                    </T>
                  </View>
                  <View style={{ alignItems: 'flex-end' }}>
                    <T weight="800" size={16}>
                      {e.sets} ×
                    </T>
                    <T size={11} sub>
                      {e.repMin}–{e.repMax} {ex?.type === 'time' ? 's' : 'reps'}
                    </T>
                  </View>
                </View>
              );
            })}
          </ScrollView>
          <T size={12} faint style={{ textAlign: 'center', paddingVertical: 10 }}>
            Toca em qualquer sítio para fechar
          </T>
        </SafeAreaView>
      </Pressable>
    </Modal>
  );
}

function Box({ label, value }: { label: string; value: string }) {
  const t = useTheme();
  return (
    <View style={{ flex: 1, backgroundColor: t.card, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 12 }}>
      <T size={11} sub>
        {label}
      </T>
      <T size={18} weight="800">
        {value}
      </T>
    </View>
  );
}
