import React from 'react';
import { Modal, Pressable, ScrollView, useWindowDimensions, View } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { estimateDuration, totalSets } from '../plan';
import { Routine, useStore } from '../store';
import { useTheme } from '../theme';
import { ExerciseDemo } from './ExerciseDemo';
import { Ionicons, T } from './ui';

/**
 * Pré-visualização em ecrã inteiro, só de leitura.
 * Grelha de 2 colunas para caber o treino todo no ecrã; se a rotina for maior, faz scroll.
 * Um toque em qualquer sítio fecha.
 */
export function RoutinePreview({ routine, onClose }: { routine: Routine | null; onClose: () => void }) {
  const t = useTheme();
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const { exById, data } = useStore();
  if (!routine) return null;
  const est = estimateDuration(routine, data.workouts);
  const pad = 16, gap = 10;
  // Ajusta colunas e altura das imagens para o treino caber todo no ecrã
  const n = routine.exercises.length;
  const cols = n > 10 ? 3 : 2;
  const rows = Math.ceil(n / cols);
  const tileW = (Math.min(width, 520) - pad * 2 - gap * (cols - 1)) / cols;
  const avail = height - insets.top - insets.bottom - 178;
  const textH = 70;
  const imgH = Math.round(Math.max(44, Math.min(tileW * 0.6, avail / rows - gap - textH)));

  return (
    <Modal visible animationType="fade" presentationStyle="fullScreen" onRequestClose={onClose}>
      <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }} edges={['top', 'bottom']}>
        <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
          <Pressable onPress={onClose} style={{ flexGrow: 1, paddingHorizontal: pad, paddingTop: 10, paddingBottom: 16, width: '100%', maxWidth: 520, alignSelf: 'center' }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <T size={11} weight="800" color={t.accent} style={{ letterSpacing: 0.6 }}>
                  PRÉ-VISUALIZAÇÃO
                </T>
                <T size={22} weight="800" numberOfLines={1}>
                  {routine.name}
                </T>
              </View>
              <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: t.card2, alignItems: 'center', justifyContent: 'center' }}>
                <Ionicons name="close" size={18} color={t.sub} />
              </View>
            </View>

            <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
              <Chip icon="barbell-outline" text={`${routine.exercises.length} exercícios`} />
              <Chip icon="layers-outline" text={`${totalSets(routine)} séries`} />
              <Chip icon="time-outline" text={`~${est.min} min`} strong />
            </View>
            <T size={11} faint style={{ marginTop: 6 }}>
              {est.fromHistory
                ? `Duração: média dos últimos ${est.fromHistory} treinos${est.lo !== est.hi ? ` (${est.lo}–${est.hi} min)` : ''}`
                : 'Duração estimada pelas séries e descansos'}
            </T>

            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap, marginTop: 12 }}>
              {routine.exercises.map((e, i) => {
                const ex = exById(e.exerciseId);
                return (
                  <View key={e.exerciseId + i} style={{ width: tileW, backgroundColor: t.card, borderRadius: 14, overflow: 'hidden' }}>
                    <View>
                      <ExerciseDemo id={e.exerciseId} size={tileW} height={imgH} radius={0} />
                      <View style={{ position: 'absolute', top: 6, left: 6, backgroundColor: 'rgba(0,0,0,0.65)', borderRadius: 8, paddingHorizontal: 7, paddingVertical: 2 }}>
                        <T size={11} weight="800" color="#fff">
                          {i + 1}
                        </T>
                      </View>
                    </View>
                    <View style={{ padding: 8 }}>
                      <T size={cols === 3 ? 12 : 13} weight="700" numberOfLines={2} style={{ lineHeight: 16, minHeight: 32 }}>
                        {ex?.name ?? e.exerciseId}
                      </T>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginTop: 3 }}>
                        <T size={14} weight="800" color={t.accent}>
                          {e.sets} × {e.repMin}–{e.repMax}
                          <T size={11} sub>
                            {' '}
                            {ex?.type === 'time' ? 's' : 'reps'}
                          </T>
                        </T>
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>

            <T size={12} faint style={{ textAlign: 'center', marginTop: 10 }}>
              Toca em qualquer sítio para fechar
            </T>
          </Pressable>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
}

function Chip({ icon, text, strong }: { icon: React.ComponentProps<typeof Ionicons>['name']; text: string; strong?: boolean }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: strong ? t.accentSoft : t.card, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 6 }}>
      <Ionicons name={icon} size={14} color={strong ? t.accent : t.sub} />
      <T size={13} weight="700" color={strong ? t.accent : t.text}>
        {text}
      </T>
    </View>
  );
}
