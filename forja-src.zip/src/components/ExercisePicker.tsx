import React, { useMemo, useState } from 'react';
import { FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { EQUIPMENT, Exercise, ExType, searchExercises } from '../data/exercises';
import { useStore } from '../store';
import { MUSCLE_LABEL, useTheme } from '../theme';
import { ExerciseDemo } from './ExerciseDemo';
import { ExerciseInfoSheet } from './ExerciseInfoSheet';
import { Btn, Chip, Ionicons, T } from './ui';

const MUSCLES = ['peito', 'costas', 'ombros', 'biceps', 'triceps', 'abdominais', 'quadriceps', 'isquios', 'gluteos', 'gemeos', 'trapezio', 'lombar', 'antebracos', 'adutores'];

export function ExercisePicker({ visible, onClose, onPick, multi = true }: { visible: boolean; onClose: () => void; onPick: (ids: string[]) => void; multi?: boolean }) {
  const t = useTheme();
  const { exercises, data, addCustomExercise } = useStore();
  const [q, setQ] = useState('');
  const [muscle, setMuscle] = useState<string | null>(null);
  const [eq, setEq] = useState<string | null>(null);
  const [sel, setSel] = useState<string[]>([]);
  const [info, setInfo] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  // Exercícios já usados primeiro (recentes), depois os com nome PT.
  const used = useMemo(() => {
    const m = new Map<string, number>();
    for (const w of data.workouts) for (const e of w.exercises) m.set(e.exerciseId, Math.max(m.get(e.exerciseId) ?? 0, w.start));
    return m;
  }, [data.workouts]);

  const list = useMemo(() => {
    const r = searchExercises(exercises, q, muscle, eq);
    return [...r].sort((a, b) => (used.get(b.id) ?? 0) - (used.get(a.id) ?? 0));
  }, [exercises, q, muscle, eq, used]);

  const close = () => {
    setSel([]);
    setQ('');
    onClose();
  };

  const toggle = (id: string) => {
    if (!multi) {
      onPick([id]);
      close();
      return;
    }
    setSel((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={close}>
      <SafeAreaView style={{ flex: 1, backgroundColor: t.bg }} edges={['top', 'bottom']}>
        <View style={st.header}>
          <Pressable onPress={close} hitSlop={10}>
            <T color={t.accent} size={16}>
              Cancelar
            </T>
          </Pressable>
          <T size={17} weight="700">
            Adicionar exercício
          </T>
          <Pressable onPress={() => setCreating(true)} hitSlop={10}>
            <T color={t.accent} size={16}>
              Criar
            </T>
          </Pressable>
        </View>
        <View style={[st.search, { backgroundColor: t.card2 }]}>
          <Ionicons name="search" size={18} color={t.faint} />
          <TextInput
            value={q}
            onChangeText={setQ}
            placeholder="Procurar (PT ou EN)"
            placeholderTextColor={t.faint}
            style={{ flex: 1, color: t.text, fontSize: 16, paddingVertical: 9, marginLeft: 8 }}
            autoCorrect={false}
          />
          {q ? (
            <Pressable onPress={() => setQ('')}>
              <Ionicons name="close-circle" size={18} color={t.faint} />
            </Pressable>
          ) : null}
        </View>
        <View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 6 }}>
            <Chip label="Todos" active={!muscle} onPress={() => setMuscle(null)} />
            {MUSCLES.map((m) => (
              <Chip key={m} label={MUSCLE_LABEL[m]} active={muscle === m} onPress={() => setMuscle(muscle === m ? null : m)} />
            ))}
          </ScrollView>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 8 }}>
            {EQUIPMENT.map((e) => (
              <Chip key={e} label={e} active={eq === e} onPress={() => setEq(eq === e ? null : e)} />
            ))}
          </ScrollView>
        </View>
        <FlatList
          data={list}
          keyExtractor={(e) => e.id}
          initialNumToRender={14}
          windowSize={8}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ paddingBottom: 100 }}
          renderItem={({ item }) => {
            const on = sel.includes(item.id);
            return (
              <Pressable
                onPress={() => toggle(item.id)}
                style={[st.row, { borderColor: t.border, backgroundColor: on ? t.accentSoft : 'transparent' }]}
              >
                <View style={{ width: 4, alignSelf: 'stretch', backgroundColor: on ? t.accent : 'transparent', borderRadius: 2, marginRight: 8 }} />
                <ExerciseDemo id={item.id} size={52} animate={false} radius={26} />
                <View style={{ flex: 1, marginLeft: 12 }}>
                  <T weight="600" numberOfLines={1}>
                    {item.name}
                  </T>
                  <T size={13} sub numberOfLines={1}>
                    {item.p.map((m) => MUSCLE_LABEL[m]).join(', ')} · {item.eq}
                    {used.has(item.id) ? ' · recente' : ''}
                  </T>
                </View>
                <Pressable onPress={() => setInfo(item.id)} hitSlop={10} style={{ padding: 6 }}>
                  <Ionicons name="information-circle-outline" size={22} color={t.faint} />
                </Pressable>
              </Pressable>
            );
          }}
        />
        {multi && sel.length > 0 && (
          <View style={st.bottom}>
            <Btn
              title={`Adicionar ${sel.length} exercício${sel.length > 1 ? 's' : ''}`}
              onPress={() => {
                onPick(sel);
                close();
              }}
            />
          </View>
        )}
      </SafeAreaView>
      <ExerciseInfoSheet id={info} onClose={() => setInfo(null)} />
      <CreateExercise
        visible={creating}
        onClose={() => setCreating(false)}
        onCreate={(e) => {
          const ex = addCustomExercise(e);
          setCreating(false);
          toggle(ex.id);
        }}
      />
    </Modal>
  );
}

function CreateExercise({ visible, onClose, onCreate }: { visible: boolean; onClose: () => void; onCreate: (e: Omit<Exercise, 'id' | 'custom'>) => void }) {
  const t = useTheme();
  const [name, setName] = useState('');
  const [muscle, setMuscle] = useState('peito');
  const [eq, setEq] = useState('Halteres');
  const [type, setType] = useState<ExType>('weight');
  return (
    <Modal visible={visible} animationType="slide" presentationStyle="formSheet" onRequestClose={onClose}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1, backgroundColor: t.bg }}>
        <ScrollView contentContainerStyle={{ padding: 16 }}>
          <View style={[st.header, { paddingHorizontal: 0 }]}>
            <Pressable onPress={onClose}>
              <T color={t.accent}>Cancelar</T>
            </Pressable>
            <T size={17} weight="700">
              Novo exercício
            </T>
            <View style={{ width: 60 }} />
          </View>
          <T sub size={13} style={{ marginTop: 12 }}>
            Nome
          </T>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="Ex.: Remada máquina pega neutra"
            placeholderTextColor={t.faint}
            style={[st.input, { backgroundColor: t.card, color: t.text, borderColor: t.border }]}
          />
          <T sub size={13} style={{ marginTop: 16, marginBottom: 6 }}>
            Músculo principal
          </T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {MUSCLES.map((m) => (
              <Chip key={m} label={MUSCLE_LABEL[m]} active={muscle === m} onPress={() => setMuscle(m)} />
            ))}
          </View>
          <T sub size={13} style={{ marginTop: 16, marginBottom: 6 }}>
            Equipamento
          </T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
            {EQUIPMENT.map((e) => (
              <Chip key={e} label={e} active={eq === e} onPress={() => setEq(e)} />
            ))}
          </View>
          <T sub size={13} style={{ marginTop: 16, marginBottom: 6 }}>
            Tipo de registo
          </T>
          <View style={{ flexDirection: 'row', gap: 6 }}>
            <Chip label="Peso × reps" active={type === 'weight'} onPress={() => setType('weight')} />
            <Chip label="Só reps" active={type === 'reps'} onPress={() => setType('reps')} />
            <Chip label="Tempo" active={type === 'time'} onPress={() => setType('time')} />
          </View>
          <Btn
            title="Guardar exercício"
            style={{ marginTop: 24 }}
            disabled={!name.trim()}
            onPress={() => {
              onCreate({ name: name.trim(), en: '', eq, p: [muscle], s: [], type, mech: '', lvl: '', cues: [], ins: [], pt: true });
              setName('');
            }}
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const st = StyleSheet.create({
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12 },
  search: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 16, borderRadius: 10, paddingHorizontal: 10 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, paddingRight: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  bottom: { position: 'absolute', left: 16, right: 16, bottom: 34 },
  input: { borderWidth: StyleSheet.hairlineWidth, borderRadius: 10, padding: 12, fontSize: 16, marginTop: 6 },
});
