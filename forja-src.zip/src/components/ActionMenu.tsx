import React from 'react';
import { Modal, Pressable, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTheme } from '../theme';
import { IconName, Ionicons, T } from './ui';

export type MenuItem = { label: string; icon?: IconName; danger?: boolean; onPress: () => void };

/** Menu de ações em folha inferior (igual em iOS e Android). */
export function ActionMenu({ title, items, visible, onClose }: { title?: string; items: MenuItem[]; visible: boolean; onClose: () => void }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={st.backdrop} onPress={onClose}>
        <Pressable style={[st.sheet, { backgroundColor: t.card, paddingBottom: 12 + insets.bottom }]}>
          {title ? (
            <T size={13} sub weight="600" style={{ textAlign: 'center', paddingVertical: 10 }} numberOfLines={1}>
              {title}
            </T>
          ) : null}
          {items.map((it, i) => (
            <Pressable
              key={i}
              onPress={() => {
                onClose();
                setTimeout(it.onPress, 250);
              }}
              style={({ pressed }) => [st.item, { borderColor: t.border, backgroundColor: pressed ? t.card2 : 'transparent' }]}
            >
              {it.icon ? <Ionicons name={it.icon} size={20} color={it.danger ? t.bad : t.text} style={{ width: 30 }} /> : null}
              <T size={16} color={it.danger ? t.bad : t.text}>
                {it.label}
              </T>
            </Pressable>
          ))}
          <Pressable onPress={onClose} style={[st.item, { justifyContent: 'center', borderBottomWidth: 0 }]}>
            <T size={16} weight="600" color={t.accent}>
              Cancelar
            </T>
          </Pressable>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const st = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.35)', justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: 18, borderTopRightRadius: 18, paddingHorizontal: 8, paddingTop: 6 },
  item: { flexDirection: 'row', alignItems: 'center', paddingVertical: 15, paddingHorizontal: 12, borderBottomWidth: StyleSheet.hairlineWidth },
});
