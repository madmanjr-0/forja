import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, StyleProp, StyleSheet, Text, TextStyle, View, ViewStyle } from 'react-native';
import { useTheme } from '../theme';

export type IconName = React.ComponentProps<typeof Ionicons>['name'];
export { Ionicons };

export function Card({ children, style, onPress }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void }) {
  const t = useTheme();
  const base = [s.card, { backgroundColor: t.card, borderColor: t.border }, style];
  if (onPress)
    return (
      <Pressable onPress={onPress} style={({ pressed }) => [...base, pressed && { opacity: 0.75 }]}>
        {children}
      </Pressable>
    );
  return <View style={base}>{children}</View>;
}

export function T({
  children,
  style,
  sub,
  faint,
  size = 15,
  weight,
  numberOfLines,
  color,
}: {
  children: React.ReactNode;
  style?: StyleProp<TextStyle>;
  sub?: boolean;
  faint?: boolean;
  size?: number;
  weight?: TextStyle['fontWeight'];
  numberOfLines?: number;
  color?: string;
}) {
  const t = useTheme();
  return (
    <Text
      numberOfLines={numberOfLines}
      style={[{ color: color ?? (faint ? t.faint : sub ? t.sub : t.text), fontSize: size, fontWeight: weight }, style]}
    >
      {children}
    </Text>
  );
}

export function Btn({
  title,
  onPress,
  kind = 'primary',
  icon,
  style,
  small,
  disabled,
}: {
  title: string;
  onPress: () => void;
  kind?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'good';
  icon?: IconName;
  style?: StyleProp<ViewStyle>;
  small?: boolean;
  disabled?: boolean;
}) {
  const t = useTheme();
  const bg = { primary: t.accent, secondary: t.card2, ghost: 'transparent', danger: t.dark ? '#3A1C1E' : '#FDECEC', good: t.good }[kind];
  const fg = { primary: t.onAccent, secondary: t.text, ghost: t.accent, danger: t.bad, good: '#fff' }[kind];
  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        s.btn,
        small && s.btnSmall,
        { backgroundColor: bg, opacity: disabled ? 0.4 : pressed ? 0.8 : 1 },
        style,
      ]}
    >
      {icon ? <Ionicons name={icon} size={small ? 16 : 19} color={fg} style={{ marginRight: title ? 6 : 0 }} /> : null}
      {title ? <Text style={{ color: fg, fontWeight: '600', fontSize: small ? 14 : 16 }}>{title}</Text> : null}
    </Pressable>
  );
}

export function Chip({ label, active, onPress }: { label: string; active?: boolean; onPress?: () => void }) {
  const t = useTheme();
  return (
    <Pressable
      onPress={onPress}
      style={[s.chip, { backgroundColor: active ? t.accent : t.card, borderColor: active ? t.accent : t.border }]}
    >
      <Text style={{ color: active ? t.onAccent : t.text, fontSize: 13, fontWeight: '500' }}>{label}</Text>
    </Pressable>
  );
}

export function Section({ title, right, children, style }: { title: string; right?: React.ReactNode; children?: React.ReactNode; style?: StyleProp<ViewStyle> }) {
  return (
    <View style={[{ marginTop: 22 }, style]}>
      <View style={s.sectionHead}>
        <T size={13} weight="700" sub style={{ letterSpacing: 0.6, textTransform: 'uppercase' }}>
          {title}
        </T>
        {right}
      </View>
      {children}
    </View>
  );
}

export function Stat({ label, value, icon }: { label: string; value: string; icon?: IconName }) {
  const t = useTheme();
  return (
    <View style={{ flex: 1 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
        {icon ? <Ionicons name={icon} size={13} color={t.sub} /> : null}
        <T size={12} sub>
          {label}
        </T>
      </View>
      <T size={17} weight="700" style={{ marginTop: 2 }}>
        {value}
      </T>
    </View>
  );
}

export function Divider() {
  const t = useTheme();
  return <View style={{ height: StyleSheet.hairlineWidth, backgroundColor: t.border, marginVertical: 10 }} />;
}

export function Empty({ icon, title, text }: { icon: IconName; title: string; text?: string }) {
  const t = useTheme();
  return (
    <View style={{ alignItems: 'center', paddingVertical: 40, paddingHorizontal: 24 }}>
      <View style={[s.emptyIcon, { backgroundColor: t.accentSoft }]}>
        <Ionicons name={icon} size={28} color={t.accent} />
      </View>
      <T size={17} weight="700" style={{ marginTop: 14, textAlign: 'center' }}>
        {title}
      </T>
      {text ? (
        <T sub style={{ marginTop: 6, textAlign: 'center', lineHeight: 20 }}>
          {text}
        </T>
      ) : null}
    </View>
  );
}

export const s = StyleSheet.create({
  card: { borderRadius: 14, padding: 14, borderWidth: StyleSheet.hairlineWidth },
  btn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderRadius: 10, paddingVertical: 13, paddingHorizontal: 16 },
  btnSmall: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8 },
  chip: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 18, borderWidth: StyleSheet.hairlineWidth, marginRight: 8 },
  sectionHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  emptyIcon: { width: 60, height: 60, borderRadius: 30, alignItems: 'center', justifyContent: 'center' },
});
