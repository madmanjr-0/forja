import React, { useState } from 'react';
import { LayoutChangeEvent, View } from 'react-native';
import Svg, { Circle, Defs, G, Line, LinearGradient, Path, Polygon, RadialGradient, Rect, Stop, Text as SvgText } from 'react-native-svg';
import { useTheme } from '../theme';
import { fmtNum, fmtShort } from '../util';
import { T } from './ui';

function useWidth(): [number, (e: LayoutChangeEvent) => void] {
  const [w, setW] = useState(0);
  return [w, (e) => setW(Math.round(e.nativeEvent.layout.width))];
}

export type Pt = { x: number; y: number };

/** Gráfico de linha com área, pontos tocáveis e valor selecionado. */
export function LineChart({ data, height = 180, unit = '', color, digits = 1 }: { data: Pt[]; height?: number; unit?: string; color?: string; digits?: number }) {
  const t = useTheme();
  const c = color ?? t.accent;
  const [w, onLayout] = useWidth();
  const [sel, setSel] = useState<number | null>(null);

  if (data.length === 0)
    return (
      <View style={{ height, alignItems: 'center', justifyContent: 'center' }}>
        <T faint>Sem dados ainda</T>
      </View>
    );

  const padL = 36, padR = 12, padT = 14, padB = 22;
  const xs = data.map((d) => d.x), ys = data.map((d) => d.y);
  const minX = Math.min(...xs), maxX = Math.max(...xs);
  let minY = Math.min(...ys), maxY = Math.max(...ys);
  if (minY === maxY) { minY -= 1; maxY += 1; }
  const range = maxY - minY;
  minY -= range * 0.12; maxY += range * 0.12;
  const iw = Math.max(1, w - padL - padR), ih = height - padT - padB;
  const X = (x: number) => padL + (maxX === minX ? iw / 2 : ((x - minX) / (maxX - minX)) * iw);
  const Y = (y: number) => padT + ih - ((y - minY) / (maxY - minY)) * ih;
  const line = data.map((d, i) => `${i ? 'L' : 'M'}${X(d.x).toFixed(1)},${Y(d.y).toFixed(1)}`).join(' ');
  const area = `${line} L${X(data[data.length - 1].x)},${padT + ih} L${X(data[0].x)},${padT + ih} Z`;
  const ticks = [0, 0.5, 1].map((f) => minY + (maxY - minY) * f);
  const shown = sel != null ? data[sel] : data[data.length - 1];
  const first = data[0].y;
  const diff = data[data.length - 1].y - first;

  return (
    <View onLayout={onLayout}>
      <View style={{ flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 4 }}>
        <T size={22} weight="800">
          {fmtNum(shown.y, digits)}
          <T size={14} sub> {unit}</T>
        </T>
        <T size={12} sub>
          {sel != null ? fmtShort(shown.x) : data.length > 1 ? `${diff >= 0 ? '+' : ''}${fmtNum(diff, digits)} ${unit} desde o início` : ''}
        </T>
      </View>
      {w > 0 && (
        <Svg width={w} height={height}>
          <Defs>
            <LinearGradient id="lg" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0" stopColor={c} stopOpacity={0.28} />
              <Stop offset="1" stopColor={c} stopOpacity={0} />
            </LinearGradient>
          </Defs>
          {ticks.map((v, i) => (
            <G key={i}>
              <Line x1={padL} x2={w - padR} y1={Y(v)} y2={Y(v)} stroke={t.border} strokeDasharray="3 4" />
              <SvgText x={padL - 6} y={Y(v) + 4} fontSize={10} fill={t.faint} textAnchor="end">
                {fmtNum(v, v >= 100 ? 0 : 1)}
              </SvgText>
            </G>
          ))}
          <SvgText x={padL} y={height - 4} fontSize={10} fill={t.faint}>{fmtShort(minX)}</SvgText>
          <SvgText x={w - padR} y={height - 4} fontSize={10} fill={t.faint} textAnchor="end">{fmtShort(maxX)}</SvgText>
          {data.length > 1 && <Path d={area} fill="url(#lg)" />}
          {data.length > 1 && <Path d={line} stroke={c} strokeWidth={2.5} fill="none" strokeLinejoin="round" strokeLinecap="round" />}
          {data.map((d, i) => (
            <Circle
              key={i}
              cx={X(d.x)}
              cy={Y(d.y)}
              r={sel === i ? 6 : data.length > 30 ? 2 : 3.5}
              fill={sel === i ? c : t.card}
              stroke={c}
              strokeWidth={2}
              onPress={() => setSel(sel === i ? null : i)}
            />
          ))}
          {/* Zonas de toque maiores */}
          {data.map((d, i) => (
            <Rect key={'h' + i} x={X(d.x) - 12} y={padT} width={24} height={ih} fill="transparent" onPress={() => setSel(sel === i ? null : i)} />
          ))}
        </Svg>
      )}
    </View>
  );
}

/** Barras verticais simples (ex.: volume semanal). */
export function BarChart({ bars, height = 150, color, format }: { bars: { label: string; value: number }[]; height?: number; color?: string; format?: (v: number) => string }) {
  const t = useTheme();
  const c = color ?? t.accent;
  const [w, onLayout] = useWidth();
  const [sel, setSel] = useState<number | null>(null);
  const max = Math.max(1, ...bars.map((b) => b.value));
  const padB = 20, padT = 18;
  const ih = height - padB - padT;
  const bw = bars.length ? w / bars.length : 0;
  return (
    <View onLayout={onLayout}>
      {w > 0 && (
        <Svg width={w} height={height}>
          {bars.map((b, i) => {
            const h = (b.value / max) * ih;
            const last = i === bars.length - 1;
            const active = sel === i || (sel == null && last);
            return (
              <G key={i} onPress={() => setSel(sel === i ? null : i)}>
                <Rect x={i * bw} y={0} width={bw} height={height} fill="transparent" />
                <Rect x={i * bw + bw * 0.18} y={padT + ih - h} width={bw * 0.64} height={Math.max(h, 2)} rx={4} fill={c} opacity={active ? 1 : 0.35} />
                {active && b.value > 0 ? (
                  <SvgText x={i * bw + bw / 2} y={padT + ih - h - 5} fontSize={10} fontWeight="700" fill={t.text} textAnchor="middle">
                    {format ? format(b.value) : Math.round(b.value)}
                  </SvgText>
                ) : null}
                <SvgText x={i * bw + bw / 2} y={height - 5} fontSize={10} fill={t.faint} textAnchor="middle">
                  {b.label}
                </SvgText>
              </G>
            );
          })}
        </Svg>
      )}
    </View>
  );
}

export type RadarSeries = { label: string; values: number[]; color: string; fill?: boolean };

/**
 * Radar estilo "scouter" (Dragon Ball): hexágonos concêntricos com
 * polígonos sobrepostos para comparar períodos. Valores em 0..1.
 */
export function Radar({ axes, series, size = 280, valueLabels }: { axes: string[]; series: RadarSeries[]; size?: number; valueLabels?: string[] }) {
  const t = useTheme();
  const [w, onLayout] = useWidth();
  const S = Math.min(size, w || size);
  const cx = S / 2, cy = S / 2;
  const R = S / 2 - 44;
  const n = axes.length;
  const ang = (i: number) => -Math.PI / 2 + (i * 2 * Math.PI) / n;
  const P = (i: number, r: number) => [cx + Math.cos(ang(i)) * r, cy + Math.sin(ang(i)) * r];
  const ring = (f: number) => axes.map((_, i) => P(i, R * f).join(',')).join(' ');

  return (
    <View onLayout={onLayout} style={{ alignItems: 'center' }}>
      {w > 0 && (
        <Svg width={S} height={S}>
          <Defs>
            <RadialGradient id="rg" cx="50%" cy="50%" r="50%">
              <Stop offset="0" stopColor={t.accent} stopOpacity={0.06} />
              <Stop offset="1" stopColor={t.accent} stopOpacity={0.16} />
            </RadialGradient>
          </Defs>
          <Polygon points={ring(1)} fill="url(#rg)" stroke={t.border} strokeWidth={1.2} />
          {[0.25, 0.5, 0.75].map((f) => (
            <Polygon key={f} points={ring(f)} fill="none" stroke={t.border} strokeWidth={1} />
          ))}
          {axes.map((_, i) => {
            const [x, y] = P(i, R);
            return <Line key={i} x1={cx} y1={cy} x2={x} y2={y} stroke={t.border} strokeWidth={1} />;
          })}
          {series.map((sr, si) => {
            const pts = sr.values.map((v, i) => P(i, R * Math.max(0.02, Math.min(1, v))).join(',')).join(' ');
            return (
              <G key={si}>
                <Polygon points={pts} fill={sr.color} fillOpacity={sr.fill === false ? 0 : 0.22} stroke={sr.color} strokeWidth={2.2} strokeLinejoin="round" strokeDasharray={sr.fill === false ? '5 4' : undefined} />
                {sr.fill !== false &&
                  sr.values.map((v, i) => {
                    const [x, y] = P(i, R * Math.max(0.02, Math.min(1, v)));
                    return <Circle key={i} cx={x} cy={y} r={3.5} fill={sr.color} />;
                  })}
              </G>
            );
          })}
          {axes.map((a, i) => {
            const [x, y] = P(i, R + 22);
            return (
              <G key={'l' + i}>
                <SvgText x={x} y={y} fontSize={12} fontWeight="700" fill={t.text} textAnchor="middle">
                  {a}
                </SvgText>
                {valueLabels ? (
                  <SvgText x={x} y={y + 14} fontSize={10.5} fill={t.sub} textAnchor="middle">
                    {valueLabels[i]}
                  </SvgText>
                ) : null}
              </G>
            );
          })}
        </Svg>
      )}
      <View style={{ flexDirection: 'row', gap: 16, marginTop: 4 }}>
        {series.map((sr) => (
          <View key={sr.label} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <View style={{ width: 12, height: 3, borderRadius: 2, backgroundColor: sr.color }} />
            <T size={12} sub>
              {sr.label}
            </T>
          </View>
        ))}
      </View>
    </View>
  );
}
