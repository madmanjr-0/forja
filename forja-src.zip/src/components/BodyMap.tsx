import React, { useState } from 'react';
import { View } from 'react-native';
import Svg, { Circle, Ellipse, G, Line, Path, Rect, Text as SvgText } from 'react-native-svg';
import { useTheme } from '../theme';
import { T } from './ui';
import { BODY } from '../data/bodyPaths';
import { DETAIL_LABEL } from '../muscles';
import { useStore } from '../store';

function Silhouette({ color }: { color: string }) {
  return (
    <G fill={color}>
      <Circle cx={50} cy={17} r={11} />
      <Rect x={45} y={26} width={10} height={10} rx={3} />
      <Path d="M30 40 Q50 33 70 40 L69 100 Q50 106 31 100 Z" />
      <Rect x={17} y={41} width={14} height={38} rx={7} />
      <Rect x={69} y={41} width={14} height={38} rx={7} />
      <Rect x={14} y={78} width={11} height={30} rx={5.5} />
      <Rect x={75} y={78} width={11} height={30} rx={5.5} />
      <Circle cx={19} cy={112} r={5} />
      <Circle cx={81} cy={112} r={5} />
      <Path d="M31 98 Q50 106 69 98 L68 158 L52 158 L50 118 L48 158 L32 158 Z" />
      <Rect x={33} y={156} width={14} height={50} rx={7} />
      <Rect x={53} y={156} width={14} height={50} rx={7} />
      <Rect x={33} y={203} width={14} height={8} rx={4} />
      <Rect x={53} y={203} width={14} height={8} rx={4} />
    </G>
  );
}

const HEAT = ['#FFC85A', '#FF9A2E', '#FF5A1F', '#E5262E'];
function heat(v: number): string {
  const x = Math.max(0, Math.min(1, v)) * (HEAT.length - 1);
  const i = Math.min(HEAT.length - 2, Math.floor(x));
  return mix(HEAT[i], HEAT[i + 1], x - i);
}

function mix(a: string, b: string, f: number): string {
  const p = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const [r1, g1, b1] = p(a), [r2, g2, b2] = p(b);
  const c = (x: number, y: number) => Math.round(x + (y - x) * f).toString(16).padStart(2, '0');
  return `#${c(r1, r2)}${c(g1, g2)}${c(b1, b2)}`;
}

// slug do desenho → músculo(s) detalhado(s); o ombro lateral aparece (mais suave) nas duas vistas
const FRONT_MAP: Record<string, string> = { chest: 'peito', biceps: 'biceps', triceps: 'triceps', forearm: 'antebracos', abs: 'abdominais', obliques: 'obliquos', trapezius: 'trapezio', adductors: 'adutores', quadriceps: 'quadriceps', calves: 'gemeos', deltoids: 'ombro_frente' };
const BACK_MAP: Record<string, string> = { trapezius: 'trapezio', 'upper-back': 'costas', 'lower-back': 'lombar', triceps: 'triceps', forearm: 'antebracos', gluteal: 'gluteos', adductors: 'adutores', hamstring: 'isquios', calves: 'gemeos', deltoids: 'ombro_tras' };

/**
 * Mapa muscular anatómico (frente/costas), colorido pela intensidade 0..1 de cada músculo detalhado.
 * Toca num músculo para ver o nome e as séries.
 */
export function BodyMap({ intensity, sets, height = 260 }: { intensity: Record<string, number>; sets?: Record<string, number>; height?: number }) {
  const t = useTheme();
  const { data } = useStore();
  const [sel, setSel] = useState<string | null>(null);
  const sex = data.profile?.sex === 'f' ? 'female' : 'male';
  const body = t.dark ? '#262B33' : '#DCE1E7';
  const idle = t.dark ? '#3A414C' : '#BCC4CE';
  const val = (m: string) => Math.max(0, Math.min(1, intensity[m] ?? 0));
  const deltVal = (head: string) => Math.max(val(head), val('ombro_lado') * 0.75);
  const fill = (v: number) => (v <= 0 ? idle : heat(0.08 + 0.92 * v));
  const w = height / 2;

  const views = [
    { key: 'front', label: 'Frente', side: BODY[sex].front, map: FRONT_MAP },
    { key: 'back', label: 'Costas', side: BODY[sex].back, map: BACK_MAP },
  ];
  const selLabel = sel ? DETAIL_LABEL[sel] ?? sel : null;
  const selSets = sel && sets ? (sel.startsWith('ombro_') ? sets[sel] ?? 0 : sets[sel] ?? 0) : null;

  return (
    <View>
      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 14 }}>
        {views.map((vw) => (
          <View key={vw.key} style={{ alignItems: 'center' }}>
            <Svg width={w} height={height} viewBox={vw.side.viewBox}>
              <Path d={vw.side.border} fill={body} stroke={body} strokeWidth={6} />
              {vw.side.parts.map((p) => {
                const m = vw.map[p.slug];
                const v = !m ? 0 : m.startsWith('ombro_') ? deltVal(m) : val(m);
                const isSel = !!m && (sel === m || (sel === 'ombro_lado' && p.slug === 'deltoids'));
                const color = !m ? body : fill(v);
                return p.d.map((d, i) => (
                  <Path
                    key={p.slug + i}
                    d={d}
                    fill={color}
                    stroke={isSel ? t.text : 'none'}
                    strokeWidth={isSel ? 5 : 0}
                    onPress={m ? () => setSel((s) => (s === m ? null : m)) : undefined}
                  />
                ));
              })}
            </Svg>
            <T size={12} sub style={{ marginTop: 4 }}>
              {vw.label}
            </T>
          </View>
        ))}
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 10, gap: 6, minHeight: 20 }}>
        {selLabel ? (
          <T size={13} weight="700">
            {selLabel}
            {selSets != null ? <T size={13} sub>{`  ·  ${String(Math.round(selSets * 10) / 10).replace('.', ',')} séries`}</T> : null}
          </T>
        ) : (
          <>
            <T size={11} faint>
              Pouco
            </T>
            {[0.15, 0.4, 0.65, 0.9].map((v) => (
              <View key={v} style={{ width: 22, height: 8, borderRadius: 4, backgroundColor: fill(v) }} />
            ))}
            <T size={11} faint>
              Muito
            </T>
          </>
        )}
      </View>
    </View>
  );
}

export type Measure = { key: string; label: string; value?: number; delta?: number };

/** Silhueta com as medidas corporais anotadas (cm) e a variação desde o primeiro registo. */
export function MeasureSilhouette({ items, height = 300 }: { items: Measure[]; height?: number }) {
  const t = useTheme();
  const base = t.dark ? '#2A2F36' : '#E2E6EB';
  const anchors: Record<string, { x: number; y: number; side: 'l' | 'r'; ly: number }> = {
    shoulders: { x: 29, y: 44, side: 'l', ly: 22 },
    armL: { x: 23, y: 64, side: 'l', ly: 58 },
    waist: { x: 38, y: 92, side: 'l', ly: 94 },
    thighL: { x: 40, y: 132, side: 'l', ly: 130 },
    neck: { x: 52, y: 30, side: 'r', ly: 14 },
    chest: { x: 58, y: 52, side: 'r', ly: 46 },
    armR: { x: 77, y: 64, side: 'r', ly: 78 },
    hip: { x: 64, y: 104, side: 'r', ly: 110 },
    thighR: { x: 60, y: 132, side: 'r', ly: 142 },
  };
  const W = 240;
  const H = 230;
  const ox = 70; // deslocação da figura dentro do viewBox
  return (
    <View style={{ alignItems: 'center' }}>
      <Svg width={(height / H) * W} height={height} viewBox={`0 0 ${W} ${H}`}>
        <G transform={`translate(${ox},0)`}>
          <Silhouette color={base} />
        </G>
        {items.map((it) => {
          const a = anchors[it.key];
          if (!a) return null;
          const ax = a.x + ox;
          const lx = a.side === 'l' ? 6 : W - 6;
          const ex = a.side === 'l' ? 56 : W - 56;
          const has = it.value != null;
          const dcol = it.delta == null || Math.abs(it.delta) < 0.05 ? t.sub : (it.key === 'waist' ? it.delta < 0 : it.delta > 0) ? t.good : t.bad;
          return (
            <G key={it.key}>
              <Circle cx={ax} cy={a.y} r={2.6} fill={t.accent} />
              <Path d={`M${ax} ${a.y} L${ex} ${a.ly} L${a.side === 'l' ? lx + 2 : lx - 2} ${a.ly}`} stroke={t.accent} strokeWidth={0.8} fill="none" />
              <SvgText x={lx} y={a.ly - 4} fontSize={8.5} fill={t.sub} textAnchor={a.side === 'l' ? 'start' : 'end'}>
                {it.label}
              </SvgText>
              <SvgText x={lx} y={a.ly + 9} fontSize={11} fontWeight="700" fill={has ? t.text : t.faint} textAnchor={a.side === 'l' ? 'start' : 'end'}>
                {has ? `${String(it.value).replace('.', ',')} cm` : '—'}
              </SvgText>
              {it.delta != null && Math.abs(it.delta) >= 0.05 ? (
                <SvgText x={lx} y={a.ly + 20} fontSize={8.5} fontWeight="600" fill={dcol} textAnchor={a.side === 'l' ? 'start' : 'end'}>
                  {`${it.delta > 0 ? '+' : ''}${it.delta.toFixed(1).replace('.', ',')}`}
                </SvgText>
              ) : null}
            </G>
          );
        })}
        <Line x1={0} x2={0} y1={0} y2={0} />
      </Svg>
    </View>
  );
}
