import React, { useState } from 'react';
import { View } from 'react-native';
import Svg, { Circle, G, Path, Text as SvgText } from 'react-native-svg';
import { useTheme } from '../theme';
import { T } from './ui';
import { BODY } from '../data/bodyPaths';
import { DETAIL_LABEL } from '../muscles';
import { useStore } from '../store';

const HEAT = ['#FFC85A', '#FF9A2E', '#FF5A1F', '#E5262E'];
function heat(v: number): string {
  const x = Math.max(0, Math.min(1, v)) * (HEAT.length - 1);
  const i = Math.min(HEAT.length - 2, Math.floor(x));
  return mix(HEAT[i], HEAT[i + 1], x - i);
}

function mix(a: string, b: string, f: number): string {
  const p = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const [r1, g1, b1] = p(a), [r2, g2, b2] = p(b);
  const c = (x: number, y: number) => Math.round(x + (y - x) * f).toString(16).padStart(2, '0');
  return `#${c(r1, r2)}${c(g1, g2)}${c(b1, b2)}`;
}

// slug do desenho → músculo(s) detalhado(s); o ombro lateral aparece (mais suave) nas duas vistas
const FRONT_MAP: Record<string, string> = { chest: 'peito', biceps: 'biceps', triceps: 'triceps', forearm: 'antebracos', abs: 'abdominais', obliques: 'obliquos', trapezius: 'trapezio', adductors: 'adutores', quadriceps: 'quadriceps', calves: 'gemeos', deltoids: 'ombro_frente' };
const BACK_MAP: Record<string, string> = { trapezius: 'trapezio', 'upper-back': 'costas', 'lower-back': 'lombar', triceps: 'triceps', forearm: 'antebracos', gluteal: 'gluteos', adductors: 'adutores', hamstring: 'isquios', calves: 'gemeos', deltoids: 'ombro_tras' };

/**
 * Mapa muscular anatómico (frente/costas), colorido pela intensidade 0..1 de cada músculo detalhado.
 * Toca num músculo para ver o nome e as séries.
 */
export function BodyMap({ intensity, sets, height = 260 }: { intensity: Record<string, number>; sets?: Record<string, number>; height?: number }) {
  const t = useTheme();
  const { data } = useStore();
  const [sel, setSel] = useState<string | null>(null);
  const sex = data.profile?.sex === 'f' ? 'female' : 'male';
  const body = t.dark ? '#262B33' : '#DCE1E7';
  const idle = t.dark ? '#3A414C' : '#BCC4CE';
  const val = (m: string) => Math.max(0, Math.min(1, intensity[m] ?? 0));
  const deltVal = (head: string) => Math.max(val(head), val('ombro_lado') * 0.75);
  const fill = (v: number) => (v <= 0 ? idle : heat(0.08 + 0.92 * v));
  const w = height / 2;

  const views = [
    { key: 'front', label: 'Frente', side: BODY[sex].front, map: FRONT_MAP },
    { key: 'back', label: 'Costas', side: BODY[sex].back, map: BACK_MAP },
  ];
  const selLabel = sel ? DETAIL_LABEL[sel] ?? sel : null;
  const selSets = sel && sets ? (sel.startsWith('ombro_') ? sets[sel] ?? 0 : sets[sel] ?? 0) : null;

  return (
    <View>
      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 14 }}>
        {views.map((vw) => (
          <View key={vw.key} style={{ alignItems: 'center' }}>
            <Svg width={w} height={height} viewBox={vw.side.viewBox}>
              <Path d={vw.side.border} fill={body} stroke={body} strokeWidth={6} />
              {vw.side.parts.map((p) => {
                const m = vw.map[p.slug];
                const v = !m ? 0 : m.startsWith('ombro_') ? deltVal(m) : val(m);
                const isSel = !!m && (sel === m || (sel === 'ombro_lado' && p.slug === 'deltoids'));
                const color = !m ? body : fill(v);
                return p.d.map((d, i) => (
                  <Path
                    key={p.slug + i}
                    d={d}
                    fill={color}
                    stroke={isSel ? t.text : 'none'}
                    strokeWidth={isSel ? 5 : 0}
                    onPress={m ? () => setSel((s) => (s === m ? null : m)) : undefined}
                  />
                ));
              })}
            </Svg>
            <T size={12} sub style={{ marginTop: 4 }}>
              {vw.label}
            </T>
          </View>
        ))}
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 10, gap: 6, minHeight: 20 }}>
        {selLabel ? (
          <T size={13} weight="700">
            {selLabel}
            {selSets != null ? <T size={13} sub>{`  ·  ${String(Math.round(selSets * 10) / 10).replace('.', ',')} séries`}</T> : null}
          </T>
        ) : (
          <>
            <T size={11} faint>
              Pouco
            </T>
            {[0.15, 0.4, 0.65, 0.9].map((v) => (
              <View key={v} style={{ width: 22, height: 8, borderRadius: 4, backgroundColor: fill(v) }} />
            ))}
            <T size={11} faint>
              Muito
            </T>
          </>
        )}
      </View>
    </View>
  );
}

export type Measure = { key: string; label: string; value?: number; delta?: number };

type Anchor = { x: number; y: number; side: 'l' | 'r'; ly: number };
// Pontos de medida sobre o desenho de frente (coordenadas do viewBox de cada corpo).
// Vista de frente: o lado esquerdo da pessoa aparece à direita do ecrã.
const ANCHORS: Record<'male' | 'female', Record<string, Anchor>> = {
  male: {
    shoulders: { x: 214, y: 345, side: 'l', ly: 300 },
    armR: { x: 200, y: 450, side: 'l', ly: 480 },
    waist: { x: 292, y: 610, side: 'l', ly: 660 },
    thighR: { x: 270, y: 800, side: 'l', ly: 850 },
    neck: { x: 392, y: 282, side: 'r', ly: 190 },
    chest: { x: 430, y: 372, side: 'r', ly: 370 },
    armL: { x: 528, y: 450, side: 'r', ly: 550 },
    hip: { x: 480, y: 700, side: 'r', ly: 730 },
    thighL: { x: 458, y: 800, side: 'r', ly: 910 },
  },
  female: {
    shoulders: { x: 190, y: 330, side: 'l', ly: 290 },
    armR: { x: 178, y: 430, side: 'l', ly: 470 },
    waist: { x: 252, y: 580, side: 'l', ly: 650 },
    thighR: { x: 232, y: 800, side: 'l', ly: 850 },
    neck: { x: 348, y: 286, side: 'r', ly: 180 },
    chest: { x: 385, y: 376, side: 'r', ly: 360 },
    armL: { x: 462, y: 430, side: 'r', ly: 540 },
    hip: { x: 436, y: 660, side: 'r', ly: 720 },
    thighL: { x: 410, y: 800, side: 'r', ly: 900 },
  },
};

/** Corpo de frente com as medidas corporais anotadas (cm) e a variação desde o primeiro registo. */
export function MeasureSilhouette({ items, maxHeight = 420 }: { items: Measure[]; maxHeight?: number }) {
  const t = useTheme();
  const { data } = useStore();
  const sex = data.profile?.sex === 'f' ? 'female' : 'male';
  const side = BODY[sex].front;
  const [vx, vy, vw, vh] = side.viewBox.split(' ').map(Number);
  const M = 380; // margem lateral para os rótulos
  const X0 = vx - M;
  const W = vw + 2 * M;
  const body = t.dark ? '#2B3039' : '#DCE1E7';
  const muscle = t.dark ? '#363C46' : '#C9D0D9';
  const anchors = ANCHORS[sex];
  return (
    <View style={{ width: '100%', maxWidth: (maxHeight * W) / vh, aspectRatio: W / vh, alignSelf: 'center' }}>
      <Svg width="100%" height="100%" viewBox={`${X0} ${vy} ${W} ${vh}`}>
        <Path d={side.border} fill={body} stroke={body} strokeWidth={6} />
        {side.parts.map((p) =>
          p.d.map((d, i) => <Path key={p.slug + i} d={d} fill={['head', 'hair', 'neck', 'hands', 'feet', 'knees', 'ankles'].includes(p.slug) ? body : muscle} />),
        )}
        {items.map((it) => {
          const a = anchors[it.key];
          if (!a) return null;
          const left = a.side === 'l';
          const lx = left ? X0 + 14 : X0 + W - 14;
          const elbow = left ? vx + 40 : vx + vw - 40;
          const has = it.value != null;
          const dcol = it.delta == null || Math.abs(it.delta) < 0.05 ? t.sub : (it.key === 'waist' ? it.delta < 0 : it.delta > 0) ? t.good : t.bad;
          const anchorTxt = left ? 'start' : 'end';
          return (
            <G key={it.key}>
              <Path d={`M${a.x} ${a.y} L${elbow} ${a.ly} L${left ? lx + 10 : lx - 10} ${a.ly}`} stroke={has ? t.accent : t.faint} strokeWidth={4} fill="none" />
              <Circle cx={a.x} cy={a.y} r={11} fill={has ? t.accent : t.faint} stroke={body} strokeWidth={4} />
              <SvgText x={lx} y={a.ly - 16} fontSize={42} fontFamily="sans-serif" fill={t.sub} textAnchor={anchorTxt}>
                {it.label}
              </SvgText>
              <SvgText x={lx} y={a.ly + 60} fontSize={60} fontFamily="sans-serif" fontWeight="700" fill={has ? t.text : t.faint} textAnchor={anchorTxt}>
                {has ? `${String(it.value).replace('.', ',')} cm` : '—'}
              </SvgText>
              {it.delta != null && Math.abs(it.delta) >= 0.05 ? (
                <SvgText x={lx} y={a.ly + 108} fontSize={40} fontFamily="sans-serif" fontWeight="700" fill={dcol} textAnchor={anchorTxt}>
                  {`${it.delta > 0 ? '+' : ''}${it.delta.toFixed(1).replace('.', ',')}`}
                </SvgText>
              ) : null}
            </G>
          );
        })}
      </Svg>
    </View>
  );
}
