import React from 'react';
import { View } from 'react-native';
import Svg, { Circle, Ellipse, G, Line, Path, Rect, Text as SvgText } from 'react-native-svg';
import { useTheme } from '../theme';
import { T } from './ui';

// Silhueta esquemática 100 x 230. Cada músculo é uma forma simples.
type Shape = { m: string; el: 'e' | 'r' | 'p'; a: number[] | string };

const FRONT: Shape[] = [
  { m: 'ombros', el: 'e', a: [27, 47, 9, 8] },
  { m: 'ombros', el: 'e', a: [73, 47, 9, 8] },
  { m: 'peito', el: 'p', a: 'M37 44 Q49 41 49 46 L49 62 Q42 66 35 60 Q32 52 37 44 Z' },
  { m: 'peito', el: 'p', a: 'M63 44 Q51 41 51 46 L51 62 Q58 66 65 60 Q68 52 63 44 Z' },
  { m: 'biceps', el: 'e', a: [23, 67, 5.5, 11] },
  { m: 'biceps', el: 'e', a: [77, 67, 5.5, 11] },
  { m: 'antebracos', el: 'e', a: [19, 92, 4.8, 13] },
  { m: 'antebracos', el: 'e', a: [81, 92, 4.8, 13] },
  { m: 'abdominais', el: 'r', a: [42.5, 66, 15, 34, 6] },
  { m: 'quadriceps', el: 'p', a: 'M34 112 Q41 108 48 113 L47 150 Q41 156 36 150 Q31 130 34 112 Z' },
  { m: 'quadriceps', el: 'p', a: 'M66 112 Q59 108 52 113 L53 150 Q59 156 64 150 Q69 130 66 112 Z' },
  { m: 'adutores', el: 'p', a: 'M48 114 L50 116 L52 114 L51 134 L49 134 Z' },
  { m: 'gemeos', el: 'e', a: [40, 182, 5, 16] },
  { m: 'gemeos', el: 'e', a: [60, 182, 5, 16] },
];

const BACK: Shape[] = [
  { m: 'trapezio', el: 'p', a: 'M40 38 Q50 32 60 38 L56 56 L50 60 L44 56 Z' },
  { m: 'ombros', el: 'e', a: [27, 47, 9, 8] },
  { m: 'ombros', el: 'e', a: [73, 47, 9, 8] },
  { m: 'costas', el: 'p', a: 'M36 52 L44 56 L48 82 Q41 86 36 78 Q33 64 36 52 Z' },
  { m: 'costas', el: 'p', a: 'M64 52 L56 56 L52 82 Q59 86 64 78 Q67 64 64 52 Z' },
  { m: 'lombar', el: 'r', a: [43.5, 82, 13, 16, 4] },
  { m: 'triceps', el: 'e', a: [23, 67, 5.5, 11] },
  { m: 'triceps', el: 'e', a: [77, 67, 5.5, 11] },
  { m: 'antebracos', el: 'e', a: [19, 92, 4.8, 13] },
  { m: 'antebracos', el: 'e', a: [81, 92, 4.8, 13] },
  { m: 'gluteos', el: 'e', a: [42, 108, 8.5, 9] },
  { m: 'gluteos', el: 'e', a: [58, 108, 8.5, 9] },
  { m: 'isquios', el: 'p', a: 'M35 120 Q41 116 48 120 L47 152 Q41 158 36 152 Q32 136 35 120 Z' },
  { m: 'isquios', el: 'p', a: 'M65 120 Q59 116 52 120 L53 152 Q59 158 64 152 Q68 136 65 120 Z' },
  { m: 'gemeos', el: 'e', a: [40, 180, 6.5, 16] },
  { m: 'gemeos', el: 'e', a: [60, 180, 6.5, 16] },
];

function Silhouette({ color }: { color: string }) {
  return (
    <G fill={color}>
      <Circle cx={50} cy={17} r={11} />
      <Rect x={45} y={26} width={10} height={10} rx={3} />
      <Path d="M30 40 Q50 33 70 40 L69 100 Q50 106 31 100 Z" />
      <Rect x={17} y={41} width={14} height={38} rx={7} />
      <Rect x={69} y={41} width={14} height={38} rx={7} />
      <Rect x={14} y={78} width={11} height={30} rx={5.5} />
      <Rect x={75} y={78} width={11} height={30} rx={5.5} />
      <Circle cx={19} cy={112} r={5} />
      <Circle cx={81} cy={112} r={5} />
      <Path d="M31 98 Q50 106 69 98 L68 158 L52 158 L50 118 L48 158 L32 158 Z" />
      <Rect x={33} y={156} width={14} height={50} rx={7} />
      <Rect x={53} y={156} width={14} height={50} rx={7} />
      <Rect x={33} y={203} width={14} height={8} rx={4} />
      <Rect x={53} y={203} width={14} height={8} rx={4} />
    </G>
  );
}

function ShapeEl({ sh, fill }: { sh: Shape; fill: string }) {
  if (sh.el === 'e') {
    const [cx, cy, rx, ry] = sh.a as number[];
    return <Ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={fill} />;
  }
  if (sh.el === 'r') {
    const [x, y, w, h, r] = sh.a as number[];
    return <Rect x={x} y={y} width={w} height={h} rx={r} fill={fill} />;
  }
  return <Path d={sh.a as string} fill={fill} />;
}

function mix(a: string, b: string, f: number): string {
  const p = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const [r1, g1, b1] = p(a), [r2, g2, b2] = p(b);
  const c = (x: number, y: number) => Math.round(x + (y - x) * f).toString(16).padStart(2, '0');
  return `#${c(r1, r2)}${c(g1, g2)}${c(b1, b2)}`;
}

/**
 * Mapa muscular frente/costas colorido pela intensidade (0..1) de cada músculo.
 */
export function BodyMap({ intensity, height = 260 }: { intensity: Record<string, number>; height?: number }) {
  const t = useTheme();
  const base = t.dark ? '#2A2F36' : '#E2E6EB';
  const muscleBase = t.dark ? '#353B44' : '#D3D9E0';
  const hot = t.accent;
  const fillFor = (m: string) => {
    const v = Math.max(0, Math.min(1, intensity[m] ?? 0));
    return v <= 0 ? muscleBase : mix(mix(muscleBase, hot, 0.25), hot, v);
  };
  const w = (height / 230) * 100;
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 18 }}>
      {[
        { label: 'Frente', shapes: FRONT },
        { label: 'Costas', shapes: BACK },
      ].map((side) => (
        <View key={side.label} style={{ alignItems: 'center' }}>
          <Svg width={w} height={height} viewBox="0 0 100 230">
            <Silhouette color={base} />
            {side.shapes.map((sh, i) => (
              <ShapeEl key={i} sh={sh} fill={fillFor(sh.m)} />
            ))}
          </Svg>
          <T size={12} sub style={{ marginTop: 4 }}>
            {side.label}
          </T>
        </View>
      ))}
    </View>
  );
}

export type Measure = { key: string; label: string; value?: number; delta?: number };

/** Silhueta com as medidas corporais anotadas (cm) e a variação desde o primeiro registo. */
export function MeasureSilhouette({ items, height = 300 }: { items: Measure[]; height?: number }) {
  const t = useTheme();
  const base = t.dark ? '#2A2F36' : '#E2E6EB';
  const anchors: Record<string, { x: number; y: number; side: 'l' | 'r'; ly: number }> = {
    shoulders: { x: 29, y: 44, side: 'l', ly: 22 },
    armL: { x: 23, y: 64, side: 'l', ly: 58 },
    waist: { x: 38, y: 92, side: 'l', ly: 94 },
    thighL: { x: 40, y: 132, side: 'l', ly: 130 },
    neck: { x: 52, y: 30, side: 'r', ly: 14 },
    chest: { x: 58, y: 52, side: 'r', ly: 46 },
    armR: { x: 77, y: 64, side: 'r', ly: 78 },
    hip: { x: 64, y: 104, side: 'r', ly: 110 },
    thighR: { x: 60, y: 132, side: 'r', ly: 142 },
  };
  const W = 240;
  const H = 230;
  const ox = 70; // deslocação da figura dentro do viewBox
  return (
    <View style={{ alignItems: 'center' }}>
      <Svg width={(height / H) * W} height={height} viewBox={`0 0 ${W} ${H}`}>
        <G transform={`translate(${ox},0)`}>
          <Silhouette color={base} />
        </G>
        {items.map((it) => {
          const a = anchors[it.key];
          if (!a) return null;
          const ax = a.x + ox;
          const lx = a.side === 'l' ? 6 : W - 6;
          const ex = a.side === 'l' ? 56 : W - 56;
          const has = it.value != null;
          const dcol = it.delta == null || Math.abs(it.delta) < 0.05 ? t.sub : (it.key === 'waist' ? it.delta < 0 : it.delta > 0) ? t.good : t.bad;
          return (
            <G key={it.key}>
              <Circle cx={ax} cy={a.y} r={2.6} fill={t.accent} />
              <Path d={`M${ax} ${a.y} L${ex} ${a.ly} L${a.side === 'l' ? lx + 2 : lx - 2} ${a.ly}`} stroke={t.accent} strokeWidth={0.8} fill="none" />
              <SvgText x={lx} y={a.ly - 4} fontSize={8.5} fill={t.sub} textAnchor={a.side === 'l' ? 'start' : 'end'}>
                {it.label}
              </SvgText>
              <SvgText x={lx} y={a.ly + 9} fontSize={11} fontWeight="700" fill={has ? t.text : t.faint} textAnchor={a.side === 'l' ? 'start' : 'end'}>
                {has ? `${String(it.value).replace('.', ',')} cm` : '—'}
              </SvgText>
              {it.delta != null && Math.abs(it.delta) >= 0.05 ? (
                <SvgText x={lx} y={a.ly + 20} fontSize={8.5} fontWeight="600" fill={dcol} textAnchor={a.side === 'l' ? 'start' : 'end'}>
                  {`${it.delta > 0 ? '+' : ''}${it.delta.toFixed(1).replace('.', ',')}`}
                </SvgText>
              ) : null}
            </G>
          );
        })}
        <Line x1={0} x2={0} y1={0} y2={0} />
      </Svg>
    </View>
  );
}
