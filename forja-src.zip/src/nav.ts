import type { NativeStackNavigationProp } from '@react-navigation/native-stack';

export type RootStack = {
  Tabs: undefined;
  Workout: undefined;
  WorkoutDetail: { id: string; fresh?: boolean };
  RoutineEdit: { id?: string };
  ExerciseDetail: { id: string };
  Settings: undefined;
  BodyEntry: { id?: string };
};

export type Nav = NativeStackNavigationProp<RootStack>;
