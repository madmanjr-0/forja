// Lógica de planeamento: letra de cada treino, próximo treino sugerido e duração estimada.
import type { Routine, Workout } from './store';
import { DAY } from './util';

/** "Treino A · Ginásio" → "A", "Casa B · Halteres" → "CB"; nomes sem letra curta → null (mostra ✓). */
export function routineLetter(name: string): string | null {
  const n = name.trim();
  let m = n.match(/^treino\s+([a-z0-9])\b/i);
  if (m) return m[1].toUpperCase();
  m = n.match(/^casa\s+([a-z0-9])\b/i);
  if (m) return 'C' + m[1].toUpperCase();
  if (n.length <= 3 && n.toLowerCase() !== 'treino livre') return n.toUpperCase();
  return null;
}

export function workoutMark(w: Workout, routines: Routine[]): string {
  const r = routines.find((x) => x.id === w.routineId);
  return routineLetter(r?.name ?? w.name) ?? '✓';
}

const letterOf = (r: Routine) => (r.name.match(/\b([AB])\b/) || [])[1];

/** Próximo treino sugerido: alterna A/B com base no último treino com rotina. */
export function nextRoutines(routines: Routine[], workouts: Workout[]): { gym?: Routine; home?: Routine } {
  const last = [...workouts].sort((a, b) => b.start - a.start).find((w) => routines.some((r) => r.id === w.routineId));
  const lastR = routines.find((r) => r.id === last?.routineId);
  const want = lastR && letterOf(lastR) === 'A' ? 'B' : 'A';
  const pick = (list: Routine[]) => list.find((r) => letterOf(r) === want) ?? list[0];
  return { gym: pick(routines.filter((r) => r.place === 'gym')), home: pick(routines.filter((r) => r.place === 'home')) };
}

/** Dia da semana (0 = segunda) em que se prevê o próximo treino: nunca hoje, e com pelo menos 1 dia de descanso. */
export function forecastDayIndex(workouts: Workout[], weekStartTs: number, now = Date.now()): number | null {
  const todayIdx = Math.floor((now - weekStartTs) / DAY);
  const last = workouts.reduce((m, w) => Math.max(m, w.start), 0);
  const lastIdx = last ? Math.floor((last - weekStartTs) / DAY) : -99;
  const idx = Math.max(todayIdx + 1, lastIdx + 2);
  return idx >= 0 && idx < 7 ? idx : null;
}

export type DurationEstimate = { min: number; fromHistory: number; lo?: number; hi?: number };

/** Duração estimada: média dos últimos 5 treinos desta rotina; sem histórico, séries × (descanso + 45 s) + 5 min. */
export function estimateDuration(r: Routine, workouts: Workout[]): DurationEstimate {
  const past = workouts
    .filter((w) => w.routineId === r.id && w.end)
    .sort((a, b) => b.start - a.start)
    .map((w) => (w.end! - w.start) / 60000)
    .filter((m) => m >= 8 && m <= 240)
    .slice(0, 5);
  if (past.length) {
    const avg = past.reduce((a, b) => a + b, 0) / past.length;
    return { min: Math.round(avg), fromHistory: past.length, lo: Math.round(Math.min(...past)), hi: Math.round(Math.max(...past)) };
  }
  const secs = r.exercises.reduce((a, e) => a + e.sets * (e.restSec + 45), 0);
  return { min: Math.round(secs / 60 + 5), fromHistory: 0 };
}

export function totalSets(r: Routine): number {
  return r.exercises.reduce((a, e) => a + e.sets, 0);
}
